(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([["pages/coupons/index"],{

/***/ "./node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib/index.js!./src/pages/coupons/index.tsx":
/*!******************************************************************************************************!*\
  !*** ./node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib!./src/pages/coupons/index.tsx ***!
  \******************************************************************************************************/
/*! exports provided: default */
/*! exports used: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/cjs/react.production.min.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _tarojs_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @tarojs/components */ "./node_modules/@tarojs/components/mini/index.js");
/* harmony import */ var _component_loginComponet_index__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../component/loginComponet/index */ "./src/component/loginComponet/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @tarojs/taro */ "./node_modules/@tarojs/taro/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _utils_commonUtils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../utils/commonUtils */ "./src/utils/commonUtils.tsx");
/* harmony import */ var _index_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./index.scss */ "./src/pages/coupons/index.scss");
/* harmony import */ var _index_scss__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_index_scss__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../utils/utils */ "./src/utils/utils.js");
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_utils_utils__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./index.module.scss */ "./src/pages/coupons/index.module.scss");
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_8__);









var api = __webpack_require__(/*! ../../utils/utils.js */ "./src/utils/utils.js");



function Index() {
  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])([]),
      _useState2 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState, 2),
      movies = _useState2[0],
      setMovies = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])({
    "showEle": false
  }),
      _useState4 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState3, 2),
      config = _useState4[0],
      setConfig = _useState4[1];

  var _useState5 = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])({}),
      _useState6 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState5, 2),
      meituan = _useState6[0],
      setMeituan = _useState6[1];

  var _useState7 = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])({}),
      _useState8 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState7, 2),
      ele = _useState8[0],
      setEle = _useState8[1];

  var _useState9 = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(),
      _useState10 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState9, 2),
      hasShowLogin = _useState10[0],
      setHasShowLogin = _useState10[1];

  var _useState11 = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])([]),
      _useState12 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState11, 2),
      datalist = _useState12[0],
      setDatalist = _useState12[1];

  Object(_utils_commonUtils__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_4__["useRouter"])());
  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_4__["useReady"])(function () {
    requestElmeLink();
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_4___default.a.setNavigationBarTitle({
      title: '每日菜谱'
    });
  });
  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_4__["useDidShow"])(function () {
    handleLoginMethod();
  });

  var handleLoginMethod = function handleLoginMethod() {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_4___default.a.getStorage({
      key: "token",
      success: function success(res) {
        setHasShowLogin(false);
      },
      fail: function fail(res) {
        setHasShowLogin(true);
      }
    });
  };

  var parentMethod = function parentMethod(result) {
    setHasShowLogin(false);
  };

  var toCoupon = function toCoupon(index, url) {
    if (!config.showEle) {
      _tarojs_taro__WEBPACK_IMPORTED_MODULE_4___default.a.navigateToMiniProgram({
        appId: "wxde8ac0a21135c07d",
        //饿了么appid固定
        path: '/index/pages/h5/h5?weburl=https%3A%2F%2Frunion.meituan.com%2Furl%3Fkey%3Db426de166efb63fac7331c3b720982de%26url%3Dhttps%253A%252F%252Fi.meituan.com%252Fawp%252Fhfe%252Fblock%252Fa13b87919a9ace9cfab4%252F89400%252Findex.html%253Fappkey%253Db426de166efb63fac7331c3b720982de%253Adfgg%26sid%3Ddfgg&lch=cps:waimai:5:b426de166efb63fac7331c3b720982de:dfgg&f_token=1&f_userId=1'
      });
    } else {
      _tarojs_taro__WEBPACK_IMPORTED_MODULE_4___default.a.setStorage({
        key: _utils_utils__WEBPACK_IMPORTED_MODULE_7__["keySelectedIndex"],
        data: index
      });
      _tarojs_taro__WEBPACK_IMPORTED_MODULE_4___default.a.switchTab({
        url: url
      });
    }
  };

  var redirectDetail = function redirectDetail(item) {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_4___default.a.setStorage({
      key: 'id',
      data: item.id
    }); // Taro.setStorage({
    //   key: 'content',
    //   data: item.content.content
    // })

    _tarojs_taro__WEBPACK_IMPORTED_MODULE_4___default.a.navigateTo({
      url: "../detail/index?id=" + item.id
    });
  };

  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_4__["useShareAppMessage"])(function (res) {
    if (res.from === "button") {
      // 来自页面内转发按钮
      console.log(res.target);
    }

    return {
      title: api.shareTitle,
      path: api.sharePath + "?inviter=" + _tarojs_taro__WEBPACK_IMPORTED_MODULE_4___default.a.getStorageSync(api.miniapp_self_uuid)
    };
  });

  var requestList = function requestList() {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_4___default.a.showLoading({
      title: "加载中"
    });
    setTimeout(function () {
      _tarojs_taro__WEBPACK_IMPORTED_MODULE_4___default.a.hideLoading();
    }, 5000);
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_4___default.a.request({
      url: "https://xcf.haozii.com/wp-json/wp/v2/posts?categories=20&page=1",
      data: {
        v: api.VERSION
      },
      success: function success(res) {
        _tarojs_taro__WEBPACK_IMPORTED_MODULE_4___default.a.hideLoading();
        setDatalist(res.data);
        console.log(res.data);
      },
      fail: function fail() {
        _tarojs_taro__WEBPACK_IMPORTED_MODULE_4___default.a.hideLoading();
      }
    });
  };

  var requestElmeLink = function requestElmeLink() {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_4___default.a.request({
      url: api.NewIndexUrl,
      data: {
        wxappid: api.WXAppID,
        v: api.VERSION
      },
      success: function success(res) {
        console.log(res.data.data.movies);
        setMovies(res.data.data.movies);
        setConfig(res.data.data.config);
        setMeituan(res.data.data.meituan);
        setEle(res.data.data.ele);
        console.log(res.data.data.config);

        if (!res.data.data.config.showEle) {
          requestList();
        } else {
          _tarojs_taro__WEBPACK_IMPORTED_MODULE_4___default.a.setNavigationBarTitle({
            title: '点外卖 有优惠 有返利'
          });
        }
      }
    });
  };

  return !config.showEle ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], null, hasShowLogin ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_component_loginComponet_index__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"], {
    parentMethod: parentMethod.bind(this)
  }) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], null), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_8___default.a.items
  }, datalist.map(function (item, i) {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_8___default.a.top_banner,
      onClick: function onClick() {
        return redirectDetail(item);
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Image */ "c"], {
      src: item.meta.thumbnaill,
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_8___default.a.top_banner_img,
      mode: "aspectFill"
    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_8___default.a.textbg
    }, item.title.rendered));
  }))) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
    className: "take_out"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
    className: "banner"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
    className: "bg"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
    className: "up-space"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
    className: "down_space"
  })), hasShowLogin ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_component_loginComponet_index__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"], {
    parentMethod: parentMethod.bind(this)
  }) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], null), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
    className: "hover"
  }, config.showEle ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Swiper */ "g"], {
    className: "swiper",
    autoplay: true,
    circular: true,
    indicatorActiveColor: "#fff",
    indicatorColor: "#ccc",
    indicatorDots: true
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* SwiperItem */ "h"], {
    className: "swiper_item"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Image */ "c"], {
    className: "img",
    mode: "widthFix",
    src: "https://img.mybei.cn/weapp-1.png"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* SwiperItem */ "h"], {
    className: "swiper_item"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Image */ "c"], {
    className: "img",
    mode: "widthFix",
    src: "https://qt-user-img.oss-cn-hangzhou.aliyuncs.com/weapp/takeout-banner2.png"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* SwiperItem */ "h"], {
    className: "swiper_item"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Image */ "c"], {
    className: "img",
    mode: "widthFix",
    src: "https://qt-user-img.oss-cn-hangzhou.aliyuncs.com/weapp/takeout-banner-3.png"
  }))) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Swiper */ "g"], {
    className: "swiper",
    autoplay: true,
    circular: true,
    indicatorActiveColor: "#fff",
    indicatorColor: "#ccc",
    indicatorDots: true
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* SwiperItem */ "h"], {
    className: "swiper_item"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Image */ "c"], {
    className: "img",
    mode: "widthFix",
    src: "https://img.mybei.cn/weapp-1.png"
  }))))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
    className: "icon_menu"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Button */ "a"], {
    className: "item",
    onClick: function onClick() {
      return _tarojs_taro__WEBPACK_IMPORTED_MODULE_4___default.a.navigateTo({
        url: "../index/index"
      });
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Image */ "c"], {
    className: "icon",
    mode: "widthFix",
    src: "https://qt-user-img.oss-cn-hangzhou.aliyuncs.com/weapp/takeout-home-icon-film.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Text */ "i"], {
    className: "label"
  }, "\u4ECA\u5929\u5403\u5565")), config.showEle ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Button */ "a"], {
    className: "item",
    onClick: function onClick() {
      return toCoupon(0, '../ele/index');
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Image */ "c"], {
    className: "icon",
    mode: "widthFix",
    src: "https://qt-user-img.oss-cn-hangzhou.aliyuncs.com/weapp/takeout-home-icon-ele.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Text */ "i"], {
    className: "label"
  }, "\u997F\u4E86\u4E48")) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Button */ "a"], {
    className: "item",
    onClick: function onClick() {
      return toCoupon(0, '../meituan/index');
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Image */ "c"], {
    className: "icon",
    mode: "widthFix",
    src: "https://qt-user-img.oss-cn-hangzhou.aliyuncs.com/weapp/takeout-home-icon-meituan.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Text */ "i"], {
    className: "label"
  }, "\u7F8E\u56E2\u5916\u5356")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Button */ "a"], {
    className: "item",
    onClick: function onClick() {
      return toCoupon(0, '../meituan/index');
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Image */ "c"], {
    className: "icon",
    mode: "widthFix",
    src: "https://qt-user-img.oss-cn-hangzhou.aliyuncs.com/weapp/takeout-home-icon-meituan.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Text */ "i"], {
    className: "label"
  }, "\u7F8E\u56E2\u5916\u5356")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Button */ "a"], {
    className: "item",
    openType: "share"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Image */ "c"], {
    className: "icon",
    mode: "widthFix",
    src: "https://qt-user-img.oss-cn-hangzhou.aliyuncs.com/weapp/takeout-home-icon-share.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Text */ "i"], {
    className: "label"
  }, "\u5206\u4EAB\u597D\u53CB"))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
    className: "list shadow"
  }, config.showEle ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
    className: "item animated fadeIn",
    onClick: function onClick() {
      return toCoupon(0, '../ele/index');
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
    className: "left"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Image */ "c"], {
    className: "label ele",
    mode: "widthFix",
    src: "https://mpstatic.qingting123.com/img/take-out/label-ele.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Image */ "c"], {
    className: "mark ele",
    mode: "widthFix",
    src: "https://mpstatic.qingting123.com/img/take-out/mark-ele.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
    className: "content"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
    className: "title"
  }, "\u997F\u4E86\u4E48\u5929\u5929\u62A2\u7EA2\u5305"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
    className: "info"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Text */ "i"], {
    className: "price"
  }, "66"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Text */ "i"], {
    className: "unit"
  }, "\u5143"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Text */ "i"], {
    className: "tip"
  }, "\u4ECA\u65E5\u4EC5\u5269\u4E2A", ele.remain, "\u4E2A")))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
    className: "right"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
    className: "btn red"
  }, "\u514D\u8D39\u9886\u53D6"))) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], null), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
    className: "item animated fadeIn",
    onClick: function onClick() {
      return toCoupon(0, '../meituan/index');
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
    className: "left"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Image */ "c"], {
    className: "label mt",
    mode: "widthFix",
    src: "https://mpstatic.qingting123.com/img/take-out/label-mt.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Image */ "c"], {
    className: "mark mt",
    mode: "widthFix",
    src: "https://mpstatic.qingting123.com/img/take-out/mark-mt.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
    className: "content"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
    className: "title"
  }, "\u7F8E\u56E2\u5916\u5356\u7EA2\u5305"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
    className: "info"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Text */ "i"], {
    className: "price"
  }, "56"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Text */ "i"], {
    className: "unit"
  }, "\u5143"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Text */ "i"], {
    className: "tip"
  }, "\u4ECA\u65E5\u4EC5\u5269", meituan.remain, "\u4E2A")))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
    className: "right"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
    className: "btn red"
  }, "\u514D\u8D39\u9886\u53D6")))), config.showEle ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], null) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
    className: "card films"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
    className: "header"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
    className: "title"
  }, "\u70ED\u6620\u7535\u5F71\u63A8\u8350"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
    className: "extra"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Text */ "i"], {
    className: "value"
  }, "\u5168\u90E833\u90E8"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Text */ "i"], {
    className: "icon-font iconfont-arrow"
  }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* ScrollView */ "f"], {
    className: "body",
    enableFlex: true,
    scrollX: true
  }, movies.map(function (item, i) {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
      className: "item"
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
      className: "content"
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Image */ "c"], {
      className: "pic",
      mode: "aspectFit",
      src: item.pic
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Text */ "i"], {
      className: "grade"
    }, item.grade)), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
      className: "name"
    }, item.name)));
  }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
    className: "card multi"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
    className: "header"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
    className: "title"
  }, "\u679C\u852C\xB7\u5546\u8D85\xB7\u9152\u5E97")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
    className: "body"
  }, config.showEle ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
    className: "item",
    onClick: function onClick() {
      return toCoupon(1, '../ele/index');
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Image */ "c"], {
    className: "img",
    src: "https://qt-user-img.oss-cn-hangzhou.aliyuncs.com/weapp/takeout-home-card-ele-gs.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
    className: "btn"
  }, "\u9886\u53D6")) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], null), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
    className: "item",
    onClick: function onClick() {
      return toCoupon(1, '../meituan/index');
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Image */ "c"], {
    className: "img",
    src: "https://qt-user-img.oss-cn-hangzhou.aliyuncs.com/weapp/takeout-home-card-meituan-market.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
    className: "btn"
  }, "\u9886\u53D6")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
    className: "item",
    onClick: function onClick() {
      return toCoupon(2, '../meituan/index');
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* Image */ "c"], {
    className: "img",
    src: "https://qt-user-img.oss-cn-hangzhou.aliyuncs.com/weapp/takeout-home-card-meituan-hotel.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_2__[/* View */ "j"], {
    className: "btn"
  }, "\u9886\u53D6")))));
}

/* harmony default export */ __webpack_exports__["a"] = (Index);

/***/ }),

/***/ "./src/pages/coupons/index.module.scss":
/*!*********************************************!*\
  !*** ./src/pages/coupons/index.module.scss ***!
  \*********************************************/
/*! no static exports found */
/*! exports used: default */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin
module.exports = {"page":"index-module__page___2MU2S","top_banner":"index-module__top_banner___2EIKN","textbg":"index-module__textbg___1eyGU","top_banner_img":"index-module__top_banner_img___rqv1R"};

/***/ }),

/***/ "./src/pages/coupons/index.scss":
/*!**************************************!*\
  !*** ./src/pages/coupons/index.scss ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "./src/pages/coupons/index.tsx":
/*!*************************************!*\
  !*** ./src/pages/coupons/index.tsx ***!
  \*************************************/
/*! no exports provided */
/*! all exports used */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _tarojs_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @tarojs/runtime */ "./node_modules/@tarojs/runtime/dist/runtime.esm.js");
/* harmony import */ var _node_modules_tarojs_mini_runner_node_modules_babel_loader_lib_index_js_index_tsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib!./index.tsx */ "./node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib/index.js!./src/pages/coupons/index.tsx");


var config = {"navigationBarTitleText":"每日菜谱","enableShareAppMessage":true};

_node_modules_tarojs_mini_runner_node_modules_babel_loader_lib_index_js_index_tsx__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].enableShareAppMessage = true
var inst = Page(Object(_tarojs_runtime__WEBPACK_IMPORTED_MODULE_0__["createPageConfig"])(_node_modules_tarojs_mini_runner_node_modules_babel_loader_lib_index_js_index_tsx__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"], 'pages/coupons/index', {}, config || {}))



/***/ })

},[["./src/pages/coupons/index.tsx","runtime","taro","vendors","common"]]]);
//# sourceMappingURL=index.js.map