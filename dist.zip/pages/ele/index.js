(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([["pages/ele/index"],{

/***/ "./node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib/index.js!./src/pages/ele/index.tsx":
/*!**************************************************************************************************!*\
  !*** ./node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib!./src/pages/ele/index.tsx ***!
  \**************************************************************************************************/
/*! exports provided: default */
/*! exports used: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _tarojs_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @tarojs/components */ "./node_modules/@tarojs/components/mini/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @tarojs/taro */ "./node_modules/@tarojs/taro/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/cjs/react.production.min.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _index_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./index.scss */ "./src/pages/ele/index.scss");
/* harmony import */ var _index_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_index_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./index.module.scss */ "./src/pages/ele/index.module.scss");
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _ele_eleme__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../ele/eleme */ "./src/pages/ele/eleme/index.tsx");
/* harmony import */ var _ele_guoshu__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../ele/guoshu */ "./src/pages/ele/guoshu/index.tsx");
/* harmony import */ var _utils_event__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../utils/event */ "./src/utils/event.js");
/* harmony import */ var _component_CustomNavBar__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../component/CustomNavBar */ "./src/component/CustomNavBar/index.tsx");
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../utils/utils */ "./src/utils/utils.js");
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_utils_utils__WEBPACK_IMPORTED_MODULE_10__);












var api = __webpack_require__(/*! ../../utils/utils.js */ "./src/utils/utils.js");

function EleMain() {
  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])([]),
      _useState2 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState, 2),
      datalist = _useState2[0],
      setDatalist = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(true),
      _useState4 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState3, 2),
      inreview = _useState4[0],
      setInreview = _useState4[1];

  var _useState5 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(),
      _useState6 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState5, 2),
      selectIndex = _useState6[0],
      setSelectIndex = _useState6[1];

  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useReady"])(function () {
    console.log("ready");
  });

  var redirectDetail = function redirectDetail(item) {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.setStorage({
      key: 'id',
      data: item.id
    }); // Taro.setStorage({
    //   key: 'content',
    //   data: item.content.content
    // })

    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.navigateTo({
      url: "../detail/index?id=" + item.id
    });
  };

  var requestList = function requestList() {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.showLoading({
      title: "加载中"
    });
    setTimeout(function () {
      _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.hideLoading();
    }, 5000);
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.request({
      url: "https://xcf.haozii.com/wp-json/wp/v2/posts?categories=28&page=1",
      data: {
        v: api.VERSION
      },
      success: function success(res) {
        _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.hideLoading();
        setDatalist(res.data);
        console.log(res.data);
      },
      fail: function fail() {
        _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.hideLoading();
      }
    });
  };

  var requestAppInfo = function requestAppInfo() {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.request({
      url: api.IndexUrl,
      header: {
        "X-Nideshop-Token": _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync("token") || ""
      },
      data: {
        userid: _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync("userInfo").id,
        wxappid: api.WXAppID,
        v: api.VERSION
      },
      success: function success(res) {
        setInreview(parseInt(res.data.data.inreview) ? true : false);

        if (!parseInt(res.data.data.inreview)) {
          _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.setTabBarItem({
            "index": 1,
            "text": "饿了么红包",
            'iconPath': 'assets/imgs/ele.png',
            'selectedIconPath': 'assets/imgs/ele-active.png'
          });
        } else {
          requestList();
        }
      },
      fail: function fail() {}
    });
  };

  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useDidShow"])(function () {
    requestAppInfo();
    console.log("useDidShow");
    setSelectIndex(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync(_utils_utils__WEBPACK_IMPORTED_MODULE_10__["keySelectedIndex"]));
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.removeStorageSync(_utils_utils__WEBPACK_IMPORTED_MODULE_10__["keySelectedIndex"]);
    _utils_event__WEBPACK_IMPORTED_MODULE_8__[/* default */ "a"].removeListener(api.navBarSelectChangedNotification, callback);
    _utils_event__WEBPACK_IMPORTED_MODULE_8__[/* default */ "a"].addListener(api.navBarSelectChangedNotification, function (index) {
      setSelectIndex(index);
    });
  });

  var callback = function callback() {
    console.log("监听全局通知释放-----饿了么顶部点击");
  };

  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useDidHide"])(function () {
    _utils_event__WEBPACK_IMPORTED_MODULE_8__[/* default */ "a"].removeListener(api.navBarSelectChangedNotification, callback);
  });
  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useShareAppMessage"])(function (res) {
    if (res.from === "button") {
      // 来自页面内转发按钮
      console.log(res.target);
    }

    return {
      title: api.shareTitle,
      path: api.sharePath + "?inviter=" + _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync(api.miniapp_self_uuid)
    };
  });
  return inreview ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: "dddd"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_component_CustomNavBar__WEBPACK_IMPORTED_MODULE_9__[/* default */ "a"], {
    background: "#3481DA",
    color: "#fff",
    backgroundColorTop: "#3481DA",
    renderCenter: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], null, "\u6BCF\u65E5\u83DC\u8C31")
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_5___default.a.items
  }, datalist.map(function (item, i) {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_5___default.a.top_banner,
      onClick: function onClick() {
        return redirectDetail(item);
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
      src: item.meta.thumbnaill,
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_5___default.a.top_banner_img,
      mode: "aspectFill"
    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_5___default.a.textbg
    }, item.title.rendered));
  }))) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_5___default.a.page
  }, selectIndex ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_ele_guoshu__WEBPACK_IMPORTED_MODULE_7__[/* default */ "a"], null) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_ele_eleme__WEBPACK_IMPORTED_MODULE_6__[/* default */ "a"], null));
}

/* harmony default export */ __webpack_exports__["a"] = (EleMain);

/***/ }),

/***/ "./node_modules/taro-ui/dist/style/components/icon.scss":
/*!**************************************************************!*\
  !*** ./node_modules/taro-ui/dist/style/components/icon.scss ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "./node_modules/taro-ui/dist/style/components/nav-bar.scss":
/*!*****************************************************************!*\
  !*** ./node_modules/taro-ui/dist/style/components/nav-bar.scss ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "./src/pages/ele/eleme/index.tsx":
/*!***************************************!*\
  !*** ./src/pages/ele/eleme/index.tsx ***!
  \***************************************/
/*! exports provided: default */
/*! exports used: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _tarojs_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @tarojs/components */ "./node_modules/@tarojs/components/mini/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @tarojs/taro */ "./node_modules/@tarojs/taro/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/cjs/react.production.min.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../index.module.scss */ "./src/pages/ele/index.module.scss");
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! classnames */ "./node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _component_loginComponet_index__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../component/loginComponet/index */ "./src/component/loginComponet/index.js");
/* harmony import */ var _utils_commonUtils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../utils/commonUtils */ "./src/utils/commonUtils.tsx");
/* harmony import */ var _component_CustomNavBar__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../component/CustomNavBar */ "./src/component/CustomNavBar/index.tsx");
/* harmony import */ var _utils_event__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../utils/event */ "./src/utils/event.js");
/* harmony import */ var _component_imageDialog__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../component/imageDialog */ "./src/component/imageDialog/index.tsx");
/* harmony import */ var taro_ui_dist_style_components_nav_bar_scss__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! taro-ui/dist/style/components/nav-bar.scss */ "./node_modules/taro-ui/dist/style/components/nav-bar.scss");
/* harmony import */ var taro_ui_dist_style_components_nav_bar_scss__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(taro_ui_dist_style_components_nav_bar_scss__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var taro_ui_dist_style_components_icon_scss__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! taro-ui/dist/style/components/icon.scss */ "./node_modules/taro-ui/dist/style/components/icon.scss");
/* harmony import */ var taro_ui_dist_style_components_icon_scss__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(taro_ui_dist_style_components_icon_scss__WEBPACK_IMPORTED_MODULE_12__);














var api = __webpack_require__(/*! ../../../utils/utils.js */ "./src/utils/utils.js");

function Ele() {
  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useShareAppMessage"])(function (res) {
    if (res.from === "button") {
      // 来自页面内转发按钮
      console.log(res.target);
    }

    return {
      title: api.shareTitle,
      path: api.sharePath + "?inviter=" + _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync(api.miniapp_self_uuid)
    };
  });

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(),
      _useState2 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState, 2),
      hasShowLogin = _useState2[0],
      setHasShowLogin = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])("https://mpstatic.qingting123.com/img/loading-max.gif"),
      _useState4 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState3, 2),
      elmeLink_qr = _useState4[0],
      setElmeLink_qr = _useState4[1];

  var _useState5 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(""),
      _useState6 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState5, 2),
      elmeLink = _useState6[0],
      setElmeLink = _useState6[1];

  var _useState7 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(""),
      _useState8 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState7, 2),
      elmeLinkPromotionText = _useState8[0],
      setElmeLinkPromotionText = _useState8[1];

  var _useState9 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(),
      _useState10 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState9, 2),
      showPromote = _useState10[0],
      setShowPromote = _useState10[1];

  var handleLoginMethod = function handleLoginMethod() {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorage({
      key: "token",
      success: function success(res) {
        setHasShowLogin(false);
      },
      fail: function fail(res) {
        setHasShowLogin(true);
      }
    });
  };

  var generateClipboard = function generateClipboard() {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.setClipboardData({
      data: elmeLinkPromotionText,
      success: function success(res) {
        _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.showToast({
          title: "文案已复制",
          icon: 'none'
        });
      }
    });
  };

  var parentMethod = function parentMethod(result) {
    setHasShowLogin(false);
    requestElmeLink();
  }; //处理分享


  var handlePromote = function handlePromote() {
    setShowPromote(false);
  };

  var generatePromote = function generatePromote() {
    setShowPromote(true);
  };

  var requestElmeLink = function requestElmeLink() {
    console.log("====================请求饿了么");
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.request({
      url: api.ElmeLinkUrl,
      data: {
        wxappid: api.WXAppID,
        wx_openid: _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync("userInfo").weixin_openid,
        v: api.VERSION
      },
      header: {
        "X-Nideshop-Token": _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync("token")
      },
      success: function success(res) {
        setElmeLink_qr(res.data.data.link_qr);
        setElmeLink(res.data.data.link);
        setElmeLinkPromotionText(res.data.data.promotion_text);
      }
    });
  };

  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useDidShow"])(function () {
    handleLoginMethod();
  });

  var handlerGohomeClick = function handlerGohomeClick() {
    console.log("home click");
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.switchTab({
      url: "../../pages/coupons/index"
    });
  };

  var toCoupon = function toCoupon() {
    console.log("redirect" + elmeLink);
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.navigateToMiniProgram({
      appId: "wxece3a9a4c82f58c9",
      //饿了么appid固定
      path: elmeLink
    });
  };

  Object(_utils_commonUtils__WEBPACK_IMPORTED_MODULE_7__[/* default */ "a"])(Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useRouter"])());
  requestElmeLink();

  var handleClick = function handleClick(index) {
    if (index) _utils_event__WEBPACK_IMPORTED_MODULE_9__[/* default */ "a"].emit(api.navBarSelectChangedNotification, index);
  };

  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.waimai
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_component_CustomNavBar__WEBPACK_IMPORTED_MODULE_8__[/* default */ "a"], {
    background: "#3481DA",
    backgroundColorTop: "#3481DA",
    onHome: handlerGohomeClick,
    home: true,
    renderCenter: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.nav_bar_tabs
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.item, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.active]),
      onClick: function onClick() {
        return handleClick(0);
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.title
    }, "\u5916\u5356")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.item,
      onClick: function onClick() {
        return handleClick(1);
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.title
    }, "\u679C\u852C")))
  }), hasShowLogin ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_component_loginComponet_index__WEBPACK_IMPORTED_MODULE_6__[/* default */ "a"], {
    parentMethod: parentMethod.bind(this)
  }) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], null), showPromote ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_component_imageDialog__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"], {
    parentMethod: handlePromote.bind(this)
  }) : '', /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.wm_banner
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.img,
    mode: "widthFix",
    src: "https://mpstatic.qingting123.com/img/waimai/banner-ele-2.jpg"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.wm_coupon
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.header
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.step
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.img,
    mode: "widthFix",
    src: "https://mpstatic.qingting123.com/img/waimai/11.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.span
  }, "\u5148\u9886\u5238")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.link,
    mode: "widthFix",
    src: "https://mpstatic.qingting123.com/img/waimai/10.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.step
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.img,
    mode: "widthFix",
    src: "https://mpstatic.qingting123.com/img/waimai/12.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.span
  }, "\u518D\u4E0B\u5355")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.link,
    mode: "widthFix",
    src: "https://mpstatic.qingting123.com/img/waimai/10.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.step
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.img,
    mode: "widthFix",
    src: "https://mpstatic.qingting123.com/img/waimai/14.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.span
  }, "\u62FF\u8FD4\u5229"))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.content
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.qrcode,
    mode: "widthFix",
    src: elmeLink_qr
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.btn_wrapper,
    onClick: function onClick() {
      return toCoupon();
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.btn
  }, "\u9886\u7EA2\u5305\u70B9\u5916\u5356")))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.wm_btns
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.btn, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.left]),
    onClick: function onClick() {
      return generatePromote();
    }
  }, "\u5206\u4EAB\u8D5A\u94B1"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.btn, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.right]),
    onClick: function onClick() {
      return generateClipboard();
    }
  }, "\u590D\u5236\u6587\u6848")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.wm_tips
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.h3
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], null, "\u8FD4\u5229\u6CE8\u610F\u4E8B\u9879\uFF1A")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.p
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], null, "1.\u9886\u5238\u4E0B\u5355\u5747\u6709\u8FD4\u5229\uFF0C\u8FD4\u5229\u6309\u7167\u8BA2\u5355\u5B9E\u9645\u652F\u4ED8\u91D1\u989D\u4E3A\u51C6\uFF1B")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.p
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], null, "2.\u5FC5\u987B\u4F7F\u7528\u4ECE\u672C\u9875\u83B7\u5F97\u7684\u7EA2\u5305\u7801\u9886\u5238\uFF0C\u9886\u5238\u540E\u4F7F\u7528\u7EA2\u5305\u4E0B\u5355\u624D\u6709\u8FD4\u5229\uFF1B")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.p
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], null, "3.\u9886\u5238\u540E\u5728\u7EA2\u5305\u6709\u6548\u671F\u5185\u4E0B\u5355\u5747\u6709\u8FD4\u5229\uFF1B")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.p
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], null, "4.\u997F\u4E86\u4E48\u7ED1\u5B9A\u7684\u624B\u673A\u53F7\uFF0C\u9700\u4E0E\u9886\u5238\u767B\u5F55\u7684\u624B\u673A\u53F7\u4E00\u81F4\uFF1B")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.p
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], null, "5.\u4E0B\u5355\u540E30\u5206\u949F\u5185\u4F1A\u6709\u8BA2\u5355\u8FD4\u73B0\u63D0\u9192\uFF1B")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.p
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], null, "6.\u65E0\u8BBA\u997F\u4E86\u4E48\u65B0\u8001\u7528\u6237\uFF0C\u6BCF\u4E2A\u624B\u673A\u53F7\u6BCF\u5929\u53EF\u9886\u4E00\u6B21\uFF0C\u7EA2\u5305\u91D1\u989D\u968F\u673A\u53D1\u653E\uFF1B"))));
}

/* harmony default export */ __webpack_exports__["a"] = (Ele);

/***/ }),

/***/ "./src/pages/ele/guoshu/index.tsx":
/*!****************************************!*\
  !*** ./src/pages/ele/guoshu/index.tsx ***!
  \****************************************/
/*! exports provided: default */
/*! exports used: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _tarojs_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @tarojs/components */ "./node_modules/@tarojs/components/mini/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @tarojs/taro */ "./node_modules/@tarojs/taro/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/cjs/react.production.min.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../index.module.scss */ "./src/pages/ele/index.module.scss");
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! classnames */ "./node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _component_loginComponet_index__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../component/loginComponet/index */ "./src/component/loginComponet/index.js");
/* harmony import */ var _utils_commonUtils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../utils/commonUtils */ "./src/utils/commonUtils.tsx");
/* harmony import */ var _component_CustomNavBar__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../component/CustomNavBar */ "./src/component/CustomNavBar/index.tsx");
/* harmony import */ var _component_imageDialog__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../component/imageDialog */ "./src/component/imageDialog/index.tsx");
/* harmony import */ var taro_ui_dist_style_components_nav_bar_scss__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! taro-ui/dist/style/components/nav-bar.scss */ "./node_modules/taro-ui/dist/style/components/nav-bar.scss");
/* harmony import */ var taro_ui_dist_style_components_nav_bar_scss__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(taro_ui_dist_style_components_nav_bar_scss__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var taro_ui_dist_style_components_icon_scss__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! taro-ui/dist/style/components/icon.scss */ "./node_modules/taro-ui/dist/style/components/icon.scss");
/* harmony import */ var taro_ui_dist_style_components_icon_scss__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(taro_ui_dist_style_components_icon_scss__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _utils_event__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../utils/event */ "./src/utils/event.js");














var api = __webpack_require__(/*! ../../../utils/utils.js */ "./src/utils/utils.js");

function Guoshu() {
  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useShareAppMessage"])(function (res) {
    if (res.from === "button") {
      // 来自页面内转发按钮
      console.log(res.target);
    }

    return {
      title: api.shareTitle,
      path: api.sharePath + "?inviter=" + _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync(api.miniapp_self_uuid)
    };
  });

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(),
      _useState2 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState, 2),
      hasShowLogin = _useState2[0],
      setHasShowLogin = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])("https://mpstatic.qingting123.com/img/loading-max.gif"),
      _useState4 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState3, 2),
      elmeLink_qrGuoshu = _useState4[0],
      setElmeLink_qrGuoshu = _useState4[1];

  var _useState5 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(""),
      _useState6 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState5, 2),
      elmeLinkGuoshu = _useState6[0],
      setElmeLinkGuoshu = _useState6[1];

  var _useState7 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(""),
      _useState8 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState7, 2),
      elmeLinkPromotionText = _useState8[0],
      setElmeLinkPromotionText = _useState8[1];

  var _useState9 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(),
      _useState10 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState9, 2),
      showPromote = _useState10[0],
      setShowPromote = _useState10[1];

  var handleLoginMethod = function handleLoginMethod() {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorage({
      key: "token",
      success: function success(res) {
        setHasShowLogin(false);
      },
      fail: function fail(res) {
        setHasShowLogin(true);
      }
    });
  }; //处理分享


  var handlePromote = function handlePromote() {
    setShowPromote(false);
  };

  var generatePromote = function generatePromote() {
    setShowPromote(true);
  };

  var parentMethod = function parentMethod(result) {
    setHasShowLogin(false);
    requestElmeLink();
  };

  var generateClipboard = function generateClipboard() {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.setClipboardData({
      data: elmeLinkPromotionText,
      success: function success(res) {
        _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.showToast({
          title: "文案已复制",
          icon: 'none'
        });
      }
    });
  };

  var requestElmeLink = function requestElmeLink() {
    console.log("====================请求果蔬");
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.request({
      url: api.ElmeLinkUrl,
      data: {
        wxappid: api.WXAppID,
        wx_openid: _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync("userInfo").weixin_openid,
        v: api.VERSION
      },
      header: {
        "X-Nideshop-Token": _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync("token")
      },
      success: function success(res) {
        setElmeLink_qrGuoshu(res.data.data.link_qr_shuguo);
        setElmeLinkGuoshu(res.data.data.link_shuguo);
        setElmeLinkPromotionText(res.data.data.promotion_text);
      }
    });
  };

  var handlerGohomeClick = function handlerGohomeClick() {
    console.log("home click");
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.switchTab({
      url: "../../pages/coupons/index"
    });
  };

  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useDidShow"])(function () {
    handleLoginMethod();
  });
  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useReady"])(function () {
    console.log("ready");
  });

  var toCoupon = function toCoupon() {
    console.log("redirect" + elmeLinkGuoshu);
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.navigateToMiniProgram({
      appId: "wxece3a9a4c82f58c9",
      //饿了么appid固定
      path: elmeLinkGuoshu
    });
  };

  Object(_utils_commonUtils__WEBPACK_IMPORTED_MODULE_7__[/* default */ "a"])(Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useRouter"])());
  requestElmeLink();

  var handleClick = function handleClick(index) {
    if (!index) _utils_event__WEBPACK_IMPORTED_MODULE_12__[/* default */ "a"].emit(api.navBarSelectChangedNotification, index);
  };

  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.guoshu
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_component_CustomNavBar__WEBPACK_IMPORTED_MODULE_8__[/* default */ "a"], {
    background: "#4DC398",
    backgroundColorTop: "#4DC398",
    onHome: handlerGohomeClick,
    home: true,
    renderCenter: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.nav_bar_tabs
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.item,
      onClick: function onClick() {
        return handleClick(0);
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.title
    }, "\u5916\u5356")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.item, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.active]),
      onClick: function onClick() {
        return handleClick(1);
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.title
    }, "\u679C\u852C")))
  }), hasShowLogin ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_component_loginComponet_index__WEBPACK_IMPORTED_MODULE_6__[/* default */ "a"], {
    parentMethod: parentMethod.bind(this)
  }) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], null), showPromote ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_component_imageDialog__WEBPACK_IMPORTED_MODULE_9__[/* default */ "a"], {
    parentMethod: handlePromote.bind(this)
  }) : '', /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.wm_banner
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.img,
    mode: "widthFix",
    src: "https://mpstatic.qingting123.com/img/waimai/banner-ele-gs.png"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.wm_coupon
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.header
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.step
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.img,
    mode: "widthFix",
    src: "https://mpstatic.qingting123.com/img/waimai/gs-1.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.span
  }, "\u5148\u9886\u5238")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.link,
    mode: "widthFix",
    src: "https://mpstatic.qingting123.com/img/waimai/gs-4.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.step
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.img,
    mode: "widthFix",
    src: "https://mpstatic.qingting123.com/img/waimai/gs-2.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.span
  }, "\u518D\u4E0B\u5355")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.link,
    mode: "widthFix",
    src: "https://mpstatic.qingting123.com/img/waimai/gs-4.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.step
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.img,
    mode: "widthFix",
    src: "https://mpstatic.qingting123.com/img/waimai/gs-3.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.span
  }, "\u62FF\u8FD4\u5229"))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.content
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.qrcode,
    mode: "widthFix",
    src: elmeLink_qrGuoshu
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.btn_wrapper,
    onClick: function onClick() {
      return toCoupon();
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.btn
  }, "\u9886\u7EA2\u5305\u70B9\u5916\u5356")))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.wm_btns
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.btn, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.left]),
    onClick: function onClick() {
      return generatePromote();
    }
  }, "\u5206\u4EAB\u8D5A\u94B1"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.btn, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.right]),
    onClick: function onClick() {
      return generateClipboard();
    }
  }, "\u590D\u5236\u6587\u6848")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.wm_tips
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.h3
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], null, "\u8FD4\u5229\u6CE8\u610F\u4E8B\u9879\uFF1A")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.p
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], null, "1.\u9886\u5238\u4E0B\u5355\u5747\u6709\u8FD4\u5229\uFF0C\u8FD4\u5229\u6309\u7167\u8BA2\u5355\u5B9E\u9645\u652F\u4ED8\u91D1\u989D\u4E3A\u51C6\uFF1B")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.p
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], null, "2.\u5FC5\u987B\u4F7F\u7528\u4ECE\u672C\u9875\u83B7\u5F97\u7684\u7EA2\u5305\u7801\u9886\u5238\uFF0C\u9886\u5238\u540E\u4F7F\u7528\u7EA2\u5305\u4E0B\u5355\u624D\u6709\u8FD4\u5229\uFF1B")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.p
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], null, "3.\u9886\u5238\u540E\u5728\u7EA2\u5305\u6709\u6548\u671F\u5185\u4E0B\u5355\u5747\u6709\u8FD4\u5229\uFF1B")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.p
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], null, "4.\u997F\u4E86\u4E48\u7ED1\u5B9A\u7684\u624B\u673A\u53F7\uFF0C\u9700\u4E0E\u9886\u5238\u767B\u5F55\u7684\u624B\u673A\u53F7\u4E00\u81F4\uFF1B")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.p
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], null, "5.\u4E0B\u5355\u540E30\u5206\u949F\u5185\u4F1A\u6709\u8BA2\u5355\u8FD4\u73B0\u63D0\u9192\uFF1B")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.p
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], null, "6.\u65E0\u8BBA\u997F\u4E86\u4E48\u65B0\u8001\u7528\u6237\uFF0C\u6BCF\u4E2A\u624B\u673A\u53F7\u6BCF\u5929\u53EF\u9886\u4E00\u6B21\uFF0C\u7EA2\u5305\u91D1\u989D\u968F\u673A\u53D1\u653E\uFF1B"))));
}

/* harmony default export */ __webpack_exports__["a"] = (Guoshu);

/***/ }),

/***/ "./src/pages/ele/index.module.scss":
/*!*****************************************!*\
  !*** ./src/pages/ele/index.module.scss ***!
  \*****************************************/
/*! no static exports found */
/*! exports used: default */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin
module.exports = {"waimai":"index-module__waimai___3SJdx","nav_bar__left":"index-module__nav_bar__left___3GZ9H","nav_bar__button":"index-module__nav_bar__button___2TWHp","nav_bar_tabs":"index-module__nav_bar_tabs___3H_o2","item":"index-module__item___32HSW","title":"index-module__title___84iwT","active":"index-module__active___2gX2w","wm_banner":"index-module__wm_banner___CWNGt","img":"index-module__img___2vKL1","wm_coupon":"index-module__wm_coupon___1C4vY","header":"index-module__header___3gYH-","step":"index-module__step___1z81w","span":"index-module__span___1nUBB","link":"index-module__link___1QglY","content":"index-module__content___cLnID","qrcode":"index-module__qrcode___3MdCZ","wm_btns":"index-module__wm_btns___-cj6_","btn_wrapper":"index-module__btn_wrapper___1u0_m","btn":"index-module__btn___3VG3N","left":"index-module__left___3xTak","right":"index-module__right___1xsOT","disabled":"index-module__disabled___1vNFm","wm_tips":"index-module__wm_tips___19L0J","h3":"index-module__h3___nqRvT","p":"index-module__p___2nhod","guoshu":"index-module__guoshu___34EJb","page":"index-module__page___2Mxm6","top_banner":"index-module__top_banner___Zz9YZ","textbg":"index-module__textbg___HVBsO","top_banner_img":"index-module__top_banner_img___1nYwq"};

/***/ }),

/***/ "./src/pages/ele/index.scss":
/*!**********************************!*\
  !*** ./src/pages/ele/index.scss ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "./src/pages/ele/index.tsx":
/*!*********************************!*\
  !*** ./src/pages/ele/index.tsx ***!
  \*********************************/
/*! no exports provided */
/*! all exports used */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _tarojs_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @tarojs/runtime */ "./node_modules/@tarojs/runtime/dist/runtime.esm.js");
/* harmony import */ var _node_modules_tarojs_mini_runner_node_modules_babel_loader_lib_index_js_index_tsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib!./index.tsx */ "./node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib/index.js!./src/pages/ele/index.tsx");


var config = {"navigationBarTitleText":"饿了么","enableShareAppMessage":true,"navigationStyle":"custom"};

_node_modules_tarojs_mini_runner_node_modules_babel_loader_lib_index_js_index_tsx__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].enableShareAppMessage = true
var inst = Page(Object(_tarojs_runtime__WEBPACK_IMPORTED_MODULE_0__["createPageConfig"])(_node_modules_tarojs_mini_runner_node_modules_babel_loader_lib_index_js_index_tsx__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"], 'pages/ele/index', {}, config || {}))



/***/ })

},[["./src/pages/ele/index.tsx","runtime","taro","vendors","common"]]]);
//# sourceMappingURL=index.js.map