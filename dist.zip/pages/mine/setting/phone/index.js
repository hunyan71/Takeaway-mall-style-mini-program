(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([["pages/mine/setting/phone/index"],{

/***/ "./node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib/index.js!./src/pages/mine/setting/phone/index.tsx":
/*!*****************************************************************************************************************!*\
  !*** ./node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib!./src/pages/mine/setting/phone/index.tsx ***!
  \*****************************************************************************************************************/
/*! exports provided: default */
/*! exports used: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _tarojs_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @tarojs/components */ "./node_modules/@tarojs/components/mini/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @tarojs/taro */ "./node_modules/@tarojs/taro/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/cjs/react.production.min.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./index.module.scss */ "./src/pages/mine/setting/phone/index.module.scss");
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_3__);





var api = __webpack_require__(/*! ../../../../utils/utils.js */ "./src/utils/utils.js");

function Friends() {
  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_1__["useShareAppMessage"])(function () {
    return {};
  }); // "直邀粉丝", "间接粉丝"

  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_1__["useReady"])(function () {
    console.log("use ready");
  });
  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_1__["useDidShow"])(function () {});
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.setting
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.msg
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* Text */ "i"], null, "\u8BF7\u586B\u5199\u771F\u5B9E\u4FE1\u606F\uFF0C\u4EE5\u514D\u4F63\u91D1\u63D0\u73B0\u5F02\u5E38")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.form
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.item
  }, "\u624B\u673A\u53F7\u7801\uFF1A ", /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* Input */ "d"], {
    placeholder: "\u8BF7\u8F93\u5165\u771F\u5B9E\u624B\u673A\u53F7\u7801",
    value: ""
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.submit
  }, "\u786E\u5B9A")));
}

/* harmony default export */ __webpack_exports__["a"] = (Friends);

/***/ }),

/***/ "./src/pages/mine/setting/phone/index.module.scss":
/*!********************************************************!*\
  !*** ./src/pages/mine/setting/phone/index.module.scss ***!
  \********************************************************/
/*! no static exports found */
/*! exports used: default */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin
module.exports = {"setting":"index-module__setting___B5mU9","msg":"index-module__msg___28UFb","form":"index-module__form___dxZxb","item":"index-module__item___1q6gY","extra":"index-module__extra___3I2wW","submit":"index-module__submit___x0nlh"};

/***/ }),

/***/ "./src/pages/mine/setting/phone/index.tsx":
/*!************************************************!*\
  !*** ./src/pages/mine/setting/phone/index.tsx ***!
  \************************************************/
/*! no exports provided */
/*! all exports used */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _tarojs_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @tarojs/runtime */ "./node_modules/@tarojs/runtime/dist/runtime.esm.js");
/* harmony import */ var _node_modules_tarojs_mini_runner_node_modules_babel_loader_lib_index_js_index_tsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib!./index.tsx */ "./node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib/index.js!./src/pages/mine/setting/phone/index.tsx");


var config = {"navigationBarTitleText":"设置手机号码","enableShareAppMessage":true,"navigationBarBackgroundColor":"#e66465"};

_node_modules_tarojs_mini_runner_node_modules_babel_loader_lib_index_js_index_tsx__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].enableShareAppMessage = true
var inst = Page(Object(_tarojs_runtime__WEBPACK_IMPORTED_MODULE_0__["createPageConfig"])(_node_modules_tarojs_mini_runner_node_modules_babel_loader_lib_index_js_index_tsx__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"], 'pages/mine/setting/phone/index', {}, config || {}))



/***/ })

},[["./src/pages/mine/setting/phone/index.tsx","runtime","taro","vendors","common"]]]);
//# sourceMappingURL=index.js.map