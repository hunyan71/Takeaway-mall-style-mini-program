(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([["pages/mine/setting/alipay/index"],{

/***/ "./node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib/index.js!./src/pages/mine/setting/alipay/index.tsx":
/*!******************************************************************************************************************!*\
  !*** ./node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib!./src/pages/mine/setting/alipay/index.tsx ***!
  \******************************************************************************************************************/
/*! exports provided: default */
/*! exports used: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _tarojs_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @tarojs/components */ "./node_modules/@tarojs/components/mini/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @tarojs/taro */ "./node_modules/@tarojs/taro/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/cjs/react.production.min.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./index.module.scss */ "./src/pages/mine/setting/alipay/index.module.scss");
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_4__);






var api = __webpack_require__(/*! ../../../../utils/utils.js */ "./src/utils/utils.js");

function Friends() {
  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(""),
      _useState2 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState, 2),
      alipayName = _useState2[0],
      setAlipayName = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(""),
      _useState4 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState3, 2),
      alipayAccount = _useState4[0],
      setAlipayAccount = _useState4[1];

  var _useState5 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(false),
      _useState6 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState5, 2),
      hasSetAlipay = _useState6[0],
      setHasSetAlipay = _useState6[1];

  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useShareAppMessage"])(function () {
    return {};
  }); // "直邀粉丝", "间接粉丝"

  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useReady"])(function () {
    console.log("use ready");
  });
  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useDidShow"])(function () {
    setHasSetAlipay(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync("alipay_account") ? true : false);
    setAlipayName(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync("alipay_real_name") ? _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync("alipay_real_name") : "");
    setAlipayAccount(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync("alipay_account") ? _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync("alipay_account") : "");
  });

  var submit = function submit() {
    if (!alipayName.length) {
      _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.showToast({
        title: "请输入支付宝真实姓名",
        icon: "none"
      });
      return;
    }

    if (!alipayAccount.length) {
      _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.showToast({
        title: "请输入支付宝账户",
        icon: "none"
      });
      return;
    }

    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.showModal({
      title: "提现账户绑定后无法修改",
      content: "您的佣金将通过该账户结算给您，确定要绑定该支付宝账号吗？每个账户只能绑定一次哦！",
      success: function success(res) {
        if (res.confirm) {
          console.log("用户点击确定");
          requestUpdateAlipay();
        } else if (res.cancel) {
          console.log("用户点击取消");
        }
      }
    });
    console.log(alipayName + alipayAccount);
  };

  var requestUpdateAlipay = function requestUpdateAlipay() {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.request({
      url: api.updateAlipay,
      method: "POST",
      header: {
        'X-Nideshop-Token': _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync("token") || ""
      },
      data: {
        userid: _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync("userInfo").id,
        alipay_id: alipayAccount,
        alipay_name: alipayName,
        wxappid: api.WXAppID,
        v: api.VERSION
      },
      success: function success(res) {
        console.log(res);

        if (!res.data.errno) {
          _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.showToast({
            title: "绑定成功",
            icon: "none"
          });
          setTimeout(function () {
            _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.navigateBack();
          }, 3000);
        } else {
          _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.showToast({
            title: res.data.errmsg,
            icon: "none"
          });
        }
      }
    });
  };

  var handleInput_name = function handleInput_name(e) {
    setAlipayName(e.detail.value);
  };

  var handleInput_account = function handleInput_account(e) {
    setAlipayAccount(e.detail.value);
  };

  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useDidShow"])(function () {});
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.setting
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.msg
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], null, "\u8BF7\u586B\u5199\u771F\u5B9E\u4FE1\u606F\uFF0C\u4EE5\u514D\u4F63\u91D1\u63D0\u73B0\u5F02\u5E38")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.form
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.item
  }, "\u652F\u4ED8\u5B9D\u8D26\u6237\uFF1A", " ", /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Input */ "d"], {
    placeholder: "\u8BF7\u8F93\u5165\u652F\u4ED8\u5B9D\u8D26\u6237",
    onInput: handleInput_account,
    disabled: hasSetAlipay,
    value: alipayAccount
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.item
  }, "\u652F\u4ED8\u5B9D\u59D3\u540D\uFF1A", " ", /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Input */ "d"], {
    placeholder: "\u8BF7\u8F93\u5165\u652F\u4ED8\u5B9D\u771F\u5B9E\u59D3\u540D",
    value: alipayName,
    onInput: handleInput_name,
    disabled: hasSetAlipay
  })), hasSetAlipay ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.notice
  }, "\u5DF2\u7ED1\u5B9A\u652F\u4ED8\u5B9D\uFF0C\u65E0\u6CD5\u4FEE\u6539") : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.submit,
    onClick: submit
  }, "\u786E\u5B9A")));
}

/* harmony default export */ __webpack_exports__["a"] = (Friends);

/***/ }),

/***/ "./src/pages/mine/setting/alipay/index.module.scss":
/*!*********************************************************!*\
  !*** ./src/pages/mine/setting/alipay/index.module.scss ***!
  \*********************************************************/
/*! no static exports found */
/*! exports used: default */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin
module.exports = {"setting":"index-module__setting___1sJhg","msg":"index-module__msg___9qqqp","form":"index-module__form___3sNrv","item":"index-module__item___DlGMe","extra":"index-module__extra___3PgVJ","notice":"index-module__notice___1x1v9","submit":"index-module__submit___29hXT"};

/***/ }),

/***/ "./src/pages/mine/setting/alipay/index.tsx":
/*!*************************************************!*\
  !*** ./src/pages/mine/setting/alipay/index.tsx ***!
  \*************************************************/
/*! no exports provided */
/*! all exports used */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _tarojs_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @tarojs/runtime */ "./node_modules/@tarojs/runtime/dist/runtime.esm.js");
/* harmony import */ var _node_modules_tarojs_mini_runner_node_modules_babel_loader_lib_index_js_index_tsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib!./index.tsx */ "./node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib/index.js!./src/pages/mine/setting/alipay/index.tsx");


var config = {"navigationBarTitleText":"绑定支付宝账户","enableShareAppMessage":true,"navigationBarBackgroundColor":"#e66465"};

_node_modules_tarojs_mini_runner_node_modules_babel_loader_lib_index_js_index_tsx__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].enableShareAppMessage = true
var inst = Page(Object(_tarojs_runtime__WEBPACK_IMPORTED_MODULE_0__["createPageConfig"])(_node_modules_tarojs_mini_runner_node_modules_babel_loader_lib_index_js_index_tsx__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"], 'pages/mine/setting/alipay/index', {}, config || {}))



/***/ })

},[["./src/pages/mine/setting/alipay/index.tsx","runtime","taro","vendors","common"]]]);
//# sourceMappingURL=index.js.map