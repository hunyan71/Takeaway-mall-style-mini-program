(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([["pages/mine/setting/index"],{

/***/ "./node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib/index.js!./src/pages/mine/setting/index.tsx":
/*!***********************************************************************************************************!*\
  !*** ./node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib!./src/pages/mine/setting/index.tsx ***!
  \***********************************************************************************************************/
/*! exports provided: default */
/*! exports used: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _tarojs_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @tarojs/components */ "./node_modules/@tarojs/components/mini/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @tarojs/taro */ "./node_modules/@tarojs/taro/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/cjs/react.production.min.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./index.module.scss */ "./src/pages/mine/setting/index.module.scss");
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! classnames */ "./node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_4__);







var api = __webpack_require__(/*! ../../../utils/utils.js */ "./src/utils/utils.js");

function Friends() {
  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_1__["useShareAppMessage"])(function () {
    return {};
  }); // "直邀粉丝", "间接粉丝"

  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_1__["useReady"])(function () {
    console.log("use ready");
  });
  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_1__["useDidShow"])(function () {});
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* View */ "j"], {
    className: classnames__WEBPACK_IMPORTED_MODULE_4___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.setting_takeout, _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.animated, _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.fadeIn])
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.content
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.cell_group
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.cell_item
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.left
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.icon_wrapper
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* Image */ "c"], {
    className: classnames__WEBPACK_IMPORTED_MODULE_4___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.icon_img, _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.icon_avatar]),
    mode: "widthFix",
    src: "https://mpstatic.qingting123.com/img/weapp-mine/setting-avatar.png"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.label
  }, "\u5934\u50CF")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.right
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* OpenData */ "e"], {
    type: "userAvatarUrl",
    className: classnames__WEBPACK_IMPORTED_MODULE_4___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.icon_img, _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.icon_avatar])
  }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.cell_item
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.left
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.icon_wrapper
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* Image */ "c"], {
    className: classnames__WEBPACK_IMPORTED_MODULE_4___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.icon_img, _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.icon_nickname]),
    mode: "widthFix",
    src: "https://mpstatic.qingting123.com/img/weapp-mine/setting-nickname.png"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.label
  }, "\u5FAE\u4FE1\u6635\u79F0")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.right
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* Text */ "i"], {
    className: classnames__WEBPACK_IMPORTED_MODULE_4___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.item, _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.item_value])
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* OpenData */ "e"], {
    type: "userNickName"
  })))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.cell_item,
    onClick: function onClick() {
      return _tarojs_taro__WEBPACK_IMPORTED_MODULE_1___default.a.navigateTo({
        url: './phone/index'
      });
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.left
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.icon_wrapper
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* Image */ "c"], {
    className: classnames__WEBPACK_IMPORTED_MODULE_4___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.icon_img, _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.icon_phone]),
    mode: "widthFix",
    src: "https://mpstatic.qingting123.com/img/weapp-mine/setting-phone.png"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.label
  }, "\u624B\u673A\u53F7")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.right
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* Text */ "i"], {
    className: classnames__WEBPACK_IMPORTED_MODULE_4___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.item, _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.item_value])
  }, "\u586B\u5199\u624B\u673A\u53F7")))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.cell_group,
    onClick: function onClick() {
      return _tarojs_taro__WEBPACK_IMPORTED_MODULE_1___default.a.navigateTo({
        url: './alipay/index'
      });
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* View */ "j"], {
    className: classnames__WEBPACK_IMPORTED_MODULE_4___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.cell_item, _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.icon_phone])
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.left
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.icon_wrapper
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* Text */ "i"], {
    className: classnames__WEBPACK_IMPORTED_MODULE_4___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.icon_font, _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.iconfont_alipay])
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.label
  }, "\u652F\u4ED8\u5B9D")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.right
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_0__[/* Text */ "i"], {
    className: classnames__WEBPACK_IMPORTED_MODULE_4___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.item, _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default.a.item_value])
  }, "\u7ED1\u5B9A\u652F\u4ED8\u5B9D"))))));
}

/* harmony default export */ __webpack_exports__["a"] = (Friends);

/***/ }),

/***/ "./src/pages/mine/setting/index.module.scss":
/*!**************************************************!*\
  !*** ./src/pages/mine/setting/index.module.scss ***!
  \**************************************************/
/*! no static exports found */
/*! exports used: default */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin
module.exports = {"iconfont":"index-module__iconfont___hy4w6","icon-success":"index-module__icon-success____sCic","icon-correct":"index-module__icon-correct___2dxhy","icon-error":"index-module__icon-error___2tYyP","icon-received":"index-module__icon-received___1_4w8","icon-profit":"index-module__icon-profit___3v8lC","icon-clock":"index-module__icon-clock___MlxyR","icon-search":"index-module__icon-search___slflE","icon-wechat":"index-module__icon-wechat___CL439","icon-pay":"index-module__icon-pay___2Uog0","icon-after-sale":"index-module__icon-after-sale___1pJpr","icon-package":"index-module__icon-package___2JUDc","icon-delivery":"index-module__icon-delivery___1xjtS","icon-order":"index-module__icon-order___1WKFX","icon-address":"index-module__icon-address___2se6z","icon-service":"index-module__icon-service___1W73D","icon-locate":"index-module__icon-locate___2JHu8","icon-close":"index-module__icon-close___1WKwA","icon-edit":"index-module__icon-edit___2Raej","icon-delete":"index-module__icon-delete___2gMt7","icon-select":"index-module__icon-select___2B2qM","icon-copy":"index-module__icon-copy___11yGN","icon-zan":"index-module__icon-zan___ASjRe","icon-download":"index-module__icon-download___3fAl4","icon-next":"index-module__icon-next___aimBV","bounce":"index-module__bounce___3QRHl","flash":"index-module__flash___OBTGD","pulse":"index-module__pulse___vS48C","rubberBand":"index-module__rubberBand___2gVnL","shake":"index-module__shake___oMAWT","headShake":"index-module__headShake___35JdY","swing":"index-module__swing___1Rd76","tada":"index-module__tada___1fPrn","wobble":"index-module__wobble___338kS","jello":"index-module__jello___32a5-","heartBeat":"index-module__heartBeat___1GiEz","bounceIn":"index-module__bounceIn___3V25b","bounceInDown":"index-module__bounceInDown___3U2kQ","bounceInLeft":"index-module__bounceInLeft___QReTl","bounceInRight":"index-module__bounceInRight___1tg2Z","bounceInUp":"index-module__bounceInUp___-M4KI","bounceOut":"index-module__bounceOut___2uq7Y","bounceOutDown":"index-module__bounceOutDown___1lffX","bounceOutLeft":"index-module__bounceOutLeft___2EQhu","bounceOutRight":"index-module__bounceOutRight___27tHo","bounceOutUp":"index-module__bounceOutUp___3nSDh","fadeIn":"index-module__fadeIn___oRcgm","fadeInDown":"index-module__fadeInDown___rn-Jd","fadeInDownBig":"index-module__fadeInDownBig___yKemj","fadeInLeft":"index-module__fadeInLeft___3ecE0","fadeInLeftBig":"index-module__fadeInLeftBig___-b0V_","fadeInRight":"index-module__fadeInRight___141ML","fadeInRightBig":"index-module__fadeInRightBig___1njoq","fadeInUp":"index-module__fadeInUp___2ftNh","fadeInUpBig":"index-module__fadeInUpBig___2OBGe","fadeOut":"index-module__fadeOut___O7BHK","fadeOutDown":"index-module__fadeOutDown___sgnbW","fadeOutDownBig":"index-module__fadeOutDownBig___1Go6N","fadeOutLeft":"index-module__fadeOutLeft___37wc7","fadeOutLeftBig":"index-module__fadeOutLeftBig___P0z6N","fadeOutRight":"index-module__fadeOutRight___3m8gb","fadeOutRightBig":"index-module__fadeOutRightBig___1fJRC","fadeOutUp":"index-module__fadeOutUp___8FKCK","fadeOutUpBig":"index-module__fadeOutUpBig___ujcLJ","animated":"index-module__animated___2N_6l","flip":"index-module__flip___RqA0Z","flipInX":"index-module__flipInX___25wWJ","flipInY":"index-module__flipInY___2YBhA","flipOutX":"index-module__flipOutX___GLtw1","flipOutY":"index-module__flipOutY___3-buI","lightSpeedIn":"index-module__lightSpeedIn___wT9ak","lightSpeedOut":"index-module__lightSpeedOut___2g8pz","rotateIn":"index-module__rotateIn___3B208","rotateInDownLeft":"index-module__rotateInDownLeft___1iLTI","rotateInDownRight":"index-module__rotateInDownRight___14bf8","rotateInUpLeft":"index-module__rotateInUpLeft___2FEEf","rotateInUpRight":"index-module__rotateInUpRight___3-0nd","rotateOut":"index-module__rotateOut___30oTW","rotateOutDownLeft":"index-module__rotateOutDownLeft___MhI3U","rotateOutDownRight":"index-module__rotateOutDownRight___22KrN","rotateOutUpLeft":"index-module__rotateOutUpLeft___LZEGh","rotateOutUpRight":"index-module__rotateOutUpRight___26xtO","hinge":"index-module__hinge___3VR8P","jackInTheBox":"index-module__jackInTheBox___3vKyV","rollIn":"index-module__rollIn___1uG3r","rollOut":"index-module__rollOut___2wbzJ","zoomIn":"index-module__zoomIn___eZXDJ","zoomInDown":"index-module__zoomInDown___1jT0b","zoomInLeft":"index-module__zoomInLeft___37RtJ","zoomInRight":"index-module__zoomInRight___29BJH","zoomInUp":"index-module__zoomInUp___2BErg","zoomOut":"index-module__zoomOut___3DlIn","zoomOutDown":"index-module__zoomOutDown___1XOa5","zoomOutLeft":"index-module__zoomOutLeft___3hFKr","zoomOutRight":"index-module__zoomOutRight___8x7Kj","zoomOutUp":"index-module__zoomOutUp___1djma","slideInDown":"index-module__slideInDown___12cs4","slideInLeft":"index-module__slideInLeft___3iTY3","slideInRight":"index-module__slideInRight___2wf2z","slideInUp":"index-module__slideInUp___2mg0e","slideOutDown":"index-module__slideOutDown___P_IF8","slideOutLeft":"index-module__slideOutLeft___3zFXI","slideOutRight":"index-module__slideOutRight___3LeI9","slideOutUp":"index-module__slideOutUp___2qlT8","infinite":"index-module__infinite___1ZF8t","delay-1s":"index-module__delay-1s___3A_Jj","delay-2s":"index-module__delay-2s___2L1tN","delay-3s":"index-module__delay-3s___1OwIK","delay-4s":"index-module__delay-4s___2iGVB","delay-5s":"index-module__delay-5s___3-FRn","fast":"index-module__fast___292nC","faster":"index-module__faster___BSQLP","slow":"index-module__slow___11xXF","slower":"index-module__slower___Slg26","icon-font":"index-module__icon-font___3rak7","iconfont-pdd":"index-module__iconfont-pdd___1updd","iconfont-jingdong":"index-module__iconfont-jingdong___JWogh","iconfont-tao":"index-module__iconfont-tao___B8wRr","iconfont-lock":"index-module__iconfont-lock___2qTtc","iconfont_wechat1":"index-module__iconfont_wechat1___3aq-E","iconfont-apple":"index-module__iconfont-apple___1M2iE","iconfont-arrow":"index-module__iconfont-arrow___D52yB","iconfont-share":"index-module__iconfont-share___2gigJ","iconfont-download":"index-module__iconfont-download___3Df2p","iconfont-earn":"index-module__iconfont-earn___1Y87B","iconfont-shopping-cart":"index-module__iconfont-shopping-cart___3dozA","iconfont-copy":"index-module__iconfont-copy___1bIfi","iconfont-timeline":"index-module__iconfont-timeline___3-KEb","iconfont-refresh":"index-module__iconfont-refresh___16fRW","iconfont-mini-program":"index-module__iconfont-mini-program___37Koa","iconfont_wechat":"index-module__iconfont_wechat___1cIsv","iconfont_alipay":"index-module__iconfont_alipay___1r86x","setting_takeout":"index-module__setting_takeout___3q_gq","content":"index-module__content___1K239","cell_group":"index-module__cell_group___2iUQ-","cell_item":"index-module__cell_item___WkXpU","left":"index-module__left___39_o-","icon_wrapper":"index-module__icon_wrapper___127dr","right":"index-module__right___3CjfM","icon_img":"index-module__icon_img___1-eUK","icon_avatar":"index-module__icon_avatar___1S0MH","icon_nickname":"index-module__icon_nickname___2cBnw","icon_phone":"index-module__icon_phone___-82oT","icon_font":"index-module__icon_font___1Sdn8","iconfont_mini_program":"index-module__iconfont_mini_program___3K_Vq","label":"index-module__label___x-99c","item":"index-module__item___1ZjWW","item_img":"index-module__item_img___3pxRR","item_value":"index-module__item_value___1NDGV","refresh_btn":"index-module__refresh_btn___WVFBK","setting":"index-module__setting___1TR8E","group":"index-module__group___3Km0v","logout":"index-module__logout___N6Chv","wrap":"index-module__wrap___1j2_P","value":"index-module__value___2IIAi","right_icon":"index-module__right_icon___2S2LV","open_type":"index-module__open_type___3oIBx","line":"index-module__line___3kaEh"};

/***/ }),

/***/ "./src/pages/mine/setting/index.tsx":
/*!******************************************!*\
  !*** ./src/pages/mine/setting/index.tsx ***!
  \******************************************/
/*! no exports provided */
/*! all exports used */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _tarojs_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @tarojs/runtime */ "./node_modules/@tarojs/runtime/dist/runtime.esm.js");
/* harmony import */ var _node_modules_tarojs_mini_runner_node_modules_babel_loader_lib_index_js_index_tsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib!./index.tsx */ "./node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib/index.js!./src/pages/mine/setting/index.tsx");


var config = {"navigationBarTitleText":"个人信息","enableShareAppMessage":true,"navigationBarBackgroundColor":"#e66465"};

_node_modules_tarojs_mini_runner_node_modules_babel_loader_lib_index_js_index_tsx__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].enableShareAppMessage = true
var inst = Page(Object(_tarojs_runtime__WEBPACK_IMPORTED_MODULE_0__["createPageConfig"])(_node_modules_tarojs_mini_runner_node_modules_babel_loader_lib_index_js_index_tsx__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"], 'pages/mine/setting/index', {}, config || {}))



/***/ })

},[["./src/pages/mine/setting/index.tsx","runtime","taro","vendors","common"]]]);
//# sourceMappingURL=index.js.map