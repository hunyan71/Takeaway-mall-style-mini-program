(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([["pages/mine/cash/index"],{

/***/ "./node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib/index.js!./src/pages/mine/cash/index.tsx":
/*!********************************************************************************************************!*\
  !*** ./node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib!./src/pages/mine/cash/index.tsx ***!
  \********************************************************************************************************/
/*! exports provided: default */
/*! exports used: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _tarojs_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @tarojs/components */ "./node_modules/@tarojs/components/mini/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @tarojs/taro */ "./node_modules/@tarojs/taro/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _component_loginComponet_index__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../component/loginComponet/index */ "./src/component/loginComponet/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "./node_modules/react/cjs/react.production.min.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./index.module.scss */ "./src/pages/mine/cash/index.module.scss");
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_5__);







var api = __webpack_require__(/*! ../../../utils/utils.js */ "./src/utils/utils.js");

function Friends() {
  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useShareAppMessage"])(function () {
    return {};
  });

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(0),
      _useState2 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState, 2),
      sum_yijiesuan = _useState2[0],
      setSum_yijiesuan = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(0),
      _useState4 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState3, 2),
      sum_paid = _useState4[0],
      setSum_paid = _useState4[1];

  var _useState5 = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(0),
      _useState6 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState5, 2),
      withdraw_lowest = _useState6[0],
      setWithdraw_lowest = _useState6[1];

  var _useState7 = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(),
      _useState8 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState7, 2),
      hasShowLogin = _useState8[0],
      setHasShowLogin = _useState8[1];

  var _useState9 = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(true),
      _useState10 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState9, 2),
      inReview = _useState10[0],
      setInReview = _useState10[1];

  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useReady"])(function () {
    console.log("use ready");
    requestAppInfo();
  });

  var handleLoginMethod = function handleLoginMethod() {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorage({
      key: "token",
      success: function success(res) {
        setHasShowLogin(false);
      },
      fail: function fail(res) {
        setHasShowLogin(true);
      }
    });
  };

  var requestAppInfo = function requestAppInfo() {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.request({
      url: api.IndexUrl,
      header: {
        "X-Nideshop-Token": _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync("token") || ""
      },
      data: {
        userid: _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync("userInfo").id,
        wxappid: api.WXAppID,
        v: api.VERSION
      },
      success: function success(res) {
        console.log(parseInt(res.data.data.inreview));
        setInReview(parseInt(res.data.data.inreview) ? true : false);

        if (!parseInt(res.data.data.inreview)) {
          requestWithDrawInfo();
        }
      },
      fail: function fail() {}
    });
  };

  var parentMethod = function parentMethod(result) {
    setHasShowLogin(false);
    requestWithDrawInfo();
  };

  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useDidShow"])(function () {
    requestWithDrawInfo();
    handleLoginMethod();
  });

  var requestWithDrawInfo = function requestWithDrawInfo() {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.showLoading({
      title: "加载中"
    });
    setTimeout(function () {
      _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.hideLoading();
    }, 5000);
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.request({
      url: api.WithDrawInfo,
      header: {
        'X-Nideshop-Token': _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync("token") || ""
      },
      data: {
        userid: _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync("userInfo").id,
        wxappid: api.WXAppID,
        v: api.VERSION
      },
      success: function success(res) {
        _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.hideLoading();
        console.log(res);
        setSum_yijiesuan(res.data.data.sum_yijiesuan);
        setSum_paid(res.data.data.sum_paid);
        setWithdraw_lowest(res.data.data.withdraw_lowest);
      }
    });
  };

  var handleWithDraw = function handleWithDraw() {
    if (sum_yijiesuan < withdraw_lowest) {
      _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.showToast({
        title: "满" + withdraw_lowest + "元可提",
        icon: "none"
      });
      return;
    }

    requestWithDraw();
  };

  var requestWithDraw = function requestWithDraw() {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.showLoading({
      title: "加载中"
    });
    setTimeout(function () {
      _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.hideLoading();
    }, 5000);
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.request({
      url: api.EstablishWithDraw,
      header: {
        'X-Nideshop-Token': _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync("token") || ""
      },
      data: {
        userid: _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync("userInfo").id,
        wxappid: api.WXAppID,
        v: api.VERSION
      },
      success: function success(res) {
        _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.hideLoading();
        console.log(res);
        _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.hideLoading();

        if (!res.data.errno) {
          _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.showToast({
            title: res.data.data,
            icon: "none"
          });
          setTimeout(function () {
            _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.navigateBack();
          }, 3000);
        } else {
          _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.showToast({
            title: res.data.errmsg,
            icon: "none"
          });
        }
      },
      fail: function fail() {
        _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.showToast({
          title: "请求失败，稍候再试",
          icon: "none"
        });
      }
    });
  };

  return inReview ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], null, "\u6682\u65E0\u6570\u636E") : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_5___default.a.cash
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], null, hasShowLogin ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(_component_loginComponet_index__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"], {
    parentMethod: parentMethod.bind(this)
  }) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], null), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_5___default.a.sum
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_5___default.a.gray
  }, "\u8D26\u6237\u5269\u4F59"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_5___default.a.red
  }, sum_yijiesuan), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_5___default.a.gray
  }, "\u5143\uFF0C\u7D2F\u8BA1\u63D0\u73B0"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_5___default.a.green
  }, sum_paid), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_5___default.a.gray
  }, "\u5143")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_5___default.a.exchange
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_5___default.a.tip
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], null, "\u8BF7\u8F93\u5165\u63D0\u73B0\u91D1\u989D\uFF0C\u6EE1", withdraw_lowest, "\u5143\u53EF\u63D0\u73B0")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Input */ "d"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_5___default.a.input,
    placeholder: "0.00",
    value: sum_yijiesuan
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_5___default.a.button,
    onClick: function onClick() {
      return handleWithDraw();
    }
  }, "\u7533\u8BF7\u7ED3\u7B97")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_5___default.a.rule
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_5___default.a.header
  }, "\u7ED3\u7B97\u89C4\u5219"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_5___default.a.body
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_5___default.a.p
  }, "1.\u6EE1", withdraw_lowest, "\u5143\u53EF\u7ED3\u7B97\uFF1B"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_5___default.a.p
  }, "2.\u6BCF\u670822\u65E5\u4E3A\u7ED3\u7B97\u65E5\uFF0C\u5176\u4F59\u65F6\u95F4\u6682\u4E0D\u652F\u6301\u63D0\u73B0\uFF08\u6B63\u5728\u52AA\u529B\u4FEE\u6539\u652F\u6301\u6BCF\u65E5\u7ED3\u7B97\uFF09\u3002"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_5___default.a.p
  }, "3.\u63D0\u73B0200\u5143\u4EE5\u4E0A\u8054\u7CFB\u5BA2\u670D\u786E\u8BA4\uFF1B")))));
}

/* harmony default export */ __webpack_exports__["a"] = (Friends);

/***/ }),

/***/ "./src/pages/mine/cash/index.module.scss":
/*!***********************************************!*\
  !*** ./src/pages/mine/cash/index.module.scss ***!
  \***********************************************/
/*! no static exports found */
/*! exports used: default */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin
module.exports = {"cash":"index-module__cash___3YDo1","sum":"index-module__sum___7Aijh","tabs":"index-module__tabs___2Q99L","item":"index-module__item___1DzjW","active":"index-module__active___289aD","gray":"index-module__gray___1CwGV","green":"index-module__green___7S5s2","red":"index-module__red___2dRnp","exchange":"index-module__exchange___3-rWI","rule":"index-module__rule___3WaP9","tip":"index-module__tip___6vdxt","input":"index-module__input___3gL4h","button":"index-module__button___2HBcc","scroll":"index-module__scroll___33TZ2","info":"index-module__info___UBScK","time":"index-module__time___2hs1W","count":"index-module__count___31Bwx","number":"index-module__number___rha5t","reduce":"index-module__reduce___weMs5","plus":"index-module__plus___RFO92","status":"index-module__status___JzCks","wait":"index-module__wait___1Q8Gq","fail":"index-module__fail___3q9k0","content":"index-module__content___f6HFK","last":"index-module__last___3J5vi","ml":"index-module__ml___8I2TY","header":"index-module__header___2Z_N0","body":"index-module__body___E93bI","p":"index-module__p___1VUy-","at-modal__container":"index-module__at-modal__container___3rnTu","at-modal__content":"index-module__at-modal__content___1WWTP","left":"index-module__left___rrHqd","right":"index-module__right___3MMdS"};

/***/ }),

/***/ "./src/pages/mine/cash/index.tsx":
/*!***************************************!*\
  !*** ./src/pages/mine/cash/index.tsx ***!
  \***************************************/
/*! no exports provided */
/*! all exports used */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _tarojs_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @tarojs/runtime */ "./node_modules/@tarojs/runtime/dist/runtime.esm.js");
/* harmony import */ var _node_modules_tarojs_mini_runner_node_modules_babel_loader_lib_index_js_index_tsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib!./index.tsx */ "./node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib/index.js!./src/pages/mine/cash/index.tsx");


var config = {"navigationBarTitleText":"结算","enableShareAppMessage":true,"navigationBarBackgroundColor":"#e66465"};

_node_modules_tarojs_mini_runner_node_modules_babel_loader_lib_index_js_index_tsx__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].enableShareAppMessage = true
var inst = Page(Object(_tarojs_runtime__WEBPACK_IMPORTED_MODULE_0__["createPageConfig"])(_node_modules_tarojs_mini_runner_node_modules_babel_loader_lib_index_js_index_tsx__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"], 'pages/mine/cash/index', {}, config || {}))



/***/ })

},[["./src/pages/mine/cash/index.tsx","runtime","taro","vendors","common"]]]);
//# sourceMappingURL=index.js.map