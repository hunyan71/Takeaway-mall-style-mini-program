(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([["pages/mine/orders/index"],{

/***/ "./node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib/index.js!./src/pages/mine/orders/index.tsx":
/*!**********************************************************************************************************!*\
  !*** ./node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib!./src/pages/mine/orders/index.tsx ***!
  \**********************************************************************************************************/
/*! exports provided: default */
/*! exports used: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _tarojs_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @tarojs/components */ "./node_modules/@tarojs/components/mini/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @tarojs/taro */ "./node_modules/@tarojs/taro/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/cjs/react.production.min.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./index.module.scss */ "./src/pages/mine/orders/index.module.scss");
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! classnames */ "./node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _component_CustomNavBar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../component/CustomNavBar */ "./src/component/CustomNavBar/index.tsx");








var api = __webpack_require__(/*! ../../../utils/utils.js */ "./src/utils/utils.js");

function Friends() {
  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useShareAppMessage"])(function () {
    return {};
  }); // "直邀粉丝", "间接粉丝"

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])([{
    title: "全部",
    active: 1
  }, {
    title: "待收货",
    active: 0
  }, {
    title: "待结算",
    active: 0
  }, {
    title: "已结算",
    active: 0
  }]),
      _useState2 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState, 2),
      tabs = _useState2[0],
      setTabs = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(0),
      _useState4 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState3, 2),
      selectNavIndex = _useState4[0],
      setSelectNavIndex = _useState4[1];

  var _useState5 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(0),
      _useState6 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState5, 2),
      selectTabIndex = _useState6[0],
      setSelectTabIndex = _useState6[1];

  var _useState7 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])([]),
      _useState8 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState7, 2),
      orderslist = _useState8[0],
      setOrderslist = _useState8[1];

  var _useState9 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(1),
      _useState10 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState9, 2),
      page = _useState10[0],
      setPage = _useState10[1];

  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useReady"])(function () {
    console.log("use ready");
  });
  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useDidShow"])(function () {
    requestOrderList(selectTabIndex, false);
  });

  var handleClick = function handleClick(index) {
    console.log("nav选择" + index);
    setSelectNavIndex(index);
    index ? requestMeituanOrderList(selectTabIndex, false) : requestOrderList(selectTabIndex, false);
  };

  var changeTab = function changeTab(index) {
    console.log("tab " + index);
    setSelectTabIndex(index);
    selectNavIndex ? requestMeituanOrderList(index, false) : requestOrderList(index, false);
  };

  var requestMeituanOrderList = function requestMeituanOrderList(index, load_more) {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.showLoading({
      title: "加载中"
    });
    setTimeout(function () {
      _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.hideLoading();
    }, 5000);
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.request({
      url: api.meituanOrdersList,
      header: {
        'X-Nideshop-Token': _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync("token") || ""
      },
      data: {
        status: index,
        userid: _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync("userInfo").id,
        page: page,
        wxappid: api.WXAppID,
        v: api.VERSION
      },
      success: function success(res) {
        _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.hideLoading();
        load_more ? setOrderslist(orderslist.concat(res.data.data)) : setOrderslist(res.data.data);
        console.log(res);
      },
      fail: function fail() {
        _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.hideLoading();
      }
    });
  };

  var requestOrderList = function requestOrderList(index, load_more) {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.showLoading({
      title: "加载中"
    });
    setTimeout(function () {
      _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.hideLoading();
    }, 5000);
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.request({
      url: api.elemeOrdersList,
      header: {
        'X-Nideshop-Token': _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync("token") || ""
      },
      data: {
        status: index,
        userid: _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync("userInfo").id,
        page: page,
        wxappid: api.WXAppID,
        v: api.VERSION
      },
      success: function success(res) {
        _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.hideLoading();
        load_more ? setOrderslist(orderslist.concat(res.data.data)) : setOrderslist(res.data.data);
        console.log(res);
      },
      fail: function fail() {
        _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.hideLoading();
      }
    });
  }; //触底


  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useReachBottom"])(function () {
    setPage(page + 1);
    selectNavIndex ? requestMeituanOrderList(selectTabIndex, true) : requestOrderList(selectTabIndex, true);
  }); //12已付款， 13已失效 14已收货 3结算成功

  function orderStatusString(status) {
    status = parseInt(status);

    if (status == 3) {
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
        className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.status, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.pay])
      }, "\u5DF2\u7ED3\u7B97");
    } else if (status == 12) {
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
        className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.status, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.pay])
      }, "\u5DF2\u4ED8\u6B3E");
    } else if (status == 14) return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.status, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.confirm])
    }, "\u5DF2\u786E\u8BA4\u6536\u8D27");else return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.status, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.confirm])
    }, "\u5DF2\u5931\u6548");
  } //1已付款， 8 已完成 9 已退款


  function meituanOrderStatusString(status) {
    status = parseInt(status);

    if (status == 8) {
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
        className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.status, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.pay])
      }, "\u5DF2\u7ED3\u7B97");
    } else if (status == 1) {
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
        className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.status, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.pay])
      }, "\u5DF2\u4ED8\u6B3E");
    } else return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.status, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.confirm])
    }, "\u5DF2\u5931\u6548");
  }

  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.order
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_component_CustomNavBar__WEBPACK_IMPORTED_MODULE_6__[/* default */ "a"], {
    background: "#e66465",
    backgroundColorTop: "#e66465",
    back: true,
    renderCenter: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.nav_bar_tabs
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: selectNavIndex === 0 ? classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.item, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.active]) : _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.item,
      onClick: function onClick() {
        return handleClick(0);
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.title
    }, "\u997F\u4E86\u4E48")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: selectNavIndex === 1 ? classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.item, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.active]) : _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.item,
      onClick: function onClick() {
        return handleClick(1);
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.title
    }, "\u7F8E\u56E2")))
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.tabs_wrapper
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.tabs])
  }, tabs.map(function (v, i) {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: selectTabIndex === i ? classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.item, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.active]) : _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.item,
      onClick: function onClick() {
        return changeTab(i);
      }
    }, v.title);
  }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.orders
  }, orderslist.length > 0 ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], null) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.empty
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.empty_text
  }, "\u6682\u65E0\u6570\u636E")), selectNavIndex ? orderslist.map(function (item, i) {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.item
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.img,
      src: "https://img.mybei.cn/meituan_logo.png"
    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.content
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.title
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], null, item.smstitle)), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.info, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.flex])
    }, meituanOrderStatusString(item.status)), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.time
    }, item.paytime, " \u521B\u5EFA")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.money
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.wrap
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
      className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.text, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.grey])
    }, "\u4ED8\u6B3E\u91D1\u989D"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
      className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.text, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.dark])
    }, "\uFFE5", item.payprice)), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.wrap
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
      className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.text, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.grey])
    }, "\u6211\u7684\u4F63\u91D1"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
      className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.text, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.dark])
    }, "\uFFE5", item.arrangement_fee)), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.wrap
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
      className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.text, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.grey])
    }, "\u63A8\u5E7F\u4EBA"), item.agent_type == 1 ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
      className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.text, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.dark])
    }, "\u81EA\u5DF1") : item.agent_type == 2 ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
      className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.text, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.red])
    }, "\u597D\u53CB") : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
      className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.text, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.orange])
    }, "\u95F4\u63A5\u597D\u53CB")))));
  }) : orderslist.map(function (item, i) {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.item
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.img,
      src: item.item_img
    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.content
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.title
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], null, item.item_title)), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.info, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.flex])
    }, orderStatusString(item.status)), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.time
    }, item.tk_create_time, " \u521B\u5EFA")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.money
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.wrap
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
      className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.text, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.grey])
    }, "\u4ED8\u6B3E\u91D1\u989D"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
      className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.text, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.dark])
    }, "\uFFE5", item.pay_price)), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.wrap
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
      className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.text, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.grey])
    }, "\u6211\u7684\u4F63\u91D1"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
      className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.text, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.dark])
    }, "\uFFE5", item.arrangement_fee)), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.wrap
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
      className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.text, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.grey])
    }, "\u63A8\u5E7F\u4EBA"), item.agent_type == 1 ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
      className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.text, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.dark])
    }, "\u81EA\u5DF1") : item.agent_type == 2 ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
      className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.text, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.red])
    }, "\u597D\u53CB") : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
      className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.text, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.orange])
    }, "\u95F4\u63A5\u597D\u53CB")))));
  })));
}

/* harmony default export */ __webpack_exports__["a"] = (Friends);

/***/ }),

/***/ "./src/pages/mine/orders/index.module.scss":
/*!*************************************************!*\
  !*** ./src/pages/mine/orders/index.module.scss ***!
  \*************************************************/
/*! no static exports found */
/*! exports used: default */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin
module.exports = {"order":"index-module__order___3Ii0g","nav_bar_tabs":"index-module__nav_bar_tabs___3b9lv","item":"index-module__item___uQrnc","title":"index-module__title___1gMQF","active":"index-module__active___eFX3j","tabs-wrapper":"index-module__tabs-wrapper___vH6AU","placeholder":"index-module__placeholder___2IZRp","tabs":"index-module__tabs___3pgEi","fixed":"index-module__fixed___2F2Nf","source":"index-module__source___36Squ","text":"index-module__text___2F6aO","border":"index-module__border___3VdBO","tips":"index-module__tips___xZwuD","grey":"index-module__grey___2vi6G","orange":"index-module__orange___3_-Y5","red":"index-module__red___34us2","orders":"index-module__orders___1FUNu","sum":"index-module__sum___3o40X","count":"index-module__count___2i7TZ","label":"index-module__label___1eoTH","highlight":"index-module__highlight___2Ppfm","number":"index-module__number___BGwgv","last_time":"index-module__last_time___1eIsH","icon":"index-module__icon___3WjFO","link":"index-module__link___2z6c4","img":"index-module__img___3mWw4","content":"index-module__content___mqzrt","goods_origin":"index-module__goods_origin___29yXQ","order_type":"index-module__order_type___2S-qY","info":"index-module__info___2o7lC","flex":"index-module__flex___1RUcR","status":"index-module__status___1h8E9","confirm":"index-module__confirm___2ws4I","pay":"index-module__pay___1uDVc","time":"index-module__time___2ILKZ","sub_tabs":"index-module__sub_tabs___1OMM1","wrap":"index-module__wrap___2OVfM","money":"index-module__money___2MVjI","empty":"index-module__empty___fzXdG","empty_text":"index-module__empty_text___1imND","dark":"index-module__dark___3iVni","tab":"index-module__tab___1DfnL","date":"index-module__date___3IAMN","line":"index-module__line___28mUR","hover":"index-module__hover___1XPMf","space":"index-module__space___fh8o6","small":"index-module__small___2to43"};

/***/ }),

/***/ "./src/pages/mine/orders/index.tsx":
/*!*****************************************!*\
  !*** ./src/pages/mine/orders/index.tsx ***!
  \*****************************************/
/*! no exports provided */
/*! all exports used */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _tarojs_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @tarojs/runtime */ "./node_modules/@tarojs/runtime/dist/runtime.esm.js");
/* harmony import */ var _node_modules_tarojs_mini_runner_node_modules_babel_loader_lib_index_js_index_tsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib!./index.tsx */ "./node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib/index.js!./src/pages/mine/orders/index.tsx");


var config = {"navigationBarTitleText":"我的团队","enableShareAppMessage":true,"navigationBarBackgroundColor":"#e66465","navigationStyle":"custom"};

_node_modules_tarojs_mini_runner_node_modules_babel_loader_lib_index_js_index_tsx__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].enableShareAppMessage = true
var inst = Page(Object(_tarojs_runtime__WEBPACK_IMPORTED_MODULE_0__["createPageConfig"])(_node_modules_tarojs_mini_runner_node_modules_babel_loader_lib_index_js_index_tsx__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"], 'pages/mine/orders/index', {}, config || {}))



/***/ })

},[["./src/pages/mine/orders/index.tsx","runtime","taro","vendors","common"]]]);
//# sourceMappingURL=index.js.map