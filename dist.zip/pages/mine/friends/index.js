(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([["pages/mine/friends/index"],{

/***/ "./node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib/index.js!./src/pages/mine/friends/index.tsx":
/*!***********************************************************************************************************!*\
  !*** ./node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib!./src/pages/mine/friends/index.tsx ***!
  \***********************************************************************************************************/
/*! exports provided: default */
/*! exports used: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _tarojs_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @tarojs/components */ "./node_modules/@tarojs/components/mini/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @tarojs/taro */ "./node_modules/@tarojs/taro/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/cjs/react.production.min.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./index.module.scss */ "./src/pages/mine/friends/index.module.scss");
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! classnames */ "./node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_5__);







var api = __webpack_require__(/*! ../../../utils/utils.js */ "./src/utils/utils.js");

function Friends() {
  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useShareAppMessage"])(function () {
    return {};
  }); // "直邀粉丝", "间接粉丝"

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])([{
    title: "直邀粉丝",
    active: 1
  }, {
    title: "间接粉丝",
    active: 0
  }]),
      _useState2 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState, 2),
      tabs = _useState2[0],
      setTabs = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])([]),
      _useState4 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState3, 2),
      friends = _useState4[0],
      setFriends = _useState4[1];

  var _useState5 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(0),
      _useState6 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState5, 2),
      selectTabIndex = _useState6[0],
      setSelectTabIndex = _useState6[1];

  var _useState7 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(1),
      _useState8 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState7, 2),
      page_tab1 = _useState8[0],
      setPage_tab1 = _useState8[1];

  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useReady"])(function () {
    console.log("use ready");
    requestList(0, 1);
  });
  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useDidShow"])(function () {});

  var changeTab = function changeTab(index) {
    console.log("change index " + index);
    setSelectTabIndex(index);
    setFriends([]);
    setPage_tab1(1);
    requestList(index, 1);
  };

  var requestList = function requestList(tabindex, page) {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.showLoading({
      title: "加载中"
    });
    setTimeout(function () {
      _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.hideLoading();
    }, 5000);
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.request({
      url: tabindex ? api.myFollewers2 : api.myFollewers,
      header: {
        'X-Nideshop-Token': _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync("token") || ""
      },
      data: {
        userid: _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync("userInfo").id,
        page: page,
        wxappid: api.WXAppID,
        v: api.VERSION
      },
      success: function success(res) {
        _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.hideLoading();
        setFriends(page == 1 ? res.data.data : friends.concat(res.data.data));
      },
      fail: function fail() {
        _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.hideLoading();
      }
    });
  }; //触底


  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useReachBottom"])(function () {
    setPage_tab1(page_tab1 + 1);
    requestList(selectTabIndex, page_tab1);
  });
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.friends
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.tabs_wrapper
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.tabs, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.fixed])
  }, tabs.map(function (v, i) {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: selectTabIndex === i ? classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.item, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.active]) : _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.item,
      onClick: function onClick() {
        return changeTab(i);
      }
    }, v.title);
  }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.list
  }, friends.length ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], null) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.empty
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.empty_text
  }, "\u6682\u65E0\u6570\u636E")), friends.map(function (item, i) {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.item
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.left
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.avatar,
      src: item.avatar
    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.flex
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.name
    }, item.nickname), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.id
    }, "MID:", item.id))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.right
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.info
    }, item.register_time)));
  })));
}

/* harmony default export */ __webpack_exports__["a"] = (Friends);

/***/ }),

/***/ "./src/pages/mine/friends/index.module.scss":
/*!**************************************************!*\
  !*** ./src/pages/mine/friends/index.module.scss ***!
  \**************************************************/
/*! no static exports found */
/*! exports used: default */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin
module.exports = {"friends":"index-module__friends___4BMZc","nav_bar_tabs":"index-module__nav_bar_tabs___10EZW","item":"index-module__item___2fw_j","title":"index-module__title___1FUQf","empty":"index-module__empty___1FVWP","empty_text":"index-module__empty_text___TgG6P","active":"index-module__active___clZPQ","tabs_wrapper":"index-module__tabs_wrapper___5SV1g","placeholder":"index-module__placeholder___1HUkS","tabs":"index-module__tabs___1SbqA","fixed":"index-module__fixed___1MffT","count":"index-module__count___36pCL","red":"index-module__red___1fkTA","list":"index-module__list___2yYK8","header":"index-module__header___1Z289","text":"index-module__text___2hyBw","left":"index-module__left___2u_qi","avatar":"index-module__avatar___29cBE","flex":"index-module__flex___2FQJ1","right":"index-module__right___7epPF","name":"index-module__name___290AR","id":"index-module__id___jzR1i","info":"index-module__info___xTyxS","ml6":"index-module__ml6___2QF0N"};

/***/ }),

/***/ "./src/pages/mine/friends/index.tsx":
/*!******************************************!*\
  !*** ./src/pages/mine/friends/index.tsx ***!
  \******************************************/
/*! no exports provided */
/*! all exports used */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _tarojs_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @tarojs/runtime */ "./node_modules/@tarojs/runtime/dist/runtime.esm.js");
/* harmony import */ var _node_modules_tarojs_mini_runner_node_modules_babel_loader_lib_index_js_index_tsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib!./index.tsx */ "./node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib/index.js!./src/pages/mine/friends/index.tsx");


var config = {"navigationBarTitleText":"我的团队","enableShareAppMessage":true,"navigationBarBackgroundColor":"#e66465"};

_node_modules_tarojs_mini_runner_node_modules_babel_loader_lib_index_js_index_tsx__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].enableShareAppMessage = true
var inst = Page(Object(_tarojs_runtime__WEBPACK_IMPORTED_MODULE_0__["createPageConfig"])(_node_modules_tarojs_mini_runner_node_modules_babel_loader_lib_index_js_index_tsx__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"], 'pages/mine/friends/index', {}, config || {}))



/***/ })

},[["./src/pages/mine/friends/index.tsx","runtime","taro","vendors","common"]]]);
//# sourceMappingURL=index.js.map