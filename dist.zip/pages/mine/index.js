(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([["pages/mine/index"],{

/***/ "./node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib/index.js!./src/pages/mine/index.tsx":
/*!***************************************************************************************************!*\
  !*** ./node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib!./src/pages/mine/index.tsx ***!
  \***************************************************************************************************/
/*! exports provided: default */
/*! exports used: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _tarojs_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @tarojs/components */ "./node_modules/@tarojs/components/mini/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @tarojs/taro */ "./node_modules/@tarojs/taro/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/cjs/react.production.min.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./index.module.scss */ "./src/pages/mine/index.module.scss");
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! classnames */ "./node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _component_loginComponet_index__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../component/loginComponet/index */ "./src/component/loginComponet/index.js");
/* harmony import */ var _component_imageDialog__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../component/imageDialog */ "./src/component/imageDialog/index.tsx");
/* harmony import */ var _component_imagePreviewer__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../component/imagePreviewer */ "./src/component/imagePreviewer/index.tsx");
/* harmony import */ var _utils_commonUtils__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../utils/commonUtils */ "./src/utils/commonUtils.tsx");











var api = __webpack_require__(/*! ../../utils/utils.js */ "./src/utils/utils.js");

function Ele() {
  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useShareAppMessage"])(function (res) {
    if (res.from === "button") {
      // 来自页面内转发按钮
      console.log(res.target);
    }

    return {
      title: api.shareTitle,
      path: api.sharePath + "?inviter=" + _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync(api.miniapp_self_uuid)
    };
  });
  Object(_utils_commonUtils__WEBPACK_IMPORTED_MODULE_9__[/* default */ "a"])(Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useRouter"])());

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(),
      _useState2 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState, 2),
      hasShowLogin = _useState2[0],
      setHasShowLogin = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(),
      _useState4 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState3, 2),
      hasLogined = _useState4[0],
      setHasLogined = _useState4[1];

  var _useState5 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(""),
      _useState6 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState5, 2),
      nick = _useState6[0],
      setNick = _useState6[1];

  var _useState7 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(""),
      _useState8 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState7, 2),
      avatar = _useState8[0],
      setAvatar = _useState8[1];

  var _useState9 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(""),
      _useState10 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState9, 2),
      userid = _useState10[0],
      setUserid = _useState10[1];

  var _useState11 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(0),
      _useState12 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState11, 2),
      first_followers = _useState12[0],
      setFirst_followers = _useState12[1];

  var _useState13 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(0),
      _useState14 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState13, 2),
      second_followers = _useState14[0],
      setSecond_followers = _useState14[1];

  var _useState15 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(0),
      _useState16 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState15, 2),
      sum_weijiesuan = _useState16[0],
      setSum_weijiesuan = _useState16[1];

  var _useState17 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(0),
      _useState18 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState17, 2),
      sum_yijiesuan = _useState18[0],
      setSum_yijiesuan = _useState18[1];

  var _useState19 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(0),
      _useState20 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState19, 2),
      sum_paid = _useState20[0],
      setSum_paid = _useState20[1];

  var _useState21 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(),
      _useState22 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState21, 2),
      showPromote = _useState22[0],
      setShowPromote = _useState22[1];

  var _useState23 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(),
      _useState24 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState23, 2),
      showContact = _useState24[0],
      setShowContact = _useState24[1];

  var _useState25 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(),
      _useState26 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState25, 2),
      showWithdraw = _useState26[0],
      setShowWithdraw = _useState26[1];

  var _useState27 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(),
      _useState28 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState27, 2),
      showPaterner = _useState28[0],
      setShowPaterner = _useState28[1];

  var _useState29 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(true),
      _useState30 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState29, 2),
      inReview = _useState30[0],
      setInReview = _useState30[1];

  var _useState31 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(""),
      _useState32 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState31, 2),
      wechatImg = _useState32[0],
      setWechatImg = _useState32[1];

  var _useState33 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(""),
      _useState34 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState33, 2),
      gongzhonghao_name = _useState34[0],
      setGongzhonghao_name = _useState34[1];

  var _useState35 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(""),
      _useState36 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState35, 2),
      gongzhonghao_img = _useState36[0],
      setGongzhonghao_img = _useState36[1];

  var handleLoginMethod = function handleLoginMethod() {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorage({
      key: "token",
      success: function success(res) {
        setHasShowLogin(false);
        setHasLogined(true);
      },
      fail: function fail(res) {
        setHasShowLogin(true);
      }
    });
  };

  var handleWithDraw = function handleWithDraw(result) {
    setShowWithdraw(false);
  };

  var parentMethod = function parentMethod(result) {
    setHasShowLogin(false);
  };

  var handleContact = function handleContact() {
    setShowContact(false);
  };

  var handlePaterner = function handlePaterner() {
    setShowPaterner(false);
  };

  var handlePromote = function handlePromote() {
    setShowPromote(false);
  };

  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useDidShow"])(function () {
    requestAppInfo();
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorage({
      key: "userInfo",
      success: function success(res) {
        console.log(res.data.id);
        setNick(res.data.nickname);
        setAvatar(res.data.avatar);
        setUserid(res.data.id);
      },
      fail: function fail(res) {}
    });
    handleLoginMethod();
    requestUserDetail();
  });

  var requestAppInfo = function requestAppInfo() {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.request({
      url: api.IndexUrl,
      header: {
        "X-Nideshop-Token": _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync("token") || ""
      },
      data: {
        userid: _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync("userInfo").id,
        wxappid: api.WXAppID,
        v: api.VERSION
      },
      success: function success(res) {
        console.log(parseInt(res.data.data.inreview));
        setInReview(parseInt(res.data.data.inreview) ? true : false);
      },
      fail: function fail() {}
    });
  };

  var requestUserDetail = function requestUserDetail() {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.request({
      url: api.UserDetail,
      header: {
        "X-Nideshop-Token": _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync("token") || ""
      },
      data: {
        userid: _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync("userInfo").id,
        wxappid: api.WXAppID,
        v: api.VERSION
      },
      success: function success(res) {
        console.log(res);
        setFirst_followers(res.data.data.data.first_followers);
        setSecond_followers(res.data.data.data.second_followers);
        setSum_paid(res.data.data.data.sum_paid);
        setSum_yijiesuan(res.data.data.data.sum_yijiesuan);
        setSum_weijiesuan(res.data.data.data.sum_weijiesuan);
        setWechatImg(res.data.data.contact_wechat_img);
        setGongzhonghao_name(res.data.data.gongzhonghao_name);
        setGongzhonghao_img(res.data.data.gongzhonghao_img);
        _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.setStorage({
          key: "alipay_account",
          data: res.data.data.user.alipay_id
        });
        _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.setStorage({
          key: "alipay_real_name",
          data: res.data.data.user.alipay_username
        });
      },
      fail: function fail() {
        _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.showToast({
          title: "获取个人信息失败",
          icon: "none"
        });
      }
    });
  };

  var generatePromote = function generatePromote() {
    setShowPromote(true);
  };

  var showContactDialog = function showContactDialog() {
    setShowContact(true);
  };

  var showWithDrawDialog = function showWithDrawDialog() {
    if (gongzhonghao_img.length) {
      setShowWithdraw(true);
    } else {
      _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.navigateTo({
        url: "./cash/index"
      });
    }
  };

  var showPaternerDialog = function showPaternerDialog() {
    setShowPaterner(true);
  };

  var clear = function clear() {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.removeStorageSync("token");
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.showToast({
      title: "退出成功",
      icon: "success"
    }).then(function () {
      handleLoginMethod();
    });
  };

  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.page
  }, hasShowLogin ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_component_loginComponet_index__WEBPACK_IMPORTED_MODULE_6__[/* default */ "a"], {
    parentMethod: parentMethod.bind(this)
  }) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], null), showPromote ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_component_imageDialog__WEBPACK_IMPORTED_MODULE_7__[/* default */ "a"], {
    parentMethod: handlePromote.bind(this)
  }) : "", showContact ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_component_imagePreviewer__WEBPACK_IMPORTED_MODULE_8__[/* default */ "a"], {
    imgsrc: wechatImg,
    text: "\u7F8E\u5973\u5BA2\u670D\uFF0C\u6B22\u8FCE\u6765\u64A9\uFF01",
    parentMethod: handleContact.bind(this)
  }) : "", showPaterner ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_component_imagePreviewer__WEBPACK_IMPORTED_MODULE_8__[/* default */ "a"], {
    imgsrc: wechatImg,
    text: "\u590D\u5236\u4E00\u4E2A\u5C0F\u7A0B\u5E8F\uFF0C\u4F60\u72EC\u81EA\u8FD0\u8425\uFF0C\u5B9E\u73B0\u8EBA\u8D5A",
    parentMethod: handlePaterner.bind(this)
  }) : "", showWithdraw ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_component_imagePreviewer__WEBPACK_IMPORTED_MODULE_8__[/* default */ "a"], {
    imgsrc: gongzhonghao_img,
    text: "\u4E3A\u65B9\u4FBF\u63D0\u73B0\uFF0C\u5173\u6CE8\u516C\u4F17\u53F7\uFF0C\u8FDB\u5165\u4F63\u91D1\u63D0\u73B0",
    parentMethod: handleWithDraw.bind(this)
  }) : "", /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.mine
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.mine_takeout
  }, inReview ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], null) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.agent
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.placeholder
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.radius
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.hover
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.info
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.left
  }, hasLogined ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.avatar,
    mode: "widthFix",
    src: avatar
  }) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.avatar,
    mode: "widthFix",
    src: "https://img.mybei.cn/defaultAvatar.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.more
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.nickname
  }, " ", hasLogined ? nick : "未登录"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.mp
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.item
  }, "\u516C\u4F17\u53F7: ", hasLogined ? gongzhonghao_name : "----"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.item
  }, "ID: ", hasLogined ? userid : "----"))))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.panel
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.commission
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.vip,
    mode: "widthFix",
    src: "https://img.mybei.cn/vip111.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.label
  }, "\u7279\u6743\u4F63\u91D1")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.row
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.col
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.label
  }, "\u8D26\u6237\u4F59\u989D(\u5143)"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.number
  }, sum_yijiesuan)), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.col
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.col
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    onClick: function onClick() {
      return showWithDrawDialog();
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.withdraw
  }, "\u53BB\u63D0\u73B0")))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.row
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.col,
    onClick: function onClick() {
      return _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.navigateTo({
        url: "./friends/index"
      });
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.label
  }, "\u6211\u7684\u56E2\u961F(\u4EBA)"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.number
  }, first_followers + second_followers)), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.col
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.label
  }, "\u5F85\u7ED3\u7B97\u4F63\u91D1(\u5143)"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.number
  }, sum_weijiesuan)), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.col
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.label
  }, "\u7D2F\u8BA1\u63D0\u73B0(\u5143)"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.number
  }, sum_paid)))))), inReview ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], null) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.friend
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.item,
    onClick: function onClick() {
      return _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.navigateTo({
        url: "./friends/index"
      });
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.icon11,
    src: "https://mpstatic.qingting123.com/img/weapp-mine/friendsList.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.label
  }, "\u56E2\u961F\u5217\u8868")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.item,
    onClick: function onClick() {
      return generatePromote();
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.icon, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.invite]),
    src: "https://mpstatic.qingting123.com/img/icon/invite.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.label
  }, "\u9080\u8BF7\u597D\u53CB"))), inReview ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], null) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.bannerview,
    onClick: function onClick() {
      return generatePromote();
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.banner,
    src: "https://img.mybei.cn/mine_banner.png"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.btns
  }, inReview ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], null) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.item, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.order]),
    onClick: function onClick() {
      return _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.navigateTo({
        url: "./orders/index"
      });
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.icon_wrapper
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.icon,
    src: "https://mpstatic.qingting123.com/img/weapp-mine/order.png"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.label
  }, "\u8BA2\u5355\u4E1A\u7EE9 "), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.right
  })), inReview ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], null) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.item, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.setting]),
    onClick: function onClick() {
      return _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.navigateTo({
        url: "./setting/alipay/index"
      });
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.icon_wrapper
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.icon,
    src: "https://mpstatic.qingting123.com/img/weapp-mine/setting.png"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.label
  }, "\u63D0\u73B0\u65B9\u5F0F"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.right
  })), inReview ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], null) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.item, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.wallet]),
    onClick: function onClick() {
      return generatePromote();
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.icon_wrapper
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.icon,
    src: "https://mpstatic.qingting123.com/img/weapp-mine/wallet.png"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.label
  }, "\u63A8\u5E7F\u7269\u6599"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.right
  })), inReview ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], null) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.item, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.wallet]),
    onClick: function onClick() {
      return showContactDialog();
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.icon_wrapper
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.icon,
    src: "https://mpstatic.qingting123.com/img/weapp-mine/contact.png"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.label
  }, "\u8054\u7CFB\u5BA2\u670D"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.right
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.item, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.wallet]),
    onClick: function onClick() {
      return showPaternerDialog();
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.icon_wrapper
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.icon,
    src: "https://mpstatic.qingting123.com/img/weapp-mine/contact.png"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.label
  }, "\u6211\u60F3\u6210\u4E3A\u5408\u4F19\u4EBA"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.right
  }))))));
}

/* harmony default export */ __webpack_exports__["a"] = (Ele);

/***/ }),

/***/ "./src/component/imagePreviewer/index.scss":
/*!*************************************************!*\
  !*** ./src/component/imagePreviewer/index.scss ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "./src/component/imagePreviewer/index.tsx":
/*!************************************************!*\
  !*** ./src/component/imagePreviewer/index.tsx ***!
  \************************************************/
/*! exports provided: default */
/*! exports used: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass */ "./node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/assertThisInitialized */ "./node_modules/@babel/runtime/helpers/esm/assertThisInitialized.js");
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/inherits */ "./node_modules/@babel/runtime/helpers/esm/inherits.js");
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_createSuper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createSuper */ "./node_modules/@babel/runtime/helpers/esm/createSuper.js");
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @tarojs/taro */ "./node_modules/@tarojs/taro/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _tarojs_components__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @tarojs/components */ "./node_modules/@tarojs/components/mini/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react */ "./node_modules/react/cjs/react.production.min.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _index_scss__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./index.scss */ "./src/component/imagePreviewer/index.scss");
/* harmony import */ var _index_scss__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_index_scss__WEBPACK_IMPORTED_MODULE_9__);









// 拷贝文件到component的引入方式
// import { TaroCanvasDrawer  } from 'taro-plugin-canvas'; // npm 引入方式


var Simple = /*#__PURE__*/function (_React$Component) {
  Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(Simple, _React$Component);

  var _super = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_createSuper__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"])(Simple);

  function Simple(props) {
    var _this;

    Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(this, Simple);

    _this = _super.call(this, props);

    Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(_this), "config", {
      navigationBarTitleText: "首页"
    });

    Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(_this), "previewImg", function () {
      _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.previewImage({
        current: _this.props.imgsrc,
        urls: [_this.props.imgsrc]
      });
    });

    Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(_this), "saveToAlbum", function () {
      _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.downloadFile({
        url: _this.props.imgsrc,
        success: function success(res) {
          _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.saveImageToPhotosAlbum({
            filePath: res.tempFilePath
          });
          _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.showToast({
            title: "保存图片成功",
            icon: "success",
            duration: 2000
          });
        }
      });
    });

    _this.state = {
      // 绘图配置文件
      config: null,
      // 绘制的图片
      shareImage: null,
      // TaroCanvasDrawer 组件状态
      canvasStatus: false
    };
    return _this;
  }

  Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(Simple, [{
    key: "openShareImg",
    value: function openShareImg() {
      var _this2 = this;

      var that = this;
      this.getSetting().then(function (res) {
        _this2.props.parentMethod();

        if (!res) {
          _this2.showModal();
        } else {
          that.saveToAlbum();
        }
      }).catch(function () {
        _this2.props.parentMethod();

        _this2.showModal();
      });
    }
  }, {
    key: "showModal",
    value: function showModal() {
      this.props.parentMethod();
      var that = this;
      _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.showModal({
        title: "授权提示",
        content: "打开保存图片权限",
        success: function success(res) {
          if (res.confirm) {
            _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.openSetting({
              success: function success(res) {
                if (res.authSetting["scope.writePhotosAlbum"]) {
                  that.saveToAlbum();
                } else {
                  _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.showToast({
                    title: "授权失败",
                    icon: "none"
                  });
                }
              },
              fail: function fail() {
                _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.showToast({
                  title: "授权失败",
                  icon: "none"
                });
              }
            });
          } else if (res.cancel) {
            _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.showToast({
              title: "授权失败",
              icon: "none"
            });
          }
        }
      });
    }
  }, {
    key: "getSetting",
    value: function getSetting() {
      return new Promise(function (resolve, reject) {
        _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.getSetting().then(function (res) {
          if (!res.authSetting["scope.writePhotosAlbum"]) {
            _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.authorize({
              scope: "scope.writePhotosAlbum"
            }).then(function (res) {
              if (res.errMsg == "authorize:ok") {
                resolve(true);
              } else {
                reject(false);
              }
            }).catch(function () {
              reject(false);
            });
          } else {
            resolve(true);
          }
        }).catch(function () {
          reject(false);
        });
      });
    }
  }, {
    key: "render",
    value: function render() {
      var _this3 = this;

      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_8___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_7__[/* View */ "j"], {
        className: "image_dialog"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_8___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_7__[/* View */ "j"], {
        className: "content"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_8___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_7__[/* View */ "j"], {
        className: "header"
      }, this.props.text), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_8___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_7__[/* View */ "j"], {
        className: "body"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_8___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_7__[/* Image */ "c"], {
        className: "img",
        mode: "widthFix",
        src: this.props.imgsrc,
        onClick: function onClick() {
          return _this3.previewImg();
        },
        onLongPress: this.previewImg.bind(this)
      })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_8___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_7__[/* View */ "j"], {
        className: "footer_root"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_8___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_7__[/* View */ "j"], {
        className: "footer fleft",
        onClick: this.props.parentMethod
      }, "\u5173\u95ED"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_8___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_7__[/* View */ "j"], {
        className: "footer fright",
        onClick: function onClick() {
          return _this3.openShareImg();
        }
      }, "\u4FDD\u5B58\u5230\u76F8\u518C"))));
    }
  }]);

  return Simple;
}(react__WEBPACK_IMPORTED_MODULE_8___default.a.Component);

/* harmony default export */ __webpack_exports__["a"] = (Simple);

/***/ }),

/***/ "./src/pages/mine/index.module.scss":
/*!******************************************!*\
  !*** ./src/pages/mine/index.module.scss ***!
  \******************************************/
/*! no static exports found */
/*! exports used: default */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin
module.exports = {"page":"index-module__page___3eLoE","mine":"index-module__mine___2S7M5","mine_takeout":"index-module__mine_takeout___EHpJ7","agent":"index-module__agent___1gxMu","placeholder":"index-module__placeholder___2-84Y","radius":"index-module__radius___C0aLa","hover":"index-module__hover___wb-ys","info":"index-module__info___3pQG0","left":"index-module__left___MIQb1","more":"index-module__more___34LEg","label":"index-module__label___2pp_0","avatar":"index-module__avatar___jdFJG","nickname":"index-module__nickname___3UdJY","tuanzhang":"index-module__tuanzhang___uH2BM","mp":"index-module__mp___roPNI","item":"index-module__item___U89ga","right":"index-module__right___30UjU","wechat-btn":"index-module__wechat-btn___3HMOD","panel":"index-module__panel___3-rRK","commission":"index-module__commission___3MOdP","icon-font":"index-module__icon-font___2SaZq","vip":"index-module__vip___Fjoa6","row":"index-module__row___2FLkH","col":"index-module__col___1iCrr","number":"index-module__number___2GLsZ","withdraw":"index-module__withdraw___31L5G","friend":"index-module__friend___cGH_i","icon":"index-module__icon___2Q1wi","invite":"index-module__invite___7Zo_3","btns":"index-module__btns___1uUCw","icon_wrapper":"index-module__icon_wrapper___2OfC5","extra":"index-module__extra___2larD","at-icon":"index-module__at-icon___1W7di","contact":"index-module__contact___3G3SN","icon11":"index-module__icon11___3Ut5l","bannerview":"index-module__bannerview___3tC28","banner":"index-module__banner___9Opod","order":"index-module__order___2eAHp","wallet":"index-module__wallet___117ZC","inviter":"index-module__inviter___ZYxco","setting":"index-module__setting___1pRRY","favorite":"index-module__favorite___3kK69","score":"index-module__score___1jdw8","free":"index-module__free___2IKOG","mine_group":"index-module__mine_group___21bch","user":"index-module__user___MHNK3","user_youpin":"index-module__user_youpin___1MDY4","user__info":"index-module__user__info___3e7Cd","user__info__box":"index-module__user__info__box___1EGYF","user__info__left":"index-module__user__info__left___1kPpt","user__info__right":"index-module__user__info__right___SFTR6","name":"index-module__name___1F-MY","text":"index-module__text___uzSHZ","privilege":"index-module__privilege___2ojEl","user__info__noAgent":"index-module__user__info__noAgent___1ZWhE","user__info__login":"index-module__user__info__login___1Fdsn","icon__friendsList":"index-module__icon__friendsList___350fK","icon__share":"index-module__icon__share___2l7uz","icon__invite":"index-module__icon__invite___33WhY","line":"index-module__line___2sEOd","wrap":"index-module__wrap___3oiav","count":"index-module__count___1PA4a","money":"index-module__money___8c6ty","card":"index-module__card___oHAoM","body":"index-module__body___3Uonq","header":"index-module__header___3reGg","title":"index-module__title___2l77k","menu":"index-module__menu___1fumr","iconfont":"index-module__iconfont___1hLj-","group":"index-module__group___35C0Z","image":"index-module__image___1iDCD","open_type":"index-module__open_type___28_8D"};

/***/ }),

/***/ "./src/pages/mine/index.tsx":
/*!**********************************!*\
  !*** ./src/pages/mine/index.tsx ***!
  \**********************************/
/*! no exports provided */
/*! all exports used */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _tarojs_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @tarojs/runtime */ "./node_modules/@tarojs/runtime/dist/runtime.esm.js");
/* harmony import */ var _node_modules_tarojs_mini_runner_node_modules_babel_loader_lib_index_js_index_tsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib!./index.tsx */ "./node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib/index.js!./src/pages/mine/index.tsx");


var config = {"navigationBarTitleText":"个人中心","enableShareAppMessage":true,"navigationBarBackgroundColor":"#e66465"};

_node_modules_tarojs_mini_runner_node_modules_babel_loader_lib_index_js_index_tsx__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].enableShareAppMessage = true
var inst = Page(Object(_tarojs_runtime__WEBPACK_IMPORTED_MODULE_0__["createPageConfig"])(_node_modules_tarojs_mini_runner_node_modules_babel_loader_lib_index_js_index_tsx__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"], 'pages/mine/index', {}, config || {}))



/***/ })

},[["./src/pages/mine/index.tsx","runtime","taro","vendors","common"]]]);
//# sourceMappingURL=index.js.map