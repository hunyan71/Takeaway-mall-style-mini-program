(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([["pages/meituan/index"],{

/***/ "./node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib/index.js!./src/pages/meituan/index.tsx":
/*!******************************************************************************************************!*\
  !*** ./node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib!./src/pages/meituan/index.tsx ***!
  \******************************************************************************************************/
/*! exports provided: default */
/*! exports used: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _tarojs_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @tarojs/components */ "./node_modules/@tarojs/components/mini/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @tarojs/taro */ "./node_modules/@tarojs/taro/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/cjs/react.production.min.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./index.module.scss */ "./src/pages/meituan/index.module.scss");
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _meituan_hotel__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../meituan/hotel */ "./src/pages/meituan/hotel/index.tsx");
/* harmony import */ var _meituan_waimai__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../meituan/waimai */ "./src/pages/meituan/waimai/index.tsx");
/* harmony import */ var _meituan_shangchao__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../meituan/shangchao */ "./src/pages/meituan/shangchao/index.tsx");
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../utils/utils */ "./src/utils/utils.js");
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_utils_utils__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _utils_event__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../utils/event */ "./src/utils/event.js");
/* harmony import */ var _component_CustomNavBar__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../component/CustomNavBar */ "./src/component/CustomNavBar/index.tsx");












var api = __webpack_require__(/*! ../../utils/utils.js */ "./src/utils/utils.js");

function MeituanMain() {
  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(0),
      _useState2 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState, 2),
      selectIndex = _useState2[0],
      setSelectIndex = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(true),
      _useState4 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState3, 2),
      inreview = _useState4[0],
      setInreview = _useState4[1];

  var _useState5 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])([]),
      _useState6 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState5, 2),
      datalist = _useState6[0],
      setDatalist = _useState6[1];

  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useReady"])(function () {
    console.log("ready");
  });
  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useDidShow"])(function () {
    requestAppInfo();
    setSelectIndex(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync(_utils_utils__WEBPACK_IMPORTED_MODULE_8__["keySelectedIndex"]));
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.removeStorageSync(_utils_utils__WEBPACK_IMPORTED_MODULE_8__["keySelectedIndex"]);
    _utils_event__WEBPACK_IMPORTED_MODULE_9__[/* default */ "a"].addListener(api.navBarMeituanSelectChangedNotification, function (index) {
      setSelectIndex(index);
      _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.setStorage({
        key: _utils_utils__WEBPACK_IMPORTED_MODULE_8__["keySelectedIndex"],
        data: index
      });
    });
  });

  var redirectDetail = function redirectDetail(item) {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.setStorage({
      key: 'id',
      data: item.id
    }); // Taro.setStorage({
    //   key: 'content',
    //   data: item.content.content
    // })

    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.navigateTo({
      url: "../detail/index?id=" + item.id
    });
  };

  var requestAppInfo = function requestAppInfo() {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.request({
      url: api.IndexUrl,
      header: {
        "X-Nideshop-Token": _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync("token") || ""
      },
      data: {
        userid: _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync("userInfo").id,
        wxappid: api.WXAppID,
        v: api.VERSION
      },
      success: function success(res) {
        setInreview(parseInt(res.data.data.inreview) ? true : false);

        if (!parseInt(res.data.data.inreview)) {
          _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.setTabBarItem({
            "index": 2,
            "text": "美团红包",
            'iconPath': 'assets/imgs/meituan.png',
            'selectedIconPath': 'assets/imgs/meituan-active.png'
          });
        } else {
          requestList();
        }
      },
      fail: function fail() {}
    });
  };

  var requestList = function requestList() {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.showLoading({
      title: "加载中"
    });
    setTimeout(function () {
      _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.hideLoading();
    }, 5000);
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.request({
      url: "https://xcf.haozii.com/wp-json/wp/v2/posts?categories=21&page=1",
      data: {
        v: api.VERSION
      },
      success: function success(res) {
        _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.hideLoading();
        setDatalist(res.data);
        console.log(res.data);
      },
      fail: function fail() {
        _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.hideLoading();
      }
    });
  };

  var callback = function callback() {
    console.log("监听全局通知释放-----美团顶部点击");
  };

  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useDidHide"])(function () {
    _utils_event__WEBPACK_IMPORTED_MODULE_9__[/* default */ "a"].removeListener(api.navBarMeituanSelectChangedNotification, callback);
  });
  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useShareAppMessage"])(function (res) {
    if (res.from === "button") {
      // 来自页面内转发按钮
      console.log(res.target);
    }

    return {
      title: api.shareTitle,
      path: api.sharePath + "?inviter=" + _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync(api.miniapp_self_uuid)
    };
  });
  return inreview ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_component_CustomNavBar__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"], {
    background: "#3481DA",
    color: "#fff",
    backgroundColorTop: "#3481DA",
    renderCenter: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], null, "\u6BCF\u65E5\u83DC\u8C31")
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.items
  }, datalist.map(function (item, i) {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.top_banner,
      onClick: function onClick() {
        return redirectDetail(item);
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
      src: item.meta.thumbnaill,
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.top_banner_img,
      mode: "aspectFill"
    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.textbg
    }, item.title.rendered));
  }))) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.page
  }, selectIndex ? selectIndex === 1 ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_meituan_shangchao__WEBPACK_IMPORTED_MODULE_7__[/* default */ "a"], null) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_meituan_hotel__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"], null) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_meituan_waimai__WEBPACK_IMPORTED_MODULE_6__[/* default */ "a"], null));
}

/* harmony default export */ __webpack_exports__["a"] = (MeituanMain);

/***/ }),

/***/ "./src/pages/meituan/hotel/index.tsx":
/*!*******************************************!*\
  !*** ./src/pages/meituan/hotel/index.tsx ***!
  \*******************************************/
/*! exports provided: default */
/*! exports used: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _tarojs_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @tarojs/components */ "./node_modules/@tarojs/components/mini/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @tarojs/taro */ "./node_modules/@tarojs/taro/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/cjs/react.production.min.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../index.module.scss */ "./src/pages/meituan/index.module.scss");
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! classnames */ "./node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _component_loginComponet_index__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../component/loginComponet/index */ "./src/component/loginComponet/index.js");
/* harmony import */ var _component_CustomNavBar__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../component/CustomNavBar */ "./src/component/CustomNavBar/index.tsx");
/* harmony import */ var _utils_event__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../utils/event */ "./src/utils/event.js");
/* harmony import */ var _component_imageDialog__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../component/imageDialog */ "./src/component/imageDialog/index.tsx");









var api = __webpack_require__(/*! ../../../utils/utils.js */ "./src/utils/utils.js");




function Meituan_hotel() {
  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useShareAppMessage"])(function (res) {
    if (res.from === "button") {
      // 来自页面内转发按钮
      console.log(res.target);
    }

    return {
      title: api.shareTitle,
      path: api.sharePath + "?inviter=" + _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync(api.miniapp_self_uuid)
    };
  });

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(),
      _useState2 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState, 2),
      hasShowLogin = _useState2[0],
      setHasShowLogin = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])("https://mpstatic.qingting123.com/img/loading-max.gif"),
      _useState4 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState3, 2),
      meituanLink_qr = _useState4[0],
      setMeituanLink_qr = _useState4[1];

  var _useState5 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(''),
      _useState6 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState5, 2),
      meituanLink = _useState6[0],
      setMeituanLink = _useState6[1];

  var _useState7 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(),
      _useState8 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState7, 2),
      showPromote = _useState8[0],
      setShowPromote = _useState8[1];

  var _useState9 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(""),
      _useState10 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState9, 2),
      meituanLinkPromotionText = _useState10[0],
      setMeituanLinkPromotionText = _useState10[1];

  var handleLoginMethod = function handleLoginMethod() {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorage({
      key: "token",
      success: function success(res) {
        setHasShowLogin(false);
      },
      fail: function fail(res) {
        setHasShowLogin(true);
      }
    });
  };

  var toCoupon = function toCoupon() {
    console.log("redirect" + meituanLink);
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.navigateToMiniProgram({
      appId: "wxde8ac0a21135c07d",
      //美团appid固定
      path: meituanLink
    });
  };

  var handleClick = function handleClick(index) {
    _utils_event__WEBPACK_IMPORTED_MODULE_8__[/* default */ "a"].emit(api.navBarMeituanSelectChangedNotification, index);
  };

  var handlerGohomeClick = function handlerGohomeClick() {
    console.log("home click");
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.switchTab({
      url: "../../pages/coupons/index"
    });
  };

  var requestMeituanLink = function requestMeituanLink() {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.request({
      url: api.MeituanLinkUrl,
      data: {
        wxappid: api.WXAppID,
        wx_openid: _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync("userInfo").weixin_openid,
        v: api.VERSION
      },
      header: {
        "X-Nideshop-Token": _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync("token")
      },
      success: function success(res) {
        console.log(res.data.data.link_hotel);
        setMeituanLink_qr(res.data.data.link_qr);
        setMeituanLink(res.data.data.link_hotel);
        setMeituanLinkPromotionText(res.data.data.promotion_text);
      }
    });
  };

  var generateClipboard = function generateClipboard() {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.setClipboardData({
      data: meituanLinkPromotionText,
      success: function success(res) {
        _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.showToast({
          title: "文案已复制",
          icon: 'none'
        });
      }
    });
  };

  var parentMethod = function parentMethod(result) {
    setHasShowLogin(false);
    requestMeituanLink();
  }; //处理分享


  var handlePromote = function handlePromote() {
    setShowPromote(false);
  };

  var generatePromote = function generatePromote() {
    setShowPromote(true);
  };

  requestMeituanLink();
  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useDidShow"])(function () {
    handleLoginMethod();
  });
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.page
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.hotel
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_component_CustomNavBar__WEBPACK_IMPORTED_MODULE_7__[/* default */ "a"], {
    background: "#F54E22",
    backgroundColorTop: "#F54E22",
    onHome: handlerGohomeClick,
    home: true,
    renderCenter: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.nav_bar_tabs
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.item,
      onClick: function onClick() {
        return handleClick(0);
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.title
    }, "\u5916\u5356")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.item,
      onClick: function onClick() {
        return handleClick(1);
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.title
    }, "\u5546\u8D85")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.item, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.active]),
      onClick: function onClick() {
        return handleClick(2);
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.title
    }, "\u9152\u5E97")))
  }), hasShowLogin ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_component_loginComponet_index__WEBPACK_IMPORTED_MODULE_6__[/* default */ "a"], {
    parentMethod: parentMethod.bind(this)
  }) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], null), showPromote ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_component_imageDialog__WEBPACK_IMPORTED_MODULE_9__[/* default */ "a"], {
    parentMethod: handlePromote.bind(this)
  }) : '', /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.wm_banner
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.img,
    mode: "widthFix",
    src: "https://mpstatic.qingting123.com/img/waimai/banner-mt-jd.jpg"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.wm_coupon
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.header
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.step
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.img,
    mode: "widthFix",
    src: "https://mpstatic.qingting123.com/img/waimai/3.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.span
  }, "\u5148\u9886\u5238")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.link,
    mode: "widthFix",
    src: "https://mpstatic.qingting123.com/img/waimai/9.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.step
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.img,
    mode: "widthFix",
    src: "https://mpstatic.qingting123.com/img/waimai/4.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.span
  }, "\u518D\u4E0B\u5355")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.link,
    mode: "widthFix",
    src: "https://mpstatic.qingting123.com/img/waimai/9.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.step
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.img,
    mode: "widthFix",
    src: "https://mpstatic.qingting123.com/img/waimai/5.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.span
  }, "\u62FF\u8FD4\u5229"))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.content
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.qrcode,
    mode: "widthFix",
    src: meituanLink_qr
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.btn_wrapper,
    onClick: function onClick() {
      return toCoupon();
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.btn
  }, "\u9886\u7EA2\u5305\u5B9A\u9152\u5E97")))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.wm_btns
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.btn, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.left]),
    onClick: function onClick() {
      return generatePromote();
    }
  }, "\u5206\u4EAB\u8D5A\u94B1"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.btn, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.right]),
    onClick: function onClick() {
      return generateClipboard();
    }
  }, "\u590D\u5236\u6587\u6848")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.wm_tips
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.h3
  }, "\u8FD4\u5229\u6CE8\u610F\u4E8B\u9879\uFF1A"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.p
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], null, "1.\u9886\u5238\u540E\u5728\u7EA2\u5305\u6709\u6548\u671F\u5185\u4E0B\u5355\u5747\u6709\u8FD4\u5229\uFF1B")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.p
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], null, "2.\u7F8E\u56E2\u7ED1\u5B9A\u7684\u624B\u673A\u53F7\uFF0C\u9700\u4E0E\u9886\u5238\u767B\u5F55\u7684\u624B\u673A\u53F7\u4E00\u81F4\uFF1B")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.p
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], null, "3.\u4E0B\u5355\u540E\u7B2C\u4E8C\u5929\u4E0A\u534810:00\u4F1A\u6709\u8BA2\u5355\u8FD4\u73B0\u63D0\u9192\uFF1B")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.p
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], null, "4.\u65E0\u8BBA\u7F8E\u56E2\u65B0\u8001\u7528\u6237\uFF0C\u6BCF\u4E2A\u624B\u673A\u53F7\u6BCF\u5929\u53EF\u9886\u4E00\u6B21\uFF0C\u7EA2\u5305\u91D1\u989D\u968F\u673A\u53D1\u653E\uFF1B")))));
}

/* harmony default export */ __webpack_exports__["a"] = (Meituan_hotel);

/***/ }),

/***/ "./src/pages/meituan/index.module.scss":
/*!*********************************************!*\
  !*** ./src/pages/meituan/index.module.scss ***!
  \*********************************************/
/*! no static exports found */
/*! exports used: default */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin
module.exports = {"page":"index-module__page___27N9o","waimai":"index-module__waimai___2Bx0S","nav_bar__left":"index-module__nav_bar__left___2wvxf","nav_bar__button":"index-module__nav_bar__button___14lec","nav_bar_tabs":"index-module__nav_bar_tabs___3PGeo","item":"index-module__item___28vRZ","title":"index-module__title___2f77H","active":"index-module__active___1CJtc","wm_banner":"index-module__wm_banner___uXOfv","img":"index-module__img___1JVb5","wm_coupon":"index-module__wm_coupon___u-3C7","header":"index-module__header___2FnmC","step":"index-module__step___3DMl0","span":"index-module__span___AlWhF","link":"index-module__link___SilQe","content":"index-module__content___nE-VL","qrcode":"index-module__qrcode___3SVlj","round":"index-module__round___1L_Jq","wm_btns":"index-module__wm_btns___3o2OG","btn_wrapper":"index-module__btn_wrapper___22uwH","btn":"index-module__btn___1eiPU","left":"index-module__left___anBco","right":"index-module__right___3Abyl","disabled":"index-module__disabled___2vcdT","wm_tips":"index-module__wm_tips___3cPe2","h3":"index-module__h3___2fIhm","p":"index-module__p___3tt2Z","em":"index-module__em___3fucV","shangchao":"index-module__shangchao___3UaLe","nav-bar__button":"index-module__nav-bar__button___1vKhG","hotel":"index-module__hotel___2ed8g","top_banner":"index-module__top_banner___3Aapz","textbg":"index-module__textbg___2PdW4","top_banner_img":"index-module__top_banner_img___31EMP"};

/***/ }),

/***/ "./src/pages/meituan/index.tsx":
/*!*************************************!*\
  !*** ./src/pages/meituan/index.tsx ***!
  \*************************************/
/*! no exports provided */
/*! all exports used */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _tarojs_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @tarojs/runtime */ "./node_modules/@tarojs/runtime/dist/runtime.esm.js");
/* harmony import */ var _node_modules_tarojs_mini_runner_node_modules_babel_loader_lib_index_js_index_tsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib!./index.tsx */ "./node_modules/@tarojs/mini-runner/node_modules/babel-loader/lib/index.js!./src/pages/meituan/index.tsx");


var config = {"navigationBarTitleText":"美团外卖","enableShareAppMessage":true,"navigationBarBackgroundColor":"#F7AD31","navigationStyle":"custom"};

_node_modules_tarojs_mini_runner_node_modules_babel_loader_lib_index_js_index_tsx__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"].enableShareAppMessage = true
var inst = Page(Object(_tarojs_runtime__WEBPACK_IMPORTED_MODULE_0__["createPageConfig"])(_node_modules_tarojs_mini_runner_node_modules_babel_loader_lib_index_js_index_tsx__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"], 'pages/meituan/index', {}, config || {}))



/***/ }),

/***/ "./src/pages/meituan/shangchao/index.tsx":
/*!***********************************************!*\
  !*** ./src/pages/meituan/shangchao/index.tsx ***!
  \***********************************************/
/*! exports provided: default */
/*! exports used: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _tarojs_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @tarojs/components */ "./node_modules/@tarojs/components/mini/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @tarojs/taro */ "./node_modules/@tarojs/taro/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/cjs/react.production.min.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../index.module.scss */ "./src/pages/meituan/index.module.scss");
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! classnames */ "./node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _component_loginComponet_index__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../component/loginComponet/index */ "./src/component/loginComponet/index.js");
/* harmony import */ var _component_CustomNavBar__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../component/CustomNavBar */ "./src/component/CustomNavBar/index.tsx");
/* harmony import */ var _utils_event__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../utils/event */ "./src/utils/event.js");
/* harmony import */ var _component_imageDialog__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../component/imageDialog */ "./src/component/imageDialog/index.tsx");









var api = __webpack_require__(/*! ../../../utils/utils.js */ "./src/utils/utils.js");




function Meitun_Shangchao() {
  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useShareAppMessage"])(function (res) {
    if (res.from === "button") {
      // 来自页面内转发按钮
      console.log(res.target);
    }

    return {
      title: api.shareTitle,
      path: api.sharePath + "?inviter=" + _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync(api.miniapp_self_uuid)
    };
  });

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])([]),
      _useState2 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState, 2),
      couponslist = _useState2[0],
      setCouponslist = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(),
      _useState4 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState3, 2),
      hasShowLogin = _useState4[0],
      setHasShowLogin = _useState4[1];

  var _useState5 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])("https://mpstatic.qingting123.com/img/loading-max.gif"),
      _useState6 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState5, 2),
      meituanLink_qr = _useState6[0],
      setMeituanLink_qr = _useState6[1];

  var _useState7 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(''),
      _useState8 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState7, 2),
      meituanLink = _useState8[0],
      setMeituanLink = _useState8[1];

  var _useState9 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(),
      _useState10 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState9, 2),
      showPromote = _useState10[0],
      setShowPromote = _useState10[1];

  var _useState11 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(""),
      _useState12 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState11, 2),
      meituanLinkPromotionText = _useState12[0],
      setMeituanLinkPromotionText = _useState12[1];

  var handleLoginMethod = function handleLoginMethod() {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorage({
      key: "token",
      success: function success(res) {
        setHasShowLogin(false);
      },
      fail: function fail(res) {
        setHasShowLogin(true);
      }
    });
  };

  var toCoupon = function toCoupon() {
    console.log("redirect" + meituanLink);
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.navigateToMiniProgram({
      appId: "wxde8ac0a21135c07d",
      //美团appid固定
      path: meituanLink
    });
  };

  var handleClick = function handleClick(index) {
    _utils_event__WEBPACK_IMPORTED_MODULE_8__[/* default */ "a"].emit(api.navBarMeituanSelectChangedNotification, index);
  };

  var handlerGohomeClick = function handlerGohomeClick() {
    console.log("home click");
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.switchTab({
      url: "../../pages/coupons/index"
    });
  };

  var requestMeituanLink = function requestMeituanLink() {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.request({
      url: api.MeituanLinkUrl,
      data: {
        wxappid: api.WXAppID,
        wx_openid: _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync("userInfo").weixin_openid,
        v: api.VERSION
      },
      header: {
        "X-Nideshop-Token": _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync("token")
      },
      success: function success(res) {
        console.log(res.data.data.link_shangchao);
        setMeituanLink_qr(res.data.data.link_qr);
        setMeituanLink(res.data.data.link_shangchao);
        setMeituanLinkPromotionText(res.data.data.promotion_text);
      }
    });
  }; //处理分享


  var handlePromote = function handlePromote() {
    setShowPromote(false);
  };

  var generatePromote = function generatePromote() {
    setShowPromote(true);
  };

  var parentMethod = function parentMethod(result) {
    setHasShowLogin(false);
    requestMeituanLink();
  };

  var generateClipboard = function generateClipboard() {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.setClipboardData({
      data: meituanLinkPromotionText,
      success: function success(res) {
        _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.showToast({
          title: "文案已复制",
          icon: 'none'
        });
      }
    });
  };

  requestMeituanLink();
  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useDidShow"])(function () {
    handleLoginMethod();
  });
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.page
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.shangchao
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_component_CustomNavBar__WEBPACK_IMPORTED_MODULE_7__[/* default */ "a"], {
    background: "#71DC3E",
    backgroundColorTop: "#71DC3E",
    onHome: handlerGohomeClick,
    home: true,
    renderCenter: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.nav_bar_tabs
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.item,
      onClick: function onClick() {
        return handleClick(0);
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.title
    }, "\u5916\u5356")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.item, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.active]),
      onClick: function onClick() {
        return handleClick(1);
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.title
    }, "\u5546\u8D85")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.item,
      onClick: function onClick() {
        return handleClick(2);
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.title
    }, "\u9152\u5E97")))
  }), hasShowLogin ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_component_loginComponet_index__WEBPACK_IMPORTED_MODULE_6__[/* default */ "a"], {
    parentMethod: parentMethod.bind(this)
  }) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], null), showPromote ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_component_imageDialog__WEBPACK_IMPORTED_MODULE_9__[/* default */ "a"], {
    parentMethod: handlePromote.bind(this)
  }) : '', /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.wm_banner
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.img,
    mode: "widthFix",
    src: "https://mpstatic.qingting123.com/img/waimai/banner-mt-sc.jpg"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.wm_coupon
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.header
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.step
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.img,
    mode: "widthFix",
    src: "https://mpstatic.qingting123.com/img/waimai/mt-sc-1.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.span
  }, "\u5148\u9886\u5238")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.link,
    mode: "widthFix",
    src: "https://mpstatic.qingting123.com/img/waimai/mt-sc-4.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.step
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.img,
    mode: "widthFix",
    src: "https://mpstatic.qingting123.com/img/waimai/mt-sc-2.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.span
  }, "\u518D\u4E0B\u5355")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.link,
    mode: "widthFix",
    src: "https://mpstatic.qingting123.com/img/waimai/mt-sc-4.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.step
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.img,
    mode: "widthFix",
    src: "https://mpstatic.qingting123.com/img/waimai/mt-sc-3.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.span
  }, "\u62FF\u8FD4\u5229"))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.content
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.qrcode,
    mode: "widthFix",
    src: meituanLink_qr
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.btn_wrapper,
    onClick: function onClick() {
      return toCoupon();
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.btn
  }, "\u9886\u7EA2\u5305\u70B9\u5916\u5356")))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.wm_btns
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.btn, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.left]),
    onClick: function onClick() {
      return generatePromote();
    }
  }, "\u5206\u4EAB\u8D5A\u94B1"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.btn, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.right]),
    onClick: function onClick() {
      return generateClipboard();
    }
  }, "\u590D\u5236\u6587\u6848")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.wm_tips
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.h3
  }, "\u8FD4\u5229\u6CE8\u610F\u4E8B\u9879\uFF1A"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.p
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], null, "1.\u9886\u5238\u540E\u5728\u7EA2\u5305\u6709\u6548\u671F\u5185\u4E0B\u5355\u5747\u6709\u8FD4\u5229\uFF1B")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.p
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], null, "2.\u7F8E\u56E2\u7ED1\u5B9A\u7684\u624B\u673A\u53F7\uFF0C\u9700\u4E0E\u9886\u5238\u767B\u5F55\u7684\u624B\u673A\u53F7\u4E00\u81F4\uFF1B")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.p
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], null, "3.\u4E0B\u5355\u540E\u7B2C\u4E8C\u5929\u4E0A\u534810:00\u4F1A\u6709\u8BA2\u5355\u8FD4\u73B0\u63D0\u9192\uFF1B")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.p
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], null, "4.\u65E0\u8BBA\u7F8E\u56E2\u65B0\u8001\u7528\u6237\uFF0C\u6BCF\u4E2A\u624B\u673A\u53F7\u6BCF\u5929\u53EF\u9886\u4E00\u6B21\uFF0C\u7EA2\u5305\u91D1\u989D\u968F\u673A\u53D1\u653E\uFF1B")))));
}

/* harmony default export */ __webpack_exports__["a"] = (Meitun_Shangchao);

/***/ }),

/***/ "./src/pages/meituan/waimai/index.tsx":
/*!********************************************!*\
  !*** ./src/pages/meituan/waimai/index.tsx ***!
  \********************************************/
/*! exports provided: default */
/*! exports used: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _tarojs_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @tarojs/components */ "./node_modules/@tarojs/components/mini/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @tarojs/taro */ "./node_modules/@tarojs/taro/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/cjs/react.production.min.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../index.module.scss */ "./src/pages/meituan/index.module.scss");
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! classnames */ "./node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _component_loginComponet_index__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../component/loginComponet/index */ "./src/component/loginComponet/index.js");
/* harmony import */ var _component_CustomNavBar__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../component/CustomNavBar */ "./src/component/CustomNavBar/index.tsx");
/* harmony import */ var _utils_event__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../utils/event */ "./src/utils/event.js");
/* harmony import */ var _component_imageDialog__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../component/imageDialog */ "./src/component/imageDialog/index.tsx");









var api = __webpack_require__(/*! ../../../utils/utils.js */ "./src/utils/utils.js");




function Meituan_Waimai() {
  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useShareAppMessage"])(function (res) {
    if (res.from === "button") {
      // 来自页面内转发按钮
      console.log(res.target);
    }

    return {
      title: api.shareTitle,
      path: api.sharePath + "?inviter=" + _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync(api.miniapp_self_uuid)
    };
  });

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(),
      _useState2 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState, 2),
      hasShowLogin = _useState2[0],
      setHasShowLogin = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])("https://mpstatic.qingting123.com/img/loading-max.gif"),
      _useState4 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState3, 2),
      meituanLink_qr = _useState4[0],
      setMeituanLink_qr = _useState4[1];

  var _useState5 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(''),
      _useState6 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState5, 2),
      meituanLink = _useState6[0],
      setMeituanLink = _useState6[1];

  var _useState7 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(),
      _useState8 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState7, 2),
      showPromote = _useState8[0],
      setShowPromote = _useState8[1];

  var _useState9 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(""),
      _useState10 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_useState9, 2),
      meituanLinkPromotionText = _useState10[0],
      setMeituanLinkPromotionText = _useState10[1];

  var handleLoginMethod = function handleLoginMethod() {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorage({
      key: "token",
      success: function success(res) {
        setHasShowLogin(false);
      },
      fail: function fail(res) {
        setHasShowLogin(true);
      }
    });
  };

  var toCoupon = function toCoupon() {
    console.log("redirect" + meituanLink);
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.navigateToMiniProgram({
      appId: "wxde8ac0a21135c07d",
      //美团appid固定
      path: meituanLink
    });
  };

  var handleClick = function handleClick(index) {
    _utils_event__WEBPACK_IMPORTED_MODULE_8__[/* default */ "a"].emit(api.navBarMeituanSelectChangedNotification, index);
  };

  var handlerGohomeClick = function handlerGohomeClick() {
    console.log("home click");
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.switchTab({
      url: "../../pages/coupons/index"
    });
  };

  var generateClipboard = function generateClipboard() {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.setClipboardData({
      data: meituanLinkPromotionText,
      success: function success(res) {
        _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.showToast({
          title: "文案已复制",
          icon: 'none'
        });
      }
    });
  };

  var requestMeituanLink = function requestMeituanLink() {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.request({
      url: api.MeituanLinkUrl,
      data: {
        wxappid: api.WXAppID,
        wx_openid: _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync("userInfo").weixin_openid,
        v: api.VERSION
      },
      header: {
        "X-Nideshop-Token": _tarojs_taro__WEBPACK_IMPORTED_MODULE_2___default.a.getStorageSync("token")
      },
      success: function success(res) {
        console.log(res.data.data.link_waimai);
        setMeituanLink_qr(res.data.data.link_qr);
        setMeituanLink(res.data.data.link_waimai);
        setMeituanLinkPromotionText(res.data.data.promotion_text);
      }
    });
  }; //处理分享


  var handlePromote = function handlePromote() {
    setShowPromote(false);
  };

  var generatePromote = function generatePromote() {
    setShowPromote(true);
  };

  var parentMethod = function parentMethod(result) {
    setHasShowLogin(false);
    requestMeituanLink();
  };

  requestMeituanLink();
  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_2__["useDidShow"])(function () {
    handleLoginMethod();
  });
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.page
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.waimai
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_component_CustomNavBar__WEBPACK_IMPORTED_MODULE_7__[/* default */ "a"], {
    background: "#F5AE32",
    backgroundColorTop: "#F5AE32",
    onHome: handlerGohomeClick,
    home: true,
    renderCenter: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.nav_bar_tabs
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.item, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.active]),
      onClick: function onClick() {
        return handleClick(0);
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.title
    }, "\u5916\u5356")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.item,
      onClick: function onClick() {
        return handleClick(1);
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.title
    }, "\u5546\u8D85")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.item,
      onClick: function onClick() {
        return handleClick(2);
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
      className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.title
    }, "\u9152\u5E97")))
  }), hasShowLogin ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_component_loginComponet_index__WEBPACK_IMPORTED_MODULE_6__[/* default */ "a"], {
    parentMethod: parentMethod.bind(this)
  }) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], null), showPromote ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_component_imageDialog__WEBPACK_IMPORTED_MODULE_9__[/* default */ "a"], {
    parentMethod: handlePromote.bind(this)
  }) : '', /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.wm_banner
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.img,
    mode: "widthFix",
    src: "https://mpstatic.qingting123.com/img/waimai/banner-mt.jpg"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.wm_coupon
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.header
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.step
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.img,
    mode: "widthFix",
    src: "https://mpstatic.qingting123.com/img/waimai/3.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.span
  }, "\u5148\u9886\u5238")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.link,
    mode: "widthFix",
    src: "https://mpstatic.qingting123.com/img/waimai/9.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.step
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.img,
    mode: "widthFix",
    src: "https://mpstatic.qingting123.com/img/waimai/4.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.span
  }, "\u518D\u4E0B\u5355")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.link,
    mode: "widthFix",
    src: "https://mpstatic.qingting123.com/img/waimai/9.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.step
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.img,
    mode: "widthFix",
    src: "https://mpstatic.qingting123.com/img/waimai/5.png"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.span
  }, "\u62FF\u8FD4\u5229"))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.content
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Image */ "c"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.qrcode,
    mode: "widthFix",
    src: meituanLink_qr
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.btn_wrapper,
    onClick: function onClick() {
      return toCoupon();
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.btn
  }, "\u9886\u7EA2\u5305\u70B9\u5916\u5356")))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.wm_btns
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.btn, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.left]),
    onClick: function onClick() {
      return generatePromote();
    }
  }, "\u5206\u4EAB\u8D5A\u94B1"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: classnames__WEBPACK_IMPORTED_MODULE_5___default()([_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.btn, _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.right]),
    onClick: function onClick() {
      return generateClipboard();
    }
  }, "\u590D\u5236\u6587\u6848")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.wm_tips
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.h3
  }, "\u8FD4\u5229\u6CE8\u610F\u4E8B\u9879\uFF1A"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.p
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], null, "1.\u7F8E\u56E2\u5916\u5356\uFF0C\u5FC5\u987B\u4F7F\u7528\u5E26"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.em
  }, "\u3010\u6E20\u9053\u4E13\u4EAB\u3011"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], null, "\u6807\u8BB0\u7684\u4F18\u60E0\u5238\u624D\u6709\u8FD4\u5229\uFF1B")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.p
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], null, "2.\u9886\u5238\u540E\u5728\u7EA2\u5305\u6709\u6548\u671F\u5185\u4E0B\u5355\u5747\u6709\u8FD4\u5229\uFF1B")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.p
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], null, "3.\u7F8E\u56E2\u7ED1\u5B9A\u7684\u624B\u673A\u53F7\uFF0C\u9700\u4E0E\u9886\u5238\u767B\u5F55\u7684\u624B\u673A\u53F7\u4E00\u81F4\uFF1B")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.p
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], null, "4.\u4E0B\u5355\u540E\u7B2C\u4E8C\u5929\u4E0A\u534810:00\u4F1A\u6709\u8BA2\u5355\u8FD4\u73B0\u63D0\u9192\uFF1B")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* View */ "j"], {
    className: _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.p
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_1__[/* Text */ "i"], null, "5.\u65E0\u8BBA\u7F8E\u56E2\u65B0\u8001\u7528\u6237\uFF0C\u6BCF\u4E2A\u624B\u673A\u53F7\u6BCF\u5929\u53EF\u9886\u4E00\u6B21\uFF0C\u7EA2\u5305\u91D1\u989D\u968F\u673A\u53D1\u653E\uFF1B")))));
}

/* harmony default export */ __webpack_exports__["a"] = (Meituan_Waimai);

/***/ })

},[["./src/pages/meituan/index.tsx","runtime","taro","vendors","common"]]]);
//# sourceMappingURL=index.js.map