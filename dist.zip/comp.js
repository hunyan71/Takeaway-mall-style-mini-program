(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([["comp"],[],[["./node_modules/@tarojs/mini-runner/dist/template/comp.js","runtime","taro","vendors"]]]);
//# sourceMappingURL=comp.js.map