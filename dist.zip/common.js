(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([["common"],{

/***/ "./src/component/CustomNavBar/index.scss":
/*!***********************************************!*\
  !*** ./src/component/CustomNavBar/index.scss ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "./src/component/CustomNavBar/index.tsx":
/*!**********************************************!*\
  !*** ./src/component/CustomNavBar/index.tsx ***!
  \**********************************************/
/*! exports provided: getSystemInfo, default */
/*! exports used: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export getSystemInfo */
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_objectSpread2__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2 */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var lodash_isFunction__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! lodash/isFunction */ "./node_modules/lodash/isFunction.js");
/* harmony import */ var lodash_isFunction__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash_isFunction__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @tarojs/taro */ "./node_modules/@tarojs/taro/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "./node_modules/react/cjs/react.production.min.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _index_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./index.scss */ "./src/component/CustomNavBar/index.scss");
/* harmony import */ var _index_scss__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_index_scss__WEBPACK_IMPORTED_MODULE_5__);






var getSystemInfo = function getSystemInfo() {
  if (_tarojs_taro__WEBPACK_IMPORTED_MODULE_3___default.a.globalSystemInfo && !_tarojs_taro__WEBPACK_IMPORTED_MODULE_3___default.a.globalSystemInfo.ios) {
    return _tarojs_taro__WEBPACK_IMPORTED_MODULE_3___default.a.globalSystemInfo;
  } else {
    // h5环境下忽略navbar
    if (!lodash_isFunction__WEBPACK_IMPORTED_MODULE_2___default()(_tarojs_taro__WEBPACK_IMPORTED_MODULE_3___default.a.getSystemInfoSync)) {
      return null;
    }

    var systemInfo = _tarojs_taro__WEBPACK_IMPORTED_MODULE_3___default.a.getSystemInfoSync();
    var ios = !!(systemInfo.system.toLowerCase().search('ios') + 1);
    var rect;

    try {
      rect = _tarojs_taro__WEBPACK_IMPORTED_MODULE_3___default.a.getMenuButtonBoundingClientRect ? _tarojs_taro__WEBPACK_IMPORTED_MODULE_3___default.a.getMenuButtonBoundingClientRect() : null;

      if (rect === null) {
        throw 'getMenuButtonBoundingClientRect error';
      } //取值为0的情况  有可能width不为0 top为0的情况


      if (!rect.width || !rect.top || !rect.left || !rect.height) {
        throw 'getMenuButtonBoundingClientRect error';
      }
    } catch (error) {
      var gap = 0; //胶囊按钮上下间距 使导航内容居中

      var width = 96; //胶囊的宽度

      if (systemInfo.platform === 'android') {
        gap = 8;
        width = 96;
      } else if (systemInfo.platform === 'devtools') {
        if (ios) {
          gap = 5.5; //开发工具中ios手机
        } else {
          gap = 7.5; //开发工具中android和其他手机
        }
      } else {
        gap = 4;
        width = 88;
      }

      if (!systemInfo.statusBarHeight) {
        //开启wifi的情况下修复statusBarHeight值获取不到
        systemInfo.statusBarHeight = systemInfo.screenHeight - systemInfo.windowHeight - 20;
      }

      rect = {
        //获取不到胶囊信息就自定义重置一个
        bottom: systemInfo.statusBarHeight + gap + 32,
        height: 32,
        left: systemInfo.windowWidth - width - 10,
        right: systemInfo.windowWidth - 10,
        top: systemInfo.statusBarHeight + gap,
        width: width
      };
      console.log('error', error);
      console.log('rect', rect);
    }

    var navBarHeight = 0;

    if (!systemInfo.statusBarHeight) {
      //开启wifi和打电话下
      systemInfo.statusBarHeight = systemInfo.screenHeight - systemInfo.windowHeight - 20;

      navBarHeight = function () {
        var gap = rect.top - systemInfo.statusBarHeight;
        return 2 * gap + rect.height;
      }();

      systemInfo.statusBarHeight = 0;
      systemInfo.navBarExtendHeight = 0; //下方扩展4像素高度 防止下方边距太小
    } else {
      navBarHeight = function () {
        var gap = rect.top - systemInfo.statusBarHeight;
        return systemInfo.statusBarHeight + 2 * gap + rect.height;
      }();

      if (ios) {
        systemInfo.navBarExtendHeight = 4; //下方扩展4像素高度 防止下方边距太小
      } else {
        systemInfo.navBarExtendHeight = 0;
      }
    }

    systemInfo.navBarHeight = navBarHeight; //导航栏高度不包括statusBarHeight

    systemInfo.capsulePosition = rect; //右上角胶囊按钮信息bottom: 58 height: 32 left: 317 right: 404 top: 26 width: 87 目前发现在大多机型都是固定值 为防止不一样所以会使用动态值来计算nav元素大小

    systemInfo.ios = ios; //是否ios

    _tarojs_taro__WEBPACK_IMPORTED_MODULE_3___default.a.globalSystemInfo = systemInfo; //将信息保存到全局变量中,后边再用就不用重新异步获取了
    //console.log('systemInfo', systemInfo);

    return systemInfo;
  }
};
var globalSystemInfo = getSystemInfo();

var NavBar = function NavBar(props) {
  var back = props.back,
      home = props.home,
      title = props.title,
      color = props.color,
      background = props.background,
      backgroundColorTop = props.backgroundColorTop,
      searchBar = props.searchBar,
      searchText = props.searchText,
      iconTheme = props.iconTheme,
      extClass = props.extClass;

  var setStyle = function setStyle(systemInfo) {
    var statusBarHeight = systemInfo.statusBarHeight,
        navBarHeight = systemInfo.navBarHeight,
        capsulePosition = systemInfo.capsulePosition,
        navBarExtendHeight = systemInfo.navBarExtendHeight,
        ios = systemInfo.ios,
        windowWidth = systemInfo.windowWidth;
    var rightDistance = windowWidth - capsulePosition.right; //胶囊按钮右侧到屏幕右侧的边距

    var leftWidth = windowWidth - capsulePosition.left; //胶囊按钮左侧到屏幕右侧的边距

    var navigationbarinnerStyle = {
      color: color,
      //`background:${background}`,
      height: navBarHeight + navBarExtendHeight,
      paddingTop: statusBarHeight,
      paddingRight: leftWidth,
      paddingBottom: navBarExtendHeight
    };
    var navBarLeft = {};

    if (back && !home || !back && home) {
      navBarLeft = {
        width: capsulePosition.width,
        height: capsulePosition.height,
        marginLeft: 0,
        marginRight: rightDistance
      };
    } else if (back && home || title) {
      navBarLeft = {
        width: capsulePosition.width,
        height: capsulePosition.height,
        marginLeft: rightDistance
      };
    } else {
      navBarLeft = {
        width: 'auto',
        marginLeft: 0
      };
    }

    return {
      navigationbarinnerStyle: navigationbarinnerStyle,
      navBarLeft: navBarLeft,
      navBarHeight: navBarHeight,
      capsulePosition: capsulePosition,
      navBarExtendHeight: navBarExtendHeight,
      ios: ios,
      rightDistance: rightDistance
    };
  };

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(setStyle(globalSystemInfo)),
      _useState2 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(_useState, 2),
      configStyle = _useState2[0],
      setConfigStyle = _useState2[1];

  var navigationbarinnerStyle = configStyle.navigationbarinnerStyle,
      navBarLeft = configStyle.navBarLeft,
      navBarHeight = configStyle.navBarHeight,
      capsulePosition = configStyle.capsulePosition,
      navBarExtendHeight = configStyle.navBarExtendHeight,
      ios = configStyle.ios,
      rightDistance = configStyle.rightDistance;
  Object(_tarojs_taro__WEBPACK_IMPORTED_MODULE_3__["useDidShow"])(function () {
    if (globalSystemInfo.ios) {
      globalSystemInfo = getSystemInfo();
      setConfigStyle(setStyle(globalSystemInfo));
    }
  });

  var handleBackClick = function handleBackClick() {
    if (lodash_isFunction__WEBPACK_IMPORTED_MODULE_2___default()(props.onBack)) {
      props.onBack();
    } else {
      var pages = _tarojs_taro__WEBPACK_IMPORTED_MODULE_3___default.a.getCurrentPages();

      if (pages.length >= 2) {
        _tarojs_taro__WEBPACK_IMPORTED_MODULE_3___default.a.navigateBack({
          delta: props.delta
        });
      }
    }
  };

  var handleGoHomeClick = function handleGoHomeClick() {
    if (lodash_isFunction__WEBPACK_IMPORTED_MODULE_2___default()(props.onHome)) {
      props.onHome();
    }
  };

  var handleSearchClick = function handleSearchClick() {
    if (lodash_isFunction__WEBPACK_IMPORTED_MODULE_2___default()(props.onSearch)) {
      props.onSearch();
    }
  };

  var nav_bar__center;

  if (title) {
    nav_bar__center = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement("text", null, title);
  } else if (searchBar) {
    nav_bar__center = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement("view", {
      className: "nav-bar-search",
      style: {
        height: capsulePosition.height
      },
      onClick: handleSearchClick
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement("view", {
      className: "nav-bar-search__icon"
    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement("view", {
      className: "nav-bar-search__input"
    }, searchText));
  } else {
    nav_bar__center = props.renderCenter;
  }

  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement("view", {
    className: "nav-bar ".concat(ios ? 'ios' : 'android', " ").concat(extClass),
    style: {
      background: backgroundColorTop ? backgroundColorTop : background,
      height: navBarHeight + navBarExtendHeight
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement("view", {
    className: "nav-bar__placeholder ".concat(ios ? 'ios' : 'android'),
    style: {
      paddingTop: navBarHeight + navBarExtendHeight
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement("view", {
    className: "nav-bar__inner ".concat(ios ? 'ios' : 'android'),
    style: Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_objectSpread2__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])({
      background: background
    }, navigationbarinnerStyle)
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement("view", {
    className: "nav-bar__left",
    style: Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_objectSpread2__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])({}, navBarLeft)
  }, back && !home && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement("view", {
    onClick: handleBackClick,
    className: "nav-bar__button nav-bar__btn_goback ".concat(iconTheme)
  }), !back && home && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement("view", {
    onClick: handleGoHomeClick,
    className: "nav-bar__button nav-bar__btn_gohome ".concat(iconTheme)
  }), back && home && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement("view", {
    className: "nav-bar__buttons ".concat(ios ? 'ios' : 'android')
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement("view", {
    onClick: handleBackClick,
    className: "nav-bar__button nav-bar__btn_goback ".concat(iconTheme)
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement("view", {
    onClick: handleGoHomeClick,
    className: "nav-bar__button nav-bar__btn_gohome ".concat(iconTheme, "}")
  })), !back && !home && props.renderLeft), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement("view", {
    className: "nav-bar__center",
    style: {
      paddingLeft: rightDistance
    }
  }, nav_bar__center), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_4___default.a.createElement("view", {
    className: "nav-bar__right",
    style: {
      marginRight: rightDistance
    }
  }, props.renderRight)));
};

NavBar.options = {
  addGlobalClass: true
};
NavBar.defaultProps = {
  extClass: '',
  background: 'rgba(255,255,255,1)',
  //导航栏背景
  color: '#000000',
  title: '',
  searchText: '点我搜索',
  searchBar: false,
  back: false,
  home: false,
  iconTheme: 'white',
  delta: 1
};
/* harmony default export */ __webpack_exports__["a"] = (NavBar);

/***/ }),

/***/ "./src/component/imageDialog/base64src.js":
/*!************************************************!*\
  !*** ./src/component/imageDialog/base64src.js ***!
  \************************************************/
/*! exports provided: default */
/*! exports used: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");

var fsm = wx.getFileSystemManager();
var FILE_BASE_NAME = 'tmp_base64src'; //自定义文件名

function base64src(base64data, cb) {
  var _ref = /data:image\/(\w+);base64,(.*)/.exec(base64data) || [],
      _ref2 = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(_ref, 3),
      format = _ref2[1],
      bodyData = _ref2[2];

  if (!format) {
    console.log('base64图片格式不对');
    return new Error('ERROR_BASE64SRC_PARSE');
  }

  var filePath = "".concat(wx.env.USER_DATA_PATH, "/").concat(FILE_BASE_NAME, ".").concat(format);
  var buffer = wx.base64ToArrayBuffer(bodyData);
  fsm.writeFile({
    filePath: filePath,
    data: buffer,
    encoding: 'binary',
    success: function success() {
      console.log('小程序码base64图片本地地址' + filePath);
      cb(filePath);
    },
    fail: function fail() {
      console.log('base64图片写入本地出错');
      return new Error('ERROR_BASE64SRC_WRITE');
    }
  });
}

;
/* harmony default export */ __webpack_exports__["a"] = (base64src);

/***/ }),

/***/ "./src/component/imageDialog/index.scss":
/*!**********************************************!*\
  !*** ./src/component/imageDialog/index.scss ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "./src/component/imageDialog/index.tsx":
/*!*********************************************!*\
  !*** ./src/component/imageDialog/index.tsx ***!
  \*********************************************/
/*! exports provided: default */
/*! exports used: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass */ "./node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/assertThisInitialized */ "./node_modules/@babel/runtime/helpers/esm/assertThisInitialized.js");
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/inherits */ "./node_modules/@babel/runtime/helpers/esm/inherits.js");
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_createSuper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createSuper */ "./node_modules/@babel/runtime/helpers/esm/createSuper.js");
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @tarojs/taro */ "./node_modules/@tarojs/taro/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react */ "./node_modules/react/cjs/react.production.min.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _tarojs_components__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @tarojs/components */ "./node_modules/@tarojs/components/mini/index.js");
/* harmony import */ var _base64src__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./base64src */ "./src/component/imageDialog/base64src.js");
/* harmony import */ var _taro_plugin_canvas__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../taro-plugin-canvas */ "./src/component/taro-plugin-canvas/index.tsx");
/* harmony import */ var _index_scss__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./index.scss */ "./src/component/imageDialog/index.scss");
/* harmony import */ var _index_scss__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_index_scss__WEBPACK_IMPORTED_MODULE_11__);










 // 拷贝文件到component的引入方式



var api = __webpack_require__(/*! ../../utils/utils.js */ "./src/utils/utils.js");

var TestCanvas = /*#__PURE__*/function (_React$Component) {
  Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(TestCanvas, _React$Component);

  var _super = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_createSuper__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"])(TestCanvas);

  function TestCanvas(props) {
    var _this;

    Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(this, TestCanvas);

    _this = _super.call(this, props);

    Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(_this), "generatePromotion", function () {
      var that = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(_this);

      _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.showLoading({
        title: "正在生成海报..."
      });

      _this.requestMiniAppQrCode(function (qrdata) {
        that.canvasDrawFunc(qrdata);
      }, function () {
        _this.props.parentMethod();

        console.log("获取小程序码获取失败");
        _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.hideLoading();
        _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.showToast({
          title: "生成失败,稍候再试",
          icon: "none"
        });
      });
    });

    Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(_this), "canvasDrawFunc", function (qrdata) {
      console.log("进入下一步, 下载背景图");

      var that = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(_this);

      Object(_base64src__WEBPACK_IMPORTED_MODULE_9__[/* default */ "a"])(qrdata.data, function (qrLocalPath) {
        console.log("qr===localpath:" + qrLocalPath);
        _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.downloadFile({
          url: "https://img.mybei.cn/waimai_background2.jpg",
          success: function success(res) {
            _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.getImageInfo({
              src: res.tempFilePath
            }).then(function (img_res) {
              that.setState({
                canvasStatus: true,
                config: {
                  width: 750,
                  height: 750,
                  backgroundColor: "#ffffff",
                  debug: false,
                  images: [{
                    url: res.tempFilePath,
                    width: img_res.width,
                    height: img_res.height,
                    y: 0,
                    x: 0
                  }, {
                    url: qrLocalPath,
                    width: 300,
                    height: 300,
                    y: 700,
                    x: 220
                  }]
                }
              });
            });
          }
        });
      });
    });

    Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(_this), "onCreateSuccess", function (result) {
      var tempFilePath = result.tempFilePath,
          errMsg = result.errMsg;
      _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.hideLoading();

      if (errMsg === "canvasToTempFilePath:ok") {
        _this.setState({
          shareImage: tempFilePath,
          // 重置 TaroCanvasDrawer 状态，方便下一次调用
          canvasStatus: false,
          config: null
        });
      } else {
        // 重置 TaroCanvasDrawer 状态，方便下一次调用
        _this.setState({
          canvasStatus: false,
          config: null
        });

        _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.showToast({
          icon: "none",
          title: errMsg || "出现错误"
        });
        console.log(errMsg);
      } // 预览
      // Taro.previewImage({
      //   current: tempFilePath,
      //   urls: [tempFilePath]
      // })

    });

    Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(_this), "onCreateFail", function (error) {
      _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.hideLoading();

      _this.props.parentMethod(); // 重置 TaroCanvasDrawer 状态，方便下一次调用


      _this.setState({
        canvasStatus: false,
        config: null
      });

      console.log(error);
    });

    Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(_this), "previewImg", function () {
      _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.previewImage({
        current: _this.state.shareImage,
        urls: [_this.state.shareImage]
      });
    });

    Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(_this), "saveToAlbum", function () {
      var res = _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.saveImageToPhotosAlbum({
        filePath: _this.state.shareImage
      });
      _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.showToast({
        title: "保存图片成功",
        icon: "success",
        duration: 2000
      });
    });

    _this.state = {
      // 绘图配置文件
      config: null,
      // 绘制的图片
      shareImage: null,
      // TaroCanvasDrawer 组件状态
      canvasStatus: false
    };
    return _this;
  }

  Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(TestCanvas, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.generatePromotion();
    }
  }, {
    key: "requestMiniAppQrCode",
    value: function requestMiniAppQrCode(callback, failCallback) {
      console.log("获取小程序码");
      _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.request({
        url: api.GetBase64,
        header: {
          'X-Nideshop-Token': _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.getStorageSync("token") || ""
        },
        data: {
          userid: _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.getStorageSync("userInfo").id,
          wxappid: api.WXAppID
        },
        success: function success(res) {
          callback(res.data);
        },
        fail: function fail() {
          failCallback();
        }
      });
    }
  }, {
    key: "openShareImg",
    value: function openShareImg() {
      var _this2 = this;

      var that = this;
      this.getSetting().then(function (res) {
        _this2.props.parentMethod();

        if (!res) {
          _this2.showModal();
        } else {
          that.saveToAlbum();
        }
      }).catch(function () {
        _this2.props.parentMethod();

        _this2.showModal();
      });
    }
  }, {
    key: "showModal",
    value: function showModal() {
      this.props.parentMethod();
      var that = this;
      _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.showModal({
        title: "授权提示",
        content: "打开保存图片权限",
        success: function success(res) {
          if (res.confirm) {
            _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.openSetting({
              success: function success(res) {
                if (res.authSetting["scope.writePhotosAlbum"]) {
                  that.saveToAlbum();
                } else {
                  _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.showToast({
                    title: "授权失败",
                    icon: "none"
                  });
                }
              },
              fail: function fail() {
                _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.showToast({
                  title: "授权失败",
                  icon: "none"
                });
              }
            });
          } else if (res.cancel) {
            _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.showToast({
              title: "授权失败",
              icon: "none"
            });
          }
        }
      });
    }
  }, {
    key: "getSetting",
    value: function getSetting() {
      return new Promise(function (resolve, reject) {
        _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.getSetting().then(function (res) {
          if (!res.authSetting["scope.writePhotosAlbum"]) {
            _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.authorize({
              scope: "scope.writePhotosAlbum"
            }).then(function (res) {
              if (res.errMsg == "authorize:ok") {
                resolve(true);
              } else {
                reject(false);
              }
            }).catch(function () {
              reject(false);
            });
          } else {
            resolve(true);
          }
        }).catch(function () {
          reject(false);
        });
      });
    }
  }, {
    key: "render",
    value: function render() {
      var _this3 = this;

      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_8__[/* View */ "j"], {
        className: "image_dialog"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_8__[/* View */ "j"], {
        className: "content"
      }, this.state.shareImage ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_8__[/* View */ "j"], {
        className: "header"
      }, "\u53C2\u4E0E\u63A8\u5E7F\uFF0C\u652F\u6301\u591A\u7EA7\u88C2\u53D8\uFF0C\u8EBA\u7740\u6709\u94B1\u8D5A") : "", /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_8__[/* View */ "j"], {
        className: "body"
      }, // 由于部分限制，目前组件通过状态的方式来动态加载
      this.state.canvasStatus && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_taro_plugin_canvas__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"], {
        config: this.state.config // 绘制配置
        ,
        onCreateSuccess: this.onCreateSuccess // 绘制成功回调
        ,
        onCreateFail: this.onCreateFail // 绘制失败回调

      }), this.state.shareImage ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_8__[/* Image */ "c"], {
        className: "img",
        mode: "widthFix",
        src: this.state.shareImage,
        onClick: function onClick() {
          return _this3.previewImg();
        },
        onLongPress: this.previewImg.bind(this)
      }) : ""), this.state.shareImage ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_8__[/* View */ "j"], {
        className: "footer_root"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_8__[/* View */ "j"], {
        className: "footer fleft",
        onClick: this.props.parentMethod
      }, "\u5173\u95ED"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_8__[/* View */ "j"], {
        className: "footer fright",
        onClick: function onClick() {
          return _this3.openShareImg();
        }
      }, "\u4FDD\u5B58\u5230\u76F8\u518C")) : ""));
    }
  }]);

  return TestCanvas;
}(react__WEBPACK_IMPORTED_MODULE_7___default.a.Component);

/* harmony default export */ __webpack_exports__["a"] = (TestCanvas);

/***/ }),

/***/ "./src/component/loginComponet/index.js":
/*!**********************************************!*\
  !*** ./src/component/loginComponet/index.js ***!
  \**********************************************/
/*! exports provided: default */
/*! exports used: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass */ "./node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/assertThisInitialized */ "./node_modules/@babel/runtime/helpers/esm/assertThisInitialized.js");
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/inherits */ "./node_modules/@babel/runtime/helpers/esm/inherits.js");
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_createSuper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createSuper */ "./node_modules/@babel/runtime/helpers/esm/createSuper.js");
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @tarojs/taro */ "./node_modules/@tarojs/taro/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react */ "./node_modules/react/cjs/react.production.min.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! classnames */ "./node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _tarojs_components__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @tarojs/components */ "./node_modules/@tarojs/components/mini/index.js");
/* harmony import */ var _index_scss__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./index.scss */ "./src/component/loginComponet/index.scss");
/* harmony import */ var _index_scss__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_index_scss__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_native_uuid__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! react-native-uuid */ "./node_modules/react-native-uuid/uuid.js");
/* harmony import */ var react_native_uuid__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_native_uuid__WEBPACK_IMPORTED_MODULE_11__);














var api = __webpack_require__(/*! ../../utils/utils.js */ "./src/utils/utils.js");

var SexDetailItem = /*#__PURE__*/function (_React$Component) {
  Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(SexDetailItem, _React$Component);

  var _super = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_createSuper__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"])(SexDetailItem);

  function SexDetailItem(props) {
    var _this;

    Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(this, SexDetailItem);

    _this = _super.call(this, props);

    Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(_this), "componentWillMount", function () {
      console.info('Index willMount'); // 需要带accessToken调用的接口等 
    });

    Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(_this), "onGetUserInfo", function (res) {
      var local_uuid = _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.getStorageSync(api.miniapp_self_uuid);

      if (!local_uuid) {
        _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.setStorageSync(api.miniapp_self_uuid, react_native_uuid__WEBPACK_IMPORTED_MODULE_11___default.a.v4());
        console.log("local_uuid" + _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.getStorageSync(api.miniapp_self_uuid));
      }

      var that = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(_this);

      _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.showLoading({
        title: '正在登录...'
      });
      _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.login({
        success: function success(login_res) {
          if (login_res.code) {
            _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.request({
              url: api.AuthLoginByWeixin,
              method: "POST",
              header: {
                'X-Nideshop-Token': _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.getStorageSync("token") || ""
              },
              data: {
                code: login_res.code,
                userInfo: res.detail,
                uuid: _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.getStorageSync(api.miniapp_self_uuid),
                inviter: _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.getStorageSync('inviter') || '',
                inviter_sence: _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.getStorageSync('inviter_scene') || '',
                wxappid: api.WXAppID
              },
              success: function success(req_res) {
                if (req_res.statusCode == 200) {
                  if (req_res.data.errno == 0) {
                    that.props.parentMethod(res.detail);
                    _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.setStorage({
                      key: 'userInfo',
                      data: req_res.data.data.userInfo
                    });
                    _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.setStorage({
                      key: 'token',
                      data: req_res.data.data.token
                    });
                    _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.hideLoading();
                    _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.showToast({
                      title: '登录成功',
                      icon: 'success',
                      duration: 2000
                    });
                  }
                } else {
                  that.props.parentMethod(res.detail);
                  _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.hideLoading();
                  _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.showToast({
                    title: '登录失败',
                    icon: 'none',
                    duration: 2000
                  });
                }
              },
              fail: function fail(_fail) {
                that.props.parentMethod(res.detail);
                console.log('erqeust fail');
                _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.showToast({
                  title: '登录失败,网络错误',
                  icon: 'none',
                  duration: 2000
                });
              }
            });
          }
        }
      });
    });

    return _this;
  }

  Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(SexDetailItem, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      console.info('Index didMount');
    }
  }, {
    key: "render",
    value: function render() {
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_9__[/* View */ "j"], {
        className: "layer"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_9__[/* View */ "j"], {
        className: "auth_dialog auth"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_9__[/* View */ "j"], {
        className: "body"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_9__[/* View */ "j"], {
        className: "avatar"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_9__[/* OpenData */ "e"], {
        type: "userAvatarUrl"
      })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_9__[/* View */ "j"], {
        className: "nickname"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_9__[/* OpenData */ "e"], {
        type: "userNickName"
      })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_9__[/* View */ "j"], {
        className: "btn_wrapper"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_9__[/* Button */ "a"], {
        class: "btn login",
        openType: "getUserInfo",
        onGetUserInfo: this.onGetUserInfo
      }, "\u5FAE\u4FE1\u4E00\u952E\u767B\u5F55")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_9__[/* Text */ "i"], {
        className: "cancel_login",
        onClick: this.props.parentMethod
      }, "\u6682\u4E0D\u767B\u5F55"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_9__[/* Text */ "i"], {
        className: "agreement"
      }, "\u767B\u5F55\u5373\u540C\u610F\u6211\u4EEC \u300A\u7528\u6237\u534F\u8BAE\u300B"))));
    }
  }]);

  return SexDetailItem;
}(react__WEBPACK_IMPORTED_MODULE_7___default.a.Component);

/* harmony default export */ __webpack_exports__["a"] = (SexDetailItem);

/***/ }),

/***/ "./src/component/loginComponet/index.scss":
/*!************************************************!*\
  !*** ./src/component/loginComponet/index.scss ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "./src/component/taro-plugin-canvas/index.css":
/*!****************************************************!*\
  !*** ./src/component/taro-plugin-canvas/index.css ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "./src/component/taro-plugin-canvas/index.tsx":
/*!****************************************************!*\
  !*** ./src/component/taro-plugin-canvas/index.tsx ***!
  \****************************************************/
/*! exports provided: default */
/*! exports used: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CanvasDrawer; });
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck */ "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass */ "./node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/assertThisInitialized */ "./node_modules/@babel/runtime/helpers/esm/assertThisInitialized.js");
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/inherits */ "./node_modules/@babel/runtime/helpers/esm/inherits.js");
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_createSuper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createSuper */ "./node_modules/@babel/runtime/helpers/esm/createSuper.js");
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @tarojs/taro */ "./node_modules/@tarojs/taro/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react */ "./node_modules/react/cjs/react.production.min.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _tarojs_components__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @tarojs/components */ "./node_modules/@tarojs/components/mini/index.js");
/* harmony import */ var _utils_tools__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./utils/tools */ "./src/component/taro-plugin-canvas/utils/tools.ts");
/* harmony import */ var _utils_draw__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./utils/draw */ "./src/component/taro-plugin-canvas/utils/draw.ts");
/* harmony import */ var _index_css__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./index.css */ "./src/component/taro-plugin-canvas/index.css");
/* harmony import */ var _index_css__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_index_css__WEBPACK_IMPORTED_MODULE_12__);













var count = 1;

var CanvasDrawer = /*#__PURE__*/function (_Component) {
  Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"])(CanvasDrawer, _Component);

  var _super = Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_createSuper__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"])(CanvasDrawer);

  function CanvasDrawer(props) {
    var _this;

    Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(this, CanvasDrawer);

    _this = _super.call(this, props);

    Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(_this), "cache", void 0);

    Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(_this), "drawArr", void 0);

    Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(_this), "canvasId", void 0);

    Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(_this), "ctx", void 0);

    Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(_this), "toPx", function (rpx) {
      var int = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
      var factor = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : _this.state.factor;

      if (int) {
        return Math.ceil(rpx * factor * _this.state.pixelRatio);
      }

      return rpx * factor * _this.state.pixelRatio;
    });

    Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(_this), "toRpx", function (px) {
      var int = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
      var factor = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : _this.state.factor;

      if (int) {
        return Math.ceil(px / factor);
      }

      return px / factor;
    });

    Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(_this), "_downloadImageAndInfo", function (image, index, pixelRatio) {
      return new Promise(function (resolve, reject) {
        Object(_utils_tools__WEBPACK_IMPORTED_MODULE_10__[/* downloadImageAndInfo */ "a"])(image, index, _this.toRpx, pixelRatio).then(function (result) {
          _this.drawArr.push(result);

          resolve(result);
        }).catch(function (err) {
          console.log(err);
          reject(err);
        });
      });
    });

    Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(_this), "downloadResource", function (_ref) {
      var _ref$images = _ref.images,
          images = _ref$images === void 0 ? [] : _ref$images,
          _ref$pixelRatio = _ref.pixelRatio,
          pixelRatio = _ref$pixelRatio === void 0 ? 1 : _ref$pixelRatio;
      var drawList = [];
      var imagesTemp = images;
      imagesTemp.forEach(function (image, index) {
        return drawList.push(_this._downloadImageAndInfo(image, index, pixelRatio));
      });
      return Promise.all(drawList);
    });

    Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(_this), "downloadResourceTransit", function () {
      var config = _this.props.config;
      return new Promise(function (resolve, reject) {
        if (config.images && config.images.length > 0) {
          _this.downloadResource({
            images: config.images,
            pixelRatio: config.pixelRatio || 1
          }).then(function () {
            resolve();
          }).catch(function (e) {
            // console.log(e);
            reject(e);
          });
        } else {
          setTimeout(function () {
            resolve(1);
          }, 500);
        }
      });
    });

    Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(_this), "initCanvas", function (w, h, debug) {
      return new Promise(function (resolve) {
        _this.setState({
          pxWidth: _this.toPx(w),
          pxHeight: _this.toPx(h),
          debug: debug
        }, resolve);
      });
    });

    Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(_this), "onCreate", function () {
      var _this$props = _this.props,
          onCreateFail = _this$props.onCreateFail,
          config = _this$props.config;

      if (config['hide-loading'] === false) {
        _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.showLoading({
          mask: true,
          title: '生成中...'
        });
      }

      return _this.downloadResourceTransit().then(function () {
        _this.create(config);
      }).catch(function (err) {
        config['hide-loading'] && _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.hideLoading();
        _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.showToast({
          icon: 'none',
          title: err.errMsg || '下载图片失败'
        });
        console.error(err);

        if (!onCreateFail) {
          console.warn('您必须实现 taro-plugin-canvas 组件的 onCreateFail 方法，详见文档 https://github.com/chuyun/taro-plugin-canvas#fail');
        }

        onCreateFail && onCreateFail(err);
      });
    });

    Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(_this), "create", function (config) {
      _this.ctx = _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.createCanvasContext(_this.canvasId, _this.$scope);
      var height = Object(_utils_tools__WEBPACK_IMPORTED_MODULE_10__[/* getHeight */ "b"])(config); // 设置 pixelRatio

      _this.setState({
        pixelRatio: config.pixelRatio || 1
      }, function () {
        _this.initCanvas(config.width, height, config.debug).then(function () {
          // 设置画布底色
          if (config.backgroundColor) {
            _this.ctx.save();

            _this.ctx.setFillStyle(config.backgroundColor);

            _this.ctx.fillRect(0, 0, _this.toPx(config.width), _this.toPx(height));

            _this.ctx.restore();
          }

          var _config$texts = config.texts,
              texts = _config$texts === void 0 ? [] : _config$texts,
              _config$blocks = config.blocks,
              blocks = _config$blocks === void 0 ? [] : _config$blocks,
              _config$lines = config.lines,
              lines = _config$lines === void 0 ? [] : _config$lines;

          var queue = _this.drawArr.concat(texts.map(function (item) {
            item.type = 'text';
            item.zIndex = item.zIndex || 0;
            return item;
          })).concat(blocks.map(function (item) {
            item.type = 'block';
            item.zIndex = item.zIndex || 0;
            return item;
          })).concat(lines.map(function (item) {
            item.type = 'line';
            item.zIndex = item.zIndex || 0;
            return item;
          })); // 按照顺序排序


          queue.sort(function (a, b) {
            return a.zIndex - b.zIndex;
          });
          queue.forEach(function (item) {
            var drawOptions = {
              ctx: _this.ctx,
              toPx: _this.toPx,
              toRpx: _this.toRpx
            };

            if (item.type === 'image') {
              if (drawOptions.ctx !== null) {
                Object(_utils_draw__WEBPACK_IMPORTED_MODULE_11__[/* drawImage */ "b"])(item, drawOptions);
              }
            } else if (item.type === 'text') {
              if (drawOptions.ctx !== null) {
                Object(_utils_draw__WEBPACK_IMPORTED_MODULE_11__[/* drawText */ "d"])(item, drawOptions);
              }
            } else if (item.type === 'block') {
              if (drawOptions.ctx !== null) {
                Object(_utils_draw__WEBPACK_IMPORTED_MODULE_11__[/* drawBlock */ "a"])(item, drawOptions);
              }
            } else if (item.type === 'line') {
              if (drawOptions.ctx !== null) {
                Object(_utils_draw__WEBPACK_IMPORTED_MODULE_11__[/* drawLine */ "c"])(item, drawOptions);
              }
            }
          });
          var res = _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.getSystemInfoSync();
          var platform = res.platform;
          var time = 0;

          if (platform === 'android') {
            // 在安卓平台，经测试发现如果海报过于复杂在转换时需要做延时，要不然样式会错乱
            time = 300;
          }

          _this.ctx.draw(false, function () {
            setTimeout(function () {
              _this.getTempFile(null);
            }, time);
          });
        }).catch(function (err) {
          _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.showToast({
            icon: 'none',
            title: err.errMsg || '生成失败'
          });
          console.error(err);
        });
      });
    });

    Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"])(_this), "getTempFile", function (otherOptions) {
      var _this$props2 = _this.props,
          onCreateSuccess = _this$props2.onCreateSuccess,
          onCreateFail = _this$props2.onCreateFail;
      _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.canvasToTempFilePath({
        canvasId: _this.canvasId,
        success: function success(result) {
          if (!onCreateSuccess) {
            console.warn('您必须实现 taro-plugin-canvas 组件的 onCreateSuccess 方法，详见文档 https://github.com/chuyun/taro-plugin-canvas#success');
          }

          onCreateSuccess && onCreateSuccess(result);
        },
        fail: function fail(error) {
          var errMsg = error.errMsg;
          console.log(errMsg);

          if (errMsg === 'canvasToTempFilePath:fail:create bitmap failed') {
            count += 1;

            if (count <= 3) {
              _this.getTempFile(otherOptions);
            } else {
              if (!onCreateFail) {
                console.warn('您必须实现 taro-plugin-canvas 组件的 onCreateFail 方法，详见文档 https://github.com/chuyun/taro-plugin-canvas#fail');
              }

              onCreateFail && onCreateFail(error);
            }
          }
        }
      }, _this.$scope);
    });

    _this.state = {
      pxWidth: 0,
      pxHeight: 0,
      debug: false,
      factor: 0,
      pixelRatio: 1
    };
    _this.canvasId = Object(_utils_tools__WEBPACK_IMPORTED_MODULE_10__[/* randomString */ "c"])(10);
    _this.ctx = null;
    _this.cache = {};
    _this.drawArr = [];
    return _this;
  }

  Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(CanvasDrawer, [{
    key: "componentWillMount",
    value: function componentWillMount() {
      var config = this.props.config;
      var height = Object(_utils_tools__WEBPACK_IMPORTED_MODULE_10__[/* getHeight */ "b"])(config);
      this.initCanvas(config.width, height, config.debug);
    }
  }, {
    key: "componentDidMount",
    value: function componentDidMount() {
      var sysInfo = _tarojs_taro__WEBPACK_IMPORTED_MODULE_6___default.a.getSystemInfoSync();
      var screenWidth = sysInfo.screenWidth;
      this.setState({
        factor: screenWidth / 750
      });
      this.onCreate();
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {}
    /**
     * @description rpx => px 基础方法
     * @param { number } rpx - 需要转换的数值
     * @param { boolean} int - 是否为 int
     * @param { number } [factor = this.state.factor] - 转化因子
     * @returns { number }
     */

  }, {
    key: "render",
    value: function render() {
      var _this$state = this.state,
          pxWidth = _this$state.pxWidth,
          pxHeight = _this$state.pxHeight,
          debug = _this$state.debug;

      if (pxWidth && pxHeight) {
        return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_tarojs_components__WEBPACK_IMPORTED_MODULE_9__[/* Canvas */ "b"], {
          type: "sddd",
          canvasId: this.canvasId,
          style: "width:".concat(pxWidth, "px; height:").concat(pxHeight, "px;"),
          className: "".concat(debug ? 'debug' : 'pro', " canvas")
        });
      }

      return null;
    }
  }]);

  return CanvasDrawer;
}(react__WEBPACK_IMPORTED_MODULE_7__["Component"]);

Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(CanvasDrawer, "propTypes", {
  config: prop_types__WEBPACK_IMPORTED_MODULE_8___default.a.object.isRequired,
  onCreateSuccess: prop_types__WEBPACK_IMPORTED_MODULE_8___default.a.func.isRequired,
  onCreateFail: prop_types__WEBPACK_IMPORTED_MODULE_8___default.a.func.isRequired
});

Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"])(CanvasDrawer, "defaultProps", {});



/***/ }),

/***/ "./src/component/taro-plugin-canvas/utils/draw.ts":
/*!********************************************************!*\
  !*** ./src/component/taro-plugin-canvas/utils/draw.ts ***!
  \********************************************************/
/*! exports provided: _drawRadiusRect, _getTextWidth, _drawSingleText, drawText, drawImage, drawLine, drawBlock */
/*! exports used: drawBlock, drawImage, drawLine, drawText */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export _drawRadiusRect */
/* unused harmony export _getTextWidth */
/* unused harmony export _drawSingleText */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return drawText; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return drawImage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return drawLine; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return drawBlock; });
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_objectSpread2__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/objectSpread2 */ "./node_modules/@babel/runtime/helpers/esm/objectSpread2.js");
/* harmony import */ var _Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_typeof__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/typeof */ "./node_modules/@babel/runtime/helpers/esm/typeof.js");



/**
  * @description 绘制圆角矩形
  * @param { object } drawData - 绘制数据
  * @param { number } drawData.x - 左上角x坐标
  * @param { number } drawData.y - 左上角y坐标
  * @param { number } drawData.w - 矩形的宽
  * @param { number } drawData.h - 矩形的高
  * @param { number } drawData.r - 圆角半径
  */
function _drawRadiusRect(drawData, drawOptions) {
  var x = drawData.x,
      y = drawData.y,
      w = drawData.w,
      h = drawData.h,
      r = drawData.r;
  var ctx = drawOptions.ctx,
      toPx = drawOptions.toPx;
  var br = r / 2;
  ctx.beginPath();
  ctx.moveTo(toPx(x + br), toPx(y)); // 移动到左上角的点

  ctx.lineTo(toPx(x + w - br), toPx(y));
  ctx.arc(toPx(x + w - br), toPx(y + br), toPx(br), 2 * Math.PI * (3 / 4), 2 * Math.PI * (4 / 4));
  ctx.lineTo(toPx(x + w), toPx(y + h - br));
  ctx.arc(toPx(x + w - br), toPx(y + h - br), toPx(br), 0, 2 * Math.PI * (1 / 4));
  ctx.lineTo(toPx(x + br), toPx(y + h));
  ctx.arc(toPx(x + br), toPx(y + h - br), toPx(br), 2 * Math.PI * (1 / 4), 2 * Math.PI * (2 / 4));
  ctx.lineTo(toPx(x), toPx(y + br));
  ctx.arc(toPx(x + br), toPx(y + br), toPx(br), 2 * Math.PI * (2 / 4), 2 * Math.PI * (3 / 4));
}
/**
 * @description 计算文本长度
 * @param { Array | Object } text 数组 或者 对象
 */

function _getTextWidth(_text, drawOptions) {
  var ctx = drawOptions.ctx,
      toPx = drawOptions.toPx,
      toRpx = drawOptions.toRpx;
  var texts = [];

  if (Array.isArray(_text)) {
    texts = _text;
  } else {
    texts.push(_text);
  }

  var width = 0;
  texts.forEach(function (_ref) {
    var fontSize = _ref.fontSize,
        text = _ref.text,
        _ref$marginLeft = _ref.marginLeft,
        marginLeft = _ref$marginLeft === void 0 ? 0 : _ref$marginLeft,
        _ref$marginRight = _ref.marginRight,
        marginRight = _ref$marginRight === void 0 ? 0 : _ref$marginRight;
    ctx.setFontSize(toPx(fontSize));
    var _textWidth = 0;

    if (Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_typeof__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(text) === 'object') {
      _textWidth = ctx.measureText(text.text).width + text.marginLeft + text.marginRight;
    } else {
      _textWidth = ctx.measureText(text).width;
    }

    width += _textWidth + marginLeft + marginRight;
  });
  return toRpx(width);
}
/**
  * @description 渲染一段文字
  * @param { object } drawData - 绘制数据
  * @param { number } drawData.x - x坐标 rpx
  * @param { number } drawData.y - y坐标 rpx
  * @param { number } drawData.fontSize - 文字大小 rpx
  * @param { number } [drawData.color] - 颜色
  * @param { string } [drawData.baseLine] - 基线对齐方式 top| middle|bottom
  * @param { string } [drawData.textAlign='left'] - 对齐方式 left|center|right
  * @param { string } drawData.text - 当Object类型时，参数为 text 字段的参数，marginLeft、marginRight这两个字段可用
  * @param { number } [drawData.opacity=1] - 1为不透明，0为透明
  * @param { string } [drawData.textDecoration='none']
  * @param { number } [drawData.width] - 文字宽度 没有指定为画布宽度
  * @param { number } [drawData.lineNum=1] - 根据宽度换行，最多的行数
  * @param { number } [drawData.lineHeight=0] - 行高
  * @param { string } [drawData.fontWeight='normal'] - 'bold' 加粗字体，目前小程序不支持 100 - 900 加粗
  * @param { string } [drawData.fontStyle='normal'] - 'italic' 倾斜字体
  * @param { string } [drawData.fontFamily="sans-serif"] - 小程序默认字体为 'sans-serif', 请输入小程序支持的字体
  */

function _drawSingleText(drawData, drawOptions) {
  var x = drawData.x,
      y = drawData.y,
      fontSize = drawData.fontSize,
      color = drawData.color,
      baseLine = drawData.baseLine,
      _drawData$textAlign = drawData.textAlign,
      textAlign = _drawData$textAlign === void 0 ? 'left' : _drawData$textAlign,
      text = drawData.text,
      _drawData$opacity = drawData.opacity,
      opacity = _drawData$opacity === void 0 ? 1 : _drawData$opacity,
      _drawData$textDecorat = drawData.textDecoration,
      textDecoration = _drawData$textDecorat === void 0 ? 'none' : _drawData$textDecorat,
      _drawData$width = drawData.width,
      width = _drawData$width === void 0 ? 0 : _drawData$width,
      _drawData$lineNum = drawData.lineNum,
      lineNum = _drawData$lineNum === void 0 ? 1 : _drawData$lineNum,
      _drawData$lineHeight = drawData.lineHeight,
      lineHeight = _drawData$lineHeight === void 0 ? 0 : _drawData$lineHeight,
      _drawData$fontWeight = drawData.fontWeight,
      fontWeight = _drawData$fontWeight === void 0 ? 'normal' : _drawData$fontWeight,
      _drawData$fontStyle = drawData.fontStyle,
      fontStyle = _drawData$fontStyle === void 0 ? 'normal' : _drawData$fontStyle,
      _drawData$fontFamily = drawData.fontFamily,
      fontFamily = _drawData$fontFamily === void 0 ? "sans-serif" : _drawData$fontFamily;
  var ctx = drawOptions.ctx,
      toPx = drawOptions.toPx;
  ctx.save();
  ctx.beginPath();
  ctx.font = fontStyle + " " + fontWeight + " " + toPx(fontSize, true) + "px " + fontFamily;
  ctx.setGlobalAlpha(opacity); // ctx.setFontSize(toPx(fontSize));

  if (Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_typeof__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"])(text) === 'object') {
    text = text.text;
  }

  color && ctx.setFillStyle(color);
  baseLine && ctx.setTextBaseline(baseLine);
  ctx.setTextAlign(textAlign);
  var textWidth = ctx.measureText(text).width;
  var textArr = [];
  var drawWidth = toPx(width);

  if (width && textWidth > drawWidth) {
    // 文本宽度 大于 渲染宽度
    var fillText = '';
    var line = 1;

    for (var i = 0; i <= text.length - 1; i++) {
      // 将文字转为数组，一行文字一个元素
      fillText = fillText + text[i];

      if (ctx.measureText(fillText).width >= drawWidth) {
        if (line === lineNum) {
          if (i !== text.length - 1) {
            fillText = fillText.substring(0, fillText.length - 1) + '...';
          }
        }

        if (line <= lineNum) {
          textArr.push(fillText);
        }

        fillText = '';
        line++;
      } else {
        if (line <= lineNum) {
          if (i === text.length - 1) {
            textArr.push(fillText);
          }
        }
      }
    }

    textWidth = width;
  } else {
    textArr.push(text);
  }

  textArr.forEach(function (item, index) {
    ctx.fillText(item, toPx(x), toPx(y + (lineHeight || fontSize) * index));
  });
  ctx.restore(); // textDecoration

  if (textDecoration !== 'none') {
    var lineY = y;

    if (textDecoration === 'line-through') {
      // 目前只支持贯穿线
      lineY = y; // 小程序画布baseLine偏移阈值

      var threshold = 5; // 根据baseLine的不同对贯穿线的Y坐标做相应调整

      switch (baseLine) {
        case 'top':
          lineY += fontSize / 2 + threshold;
          break;

        case 'middle':
          break;

        case 'bottom':
          lineY -= fontSize / 2 + threshold;
          break;

        default:
          lineY -= fontSize / 2 - threshold;
          break;
      }
    }

    ctx.save();
    ctx.moveTo(toPx(x), toPx(lineY));
    ctx.lineTo(toPx(x) + toPx(textWidth), toPx(lineY));
    color && ctx.setStrokeStyle(color);
    ctx.stroke();
    ctx.restore();
  }

  return textWidth;
}
/**
 * 渲染文字
 * @param { object } params - 绘制数据
 * @param { number } params.x - x坐标 rpx
 * @param { number } params.y - y坐标 rpx
 * @param { number } params.fontSize - 文字大小 rpx
 * @param { number } [params.color] - 颜色
 * @param { string } [params.baseLine] - 基线对齐方式 top| middle|bottom
 * @param { string } [params.textAlign='left'] - 对齐方式 left|center|right
 * @param { string } params.text - 当Object类型时，参数为 text 字段的参数，marginLeft、marginRight这两个字段可用
 * @param { number } [params.opacity=1] - 1为不透明，0为透明
 * @param { string } [params.textDecoration='none']
 * @param { number } [params.width] - 文字宽度 没有指定为画布宽度
 * @param { number } [params.lineNum=1] - 根据宽度换行，最多的行数
 * @param { number } [params.lineHeight=0] - 行高
 * @param { string } [params.fontWeight='normal'] - 'bold' 加粗字体，目前小程序不支持 100 - 900 加粗
 * @param { string } [params.fontStyle='normal'] - 'italic' 倾斜字体
 * @param { string } [params.fontFamily="sans-serif"] - 小程序默认字体为 'sans-serif', 请输入小程序支持的字体
 */

function drawText(params, drawOptions) {
  // const { ctx, toPx, toRpx } = drawOptions;
  var x = params.x,
      y = params.y,
      text = params.text,
      baseLine = params.baseLine;

  if (Array.isArray(text)) {
    var preText = {
      x: x,
      y: y,
      baseLine: baseLine
    };
    text.forEach(function (item) {
      preText.x += item.marginLeft || 0;

      var textWidth = _drawSingleText(Object.assign(item, Object(_Users_zhoupei_projects_coupons_node_modules_babel_runtime_helpers_esm_objectSpread2__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])({}, preText)), drawOptions);

      preText.x += textWidth + (item.marginRight || 0); // 下一段字的 x 轴为上一段字 x + 上一段字宽度
    });
  } else {
    _drawSingleText(params, drawOptions);
  }
}

/**
 * @description 渲染图片
 * @param { object } data
 * @param { number } x - 图像的左上角在目标 canvas 上 x 轴的位置
 * @param { number } y - 图像的左上角在目标 canvas 上 y 轴的位置
 * @param { number } w - 在目标画布上绘制图像的宽度，允许对绘制的图像进行缩放
 * @param { number } h - 在目标画布上绘制图像的高度，允许对绘制的图像进行缩放
 * @param { number } sx - 源图像的矩形选择框的左上角 x 坐标
 * @param { number } sy - 源图像的矩形选择框的左上角 y 坐标
 * @param { number } sw - 源图像的矩形选择框的宽度
 * @param { number } sh - 源图像的矩形选择框的高度
 * @param { number } [borderRadius=0] - 圆角
 * @param { number } [borderWidth=0] - 边框
 */
function drawImage(data, drawOptions) {
  var ctx = drawOptions.ctx,
      toPx = drawOptions.toPx;
  var imgPath = data.imgPath,
      x = data.x,
      y = data.y,
      w = data.w,
      h = data.h,
      sx = data.sx,
      sy = data.sy,
      sw = data.sw,
      sh = data.sh,
      _data$borderRadius = data.borderRadius,
      borderRadius = _data$borderRadius === void 0 ? 0 : _data$borderRadius,
      _data$borderWidth = data.borderWidth,
      borderWidth = _data$borderWidth === void 0 ? 0 : _data$borderWidth,
      borderColor = data.borderColor;
  ctx.save();

  if (borderRadius > 0) {
    var drawData = {
      x: x,
      y: y,
      w: w,
      h: h,
      r: borderRadius
    };

    _drawRadiusRect(drawData, drawOptions);

    ctx.strokeStyle = 'rgba(255,255,255,0)';
    ctx.stroke();
    ctx.clip();
    ctx.drawImage(imgPath, toPx(sx), toPx(sy), toPx(sw), toPx(sh), toPx(x), toPx(y), toPx(w), toPx(h));

    if (borderWidth > 0) {
      borderColor && ctx.setStrokeStyle(borderColor);
      ctx.setLineWidth(toPx(borderWidth));
      ctx.stroke();
    }
  } else {
    ctx.drawImage(imgPath, toPx(sx), toPx(sy), toPx(sw), toPx(sh), toPx(x), toPx(y), toPx(w), toPx(h));
  }

  ctx.restore();
}
/**
 * @description 渲染线
 * @param  { number } startX - 起始坐标
 * @param  { number } startY - 起始坐标
 * @param  { number } endX - 终结坐标
 * @param  { number } endY - 终结坐标
 * @param  { number } width - 线的宽度
 * @param  { string } [color] - 线的颜色
 */

function drawLine(drawData, drawOptions) {
  var startX = drawData.startX,
      startY = drawData.startY,
      endX = drawData.endX,
      endY = drawData.endY,
      color = drawData.color,
      width = drawData.width;
  var ctx = drawOptions.ctx,
      toPx = drawOptions.toPx;
  ctx.save();
  ctx.beginPath();
  color && ctx.setStrokeStyle(color);
  ctx.setLineWidth(toPx(width));
  ctx.moveTo(toPx(startX), toPx(startY));
  ctx.lineTo(toPx(endX), toPx(endY));
  ctx.stroke();
  ctx.closePath();
  ctx.restore();
}
/**
* @description 渲染块
* @param  { number } x - x坐标
* @param  { number } y - y坐标
* @param  { number } height -高
* @param  { string|object } [text] - 块里面可以填充文字，参考texts字段
* @param  { number } [width=0] - 宽 如果内部有文字，由文字宽度和内边距决定
* @param  { number } [paddingLeft=0] - 内左边距
* @param  { number } [paddingRight=0] - 内右边距
* @param  { number } [borderWidth] - 边框宽度
* @param  { string } [backgroundColor] - 背景颜色
* @param  { string } [borderColor] - 边框颜色
* @param  { number } [borderRadius=0] - 圆角
* @param  { number } [opacity=1] - 透明度
*
*/

function drawBlock(blockData, drawOptions) {
  var ctx = drawOptions.ctx,
      toPx = drawOptions.toPx;
  var text = blockData.text,
      _blockData$width = blockData.width,
      width = _blockData$width === void 0 ? 0 : _blockData$width,
      height = blockData.height,
      x = blockData.x,
      y = blockData.y,
      _blockData$paddingLef = blockData.paddingLeft,
      paddingLeft = _blockData$paddingLef === void 0 ? 0 : _blockData$paddingLef,
      _blockData$paddingRig = blockData.paddingRight,
      paddingRight = _blockData$paddingRig === void 0 ? 0 : _blockData$paddingRig,
      borderWidth = blockData.borderWidth,
      backgroundColor = blockData.backgroundColor,
      borderColor = blockData.borderColor,
      _blockData$borderRadi = blockData.borderRadius,
      borderRadius = _blockData$borderRadi === void 0 ? 0 : _blockData$borderRadi,
      _blockData$opacity = blockData.opacity,
      opacity = _blockData$opacity === void 0 ? 1 : _blockData$opacity; // 判断是否块内有文字

  var blockWidth = 0; // 块的宽度

  var textX = 0;
  var textY = 0;

  if (typeof text !== 'undefined') {
    // 如果有文字并且块的宽度小于文字宽度，块的宽度为 文字的宽度 + 内边距
    // const textWidth = _getTextWidth(typeof text.text === 'string' ? text : text.text, drawOptions);
    var textWidth = _getTextWidth(text, drawOptions);

    blockWidth = textWidth > width ? textWidth : width;
    blockWidth += paddingLeft + paddingLeft;
    var _text$textAlign = text.textAlign,
        textAlign = _text$textAlign === void 0 ? 'left' : _text$textAlign;
    textY = height / 2 + y; // 文字的y轴坐标在块中线

    if (textAlign === 'left') {
      // 如果是右对齐，那x轴在块的最左边
      textX = x + paddingLeft;
    } else if (textAlign === 'center') {
      textX = blockWidth / 2 + x;
    } else {
      textX = x + blockWidth - paddingRight;
    }
  } else {
    blockWidth = width;
  }

  if (backgroundColor) {
    // 画面
    ctx.save();
    ctx.setGlobalAlpha(opacity);
    ctx.setFillStyle(backgroundColor);

    if (borderRadius > 0) {
      // 画圆角矩形
      var drawData = {
        x: x,
        y: y,
        w: blockWidth,
        h: height,
        r: borderRadius
      };

      _drawRadiusRect(drawData, drawOptions);

      ctx.fill();
    } else {
      ctx.fillRect(toPx(x), toPx(y), toPx(blockWidth), toPx(height));
    }

    ctx.restore();
  }

  if (borderWidth) {
    // 画线
    ctx.save();
    ctx.setGlobalAlpha(opacity);
    borderColor && ctx.setStrokeStyle(borderColor);
    ctx.setLineWidth(toPx(borderWidth));

    if (borderRadius > 0) {
      // 画圆角矩形边框
      var _drawData = {
        x: x,
        y: y,
        w: blockWidth,
        h: height,
        r: borderRadius
      };

      _drawRadiusRect(_drawData, drawOptions);

      ctx.stroke();
    } else {
      ctx.strokeRect(toPx(x), toPx(y), toPx(blockWidth), toPx(height));
    }

    ctx.restore();
  }

  if (text) {
    drawText(Object.assign(text, {
      x: textX,
      y: textY
    }), drawOptions);
  }
}

/***/ }),

/***/ "./src/component/taro-plugin-canvas/utils/tools.ts":
/*!*********************************************************!*\
  !*** ./src/component/taro-plugin-canvas/utils/tools.ts ***!
  \*********************************************************/
/*! exports provided: randomString, getHeight, mapHttpToHttps, downImage, getImageInfo, downloadImageAndInfo */
/*! exports used: downloadImageAndInfo, getHeight, randomString */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return randomString; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return getHeight; });
/* unused harmony export mapHttpToHttps */
/* unused harmony export downImage */
/* unused harmony export getImageInfo */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return downloadImageAndInfo; });
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @tarojs/taro */ "./node_modules/@tarojs/taro/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_0__);


/**
 * @description 生成随机字符串
 * @param  { number } length - 字符串长度
 * @returns { string }
 */
var randomString = function randomString(length) {
  var str = Math.random().toString(36).substr(2);

  if (str.length >= length) {
    return str.substr(0, length);
  }

  str += randomString(length - str.length);
  return str;
};
/**
 * @description 获取最大高度
 * @param  {} config
 * @returns { number }
 */

var getHeight = function getHeight(config) {
  var getTextHeight = function getTextHeight(text) {
    var fontHeight = text.lineHeight || text.fontSize;
    var height = 0;

    if (text.baseLine === 'top') {
      height = fontHeight;
    } else if (text.baseLine === 'middle') {
      height = fontHeight / 2;
    } else {
      height = 0;
    }

    return height;
  };

  var heightArr = [];
  (config.blocks || []).forEach(function (item) {
    heightArr.push(item.y + item.height);
  });
  (config.texts || []).forEach(function (item) {
    var height;
    height = getTextHeight(item);
    heightArr.push(item.y + height);
  });
  (config.images || []).forEach(function (item) {
    heightArr.push(item.y + item.height);
  });
  (config.lines || []).forEach(function (item) {
    heightArr.push(item.startY);
    heightArr.push(item.endY);
  });
  var sortRes = heightArr.sort(function (a, b) {
    return b - a;
  });
  var canvasHeight = 0;

  if (sortRes.length > 0) {
    canvasHeight = sortRes[0];
  }

  if (config.height < canvasHeight || !config.height) {
    return canvasHeight;
  } else {
    return config.height;
  }
};
/**
 * 将http转为https
 * @param {String}} rawUrl 图片资源url
 * @returns { string }
 */

function mapHttpToHttps(rawUrl) {
  if (rawUrl.indexOf(':') < 0) {
    return rawUrl;
  }

  var urlComponent = rawUrl.split(':');

  if (urlComponent.length === 2) {
    if (urlComponent[0] === 'http') {
      urlComponent[0] = 'https';
      return "".concat(urlComponent[0], ":").concat(urlComponent[1]);
    }
  }

  return rawUrl;
}
/**
 * 下载图片资源
 * @param { string } imageUrl
 * @returns  { Promise }
 */

function downImage(imageUrl) {
  return new Promise(function (resolve, reject) {
    // if (/^http/.test(imageUrl) && !new RegExp(wx.env.USER_DATA_PATH).test(imageUrl))
    if (/^http/.test(imageUrl) && // @ts-ignore
    !new RegExp(wx.env.USER_DATA_PATH).test(imageUrl) && !/^http:\/\/tmp/.test(imageUrl)) {
      _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default.a.downloadFile({
        url: imageUrl,
        // TODO
        // url: mapHttpToHttps(imageUrl),
        success: function success(res) {
          if (res.statusCode === 200) {
            resolve(res.tempFilePath);
          } else {
            reject(res.errMsg);
          }
        },
        fail: function fail(err) {
          reject(err);
        }
      });
    } else {
      // 支持本地地址
      resolve(imageUrl);
    }
  });
}

/**
 * 获取图片信息
 * @param {*} imgPath
 * @param {*} index
 * @returns  { Promise }
 */
function getImageInfo(imgPath, index) {
  return new Promise(function (resolve, reject) {
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default.a.getImageInfo({
      src: imgPath
    }).then(function (res) {
      resolve({
        imgPath: imgPath,
        imgInfo: res,
        index: index
      });
    }).catch(function (err) {
      reject(err);
    });
  });
}
/**
* @description 下载图片并获取图片信息
* @param  {} image
* @param  {} index
* @returns  { Promise }
*/

function downloadImageAndInfo(image, index, toRpxFunc, pixelRatio) {
  return new Promise(function (resolve, reject) {
    var x = image.x,
        y = image.y,
        url = image.url,
        zIndex = image.zIndex;
    var imageUrl = url; // 下载图片

    downImage(imageUrl) // 获取图片信息
    .then(function (imgPath) {
      return getImageInfo(imgPath, index);
    }).then(function (_ref) {
      var imgPath = _ref.imgPath,
          imgInfo = _ref.imgInfo;
      // 根据画布的宽高计算出图片绘制的大小，这里会保证图片绘制不变形
      var sx;
      var sy;
      var borderRadius = image.borderRadius || 0;
      var setWidth = image.width;
      var setHeight = image.height;
      var width = toRpxFunc(imgInfo.width / pixelRatio);
      var height = toRpxFunc(imgInfo.height / pixelRatio);

      if (width / height <= setWidth / setHeight) {
        sx = 0;
        sy = (height - width / setWidth * setHeight) / 2;
      } else {
        sy = 0;
        sx = (width - height / setHeight * setWidth) / 2;
      }

      var result = {
        type: 'image',
        borderRadius: borderRadius,
        borderWidth: image.borderWidth,
        borderColor: image.borderColor,
        zIndex: typeof zIndex !== 'undefined' ? zIndex : index,
        imgPath: imgPath,
        sx: sx,
        sy: sy,
        sw: width - sx * 2,
        sh: height - sy * 2,
        x: x,
        y: y,
        w: setWidth,
        h: setHeight
      };
      resolve(result);
    }).catch(function (err) {
      console.log(err);
      reject(err);
    });
  });
}

/***/ }),

/***/ "./src/utils/commonUtils.tsx":
/*!***********************************!*\
  !*** ./src/utils/commonUtils.tsx ***!
  \***********************************/
/*! exports provided: default */
/*! exports used: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @tarojs/taro */ "./node_modules/@tarojs/taro/index.js");
/* harmony import */ var _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_tarojs_taro__WEBPACK_IMPORTED_MODULE_0__);


function handleShare(params) {
  console.log("========================处理分享参数" + params.path);
  var inviter = params.params.inviter;
  var scene = params.params.scene;

  if (inviter) {
    console.log(inviter);
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default.a.setStorage({
      key: "inviter",
      data: inviter
    });
  }

  if (scene) {
    console.log(scene);
    _tarojs_taro__WEBPACK_IMPORTED_MODULE_0___default.a.setStorage({
      key: "inviter_scene",
      data: scene
    });
  }
}

/* harmony default export */ __webpack_exports__["a"] = (handleShare);

/***/ }),

/***/ "./src/utils/event.js":
/*!****************************!*\
  !*** ./src/utils/event.js ***!
  \****************************/
/*! exports provided: default */
/*! exports used: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var events__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! events */ "./node_modules/events/events.js");
/* harmony import */ var events__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(events__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["a"] = (new events__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]());

/***/ }),

/***/ "./src/utils/utils.js":
/*!****************************!*\
  !*** ./src/utils/utils.js ***!
  \****************************/
/*! no static exports found */
/*! all exports used */
/***/ (function(module, exports) {

// const ApiRootUrl = 'http://127.0.0.1:8360/api/';
var ApiRootUrl = 'https://p.mybei.cn/api/';
var WXAppID = 'wxf8d82754b57de7a8';
module.exports = {
  // 登录
  VERSION: "1.1",
  WXAppID: WXAppID,
  shareTitle: "美团，饿了么外卖，有券有返利，单单帮你省。",
  sharePath: "/pages/coupons/index",
  keySelectedIndex: 'keySelectedIndex',
  //首页跳转的时候用
  navBarSelectChangedNotification: 'navBarElemeSelectChanged',
  navBarMeituanSelectChangedNotification: 'navBarMeituanSelectChanged',
  miniapp_self_uuid: 'miniapp_self_uuid',
  AuthLoginByWeixin: ApiRootUrl + 'auth/loginByWeixin',
  //微信登录
  UserDetail: ApiRootUrl + 'user/getUserDetail',
  //获取用户详情
  myFollewers: ApiRootUrl + 'user/getFollowers',
  //获取用户只邀请列表
  myFollewers2: ApiRootUrl + 'user/getFollowers2',
  //获取用户二级邀请列表
  elemeOrdersList: ApiRootUrl + 'waimai_order/getEleMeOrders',
  //获取饿了么订单
  updateAlipay: ApiRootUrl + 'user/updateAlipay',
  //更新提现方式
  meituanOrdersList: ApiRootUrl + 'waimai_order/getMeituanOrders',
  //获取美团订单
  IndexUrl: ApiRootUrl + 'index/appInfo',
  //首页数据接口
  ElmeLinkUrl: ApiRootUrl + 'elemelink/getElmeLink',
  //获取饿了么链接
  MeituanLinkUrl: ApiRootUrl + 'meituanLink/getMeituanLink',
  //获取美团链接
  WithDrawInfo: ApiRootUrl + 'user/getWithDrawInfo',
  //获取提现信息
  EstablishWithDraw: ApiRootUrl + 'user/establishWithDraw',
  //申请提现
  GetBase64: ApiRootUrl + 'qrcode/getBase64',
  //获取商品详情二维码
  NewIndexUrl: ApiRootUrl + 'mp/index'
};

/***/ })

}]);
//# sourceMappingURL=common.js.map